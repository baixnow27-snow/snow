import { QUESTIONS, ROUND_BATCHES, SCENARIOS, ENGINE_VERSION, getQuestion } from './engine-data.js';
import { buildReport, getSocialContext } from './diagnosis.js';
export { buildReport } from './diagnosis.js';

const IDEA_ROUNDS = ['R0', 'R1', 'R2', 'R3', 'R4'];
const MADE_ROUNDS = ['R0', 'R3', 'R4', 'R1', 'R2'];
const now = () => new Date().toISOString();
const batchOrder = (rounds) => rounds.flatMap((round) => ROUND_BATCHES.filter((batch) => batch.round === round).map((batch) => batch.id));
const telemetryFor = (session, id) => session.questionTelemetry[id] ||= {
  stalled: false, usedHelp: false, maxHelpLevel: 0, changedRoute: false,
  volunteeredExtra: '', signal: 'none', skipped: false, clarificationCount: 0,
};
const append = (session, role, text, extra = {}) => session.messages.push({ role, text, at: now(), ...extra });
const touch = (session) => { session.updatedAt = now(); };
const textOf = (value) => typeof value === 'string' ? value : value == null ? '' : String(value);

function appendBatchPrompt(session) {
  const batch = getCurrentBatch(session);
  if (!batch) return;
  append(session, 'assistant', batch.questions.map((question) => `${question.title}\n${question.body || ''}`).join('\n\n'), {
    questionIds: batch.questionIds, batchId: batch.id,
  });
}

export function createSession({ scenarioId = 'idea', opening = '', custom = false } = {}) {
  const id = globalThis.crypto?.randomUUID?.() || `session-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const session = {
    id, version: ENGINE_VERSION, scenarioId, custom: Boolean(custom),
    title: custom ? '我的新品想法' : SCENARIOS.find((scenario) => scenario.id === scenarioId)?.label || '新的新品问询',
    createdAt: now(), updatedAt: now(), answers: {}, drafts: {}, questionTelemetry: {},
    messages: [], batchOrder: batchOrder(IDEA_ROUNDS), batchIndex: 0,
    complete: false, stopReason: null, feedback: null, report: null,
    route: 'idea', routeLog: [], search: { performed: false, mode: 'user-statements-only' },
  };
  for (const question of QUESTIONS) telemetryFor(session, question.id);
  append(session, 'assistant', '说说你想推的新品，一句话就行。我们先把购买者、发生问题的时刻和已有条件问清楚，再整理一份待验证的问题记录。');
  if (textOf(opening).trim()) {
    session.answers['R0-Q1'] = textOf(opening);
    session.title = textOf(opening).trim().slice(0, 30);
    applySignal(session, 'R0-Q1', textOf(opening));
    append(session, 'user', textOf(opening), { questionIds: ['R0-Q1'] });
  }
  appendBatchPrompt(session);
  return session;
}

export function getCurrentBatch(session) {
  if (session.complete) return null;
  const original = ROUND_BATCHES.find((batch) => batch.id === session.batchOrder[session.batchIndex]);
  if (!original) return null;
  const questionIds = original.questionIds.filter((id) => !Object.hasOwn(session.answers, id));
  const questions = questionIds.map(getQuestion).filter(Boolean);
  // Conditional follow-ups are recorded on submission after reading the full
  // scene, rather than assuming an optional extra answers an unasked question.
  return { ...original, questionIds, questions, followUps: [] };
}

export function setDraft(session, questionId, value) {
  if (!getQuestion(questionId)) return;
  session.drafts[questionId] = textOf(value);
  touch(session);
}

export function advanceHelp(session, questionId) {
  const question = getQuestion(questionId);
  if (!question) return 0;
  if (session.complete || !getCurrentBatch(session)?.questionIds.includes(questionId)) return telemetryFor(session, questionId).maxHelpLevel;
  const telemetry = telemetryFor(session, questionId);
  telemetry.stalled = true;
  telemetry.usedHelp = true;
  telemetry.maxHelpLevel = Math.min(3, telemetry.maxHelpLevel + 1);
  if (telemetry.maxHelpLevel === 1) append(session, 'assistant', `我们先看个例子：${question.example || '可以从最近一次实际发生的事说起。'}`, { questionIds: [questionId], helpLevel: 1 });
  else if (telemetry.maxHelpLevel === 2) append(session, 'assistant', `如果更接近下面哪种情况，可以选一个，再用自己的话补充：\n${(question.options || []).map((option) => `· ${option}`).join('\n')}`, { questionIds: [questionId], helpLevel: 2 });
  else if (!session.messages.some((message) => message.helpLevel === 3 && message.questionIds?.includes(questionId))) append(session, 'assistant', '这块可以先空着，往下走，后面再补。', { questionIds: [questionId], helpLevel: 3 });
  touch(session);
  return telemetry.maxHelpLevel;
}

export function isWeakNeed(value) {
  const text = textOf(value).replace(/[“”「」"']/g, '');
  if (!text.trim()) return false;
  // Explicitly discussing and rejecting the weak answer must not trigger a stop.
  const cleaned = text
    .replace(/(?:也行|凑合(?:也能过)?|忍忍就过去(?:了)?)(?:是(?:不对|错)的|这个说法不成立|这种说法不成立)/g, '')
    .replace(/(?:不是|并非|并不是|不觉得|不能说|不能算|不会|不可能|绝非|谈不上|不能|不愿意|不接受|不想|无法)[^，。；!?！？\n]{0,10}(?:也行|凑合(?:也能过)?|忍忍(?:就过去(?:了)?)?)/g, '')
    .replace(/不(?:也行|凑合(?:也能过)?|忍忍(?:就过去(?:了)?)?)/g, '');
  if (/(?:也行|凑合(?:也能过)?|忍忍就(?:过去|过了)|忍一忍就过去)/.test(cleaned)) return true;
  return /(?:没有|不用|不买)[^，。；!?！？\n]{0,18}(?:也可以|无所谓|没什么影响|没有影响|不影响|照样过)/.test(cleaned);
}

function signalFor(questionId, value) {
  const text = textOf(value).trim();
  if (!text) return ['R0-Q1', 'R2-Q2', 'R4-Q3'].includes(questionId)
    ? { signal: 'red', reason: '该项暂时留白，需要在收口时记录信息缺口。' }
    : { signal: 'none', reason: '' };
  if (questionId === 'R2-Q3' && isWeakNeed(text)) return { signal: 'red', reason: '口述中表示没有本产品也可以，需提前收口核实需求。' };
  const transferText = text
    .replace(/(?:不需要|不用|无需|不必)重新(?:建立|建|做)/g, '')
    .replace(/(?:不是|并非|并不是)[^，。；!?！？\n]{0,8}(?:无关|不相关|没关系|用不上|不能直接|无法直接|不能迁移|需要重新(?:建立|建|做))/g, '');
  if (questionId === 'R4-Q2' && /(?:完全|基本|确实|其实|都)?(?:无关|不相关|没关系|用不上|不能直接|无法直接|不能迁移)|需要重新(?:建立|建|做)|都要重新|没有可迁移/.test(transferText)) return { signal: 'yellow', reason: '口述中有条件尚不能直接用于新品，需要在收口时核实。' };
  if (questionId === 'R0-Q1' && (text.match(/[。！？!?]/g) || []).length > 2) return { signal: 'red', reason: '产品描述尚未收拢为一句话，仍需核实具体对象。' };
  const rules = {
    'R0-Q1': /就是那个|类似于|不知(?:道)?怎么说|说不清/,
    'R0-Q3': /行业都在做|同行都在做|同行在做|我们得有个新品|感觉有机会|跟风/,
    'R1-Q2': /没什么办法[^。]{0,10}忍|没有办法[^。]{0,10}忍|就忍着|只能忍/,
    'R1-Q3': /不会主动找|不主动(?:去)?找|不会专门找|不(?:会|去)搜索|很少主动找/,
    'R2-Q2': /不知道什么时候|说不出(?:具体)?时|没有具体(?:时|场景)|不清楚什么时候|随时|任何时候|需要的时候/,
    'R3-Q3': /三个月[^。]{0,10}(?:抄|做)|(?:一|两|二|三|1|2|3)个月(?:就)?(?:能|可以|足够)|很容易(?:抄|做)|很快(?:就能|能|可以)(?:抄|做)/,
    'R3-Q4': /成本[^。]{0,15}(?:加|利润|%|％)|成本加成/,
    'R4-Q3': /不知道|说不清|答不上|没(?:有|什么)(?:了|剩|其他)|不剩|还没找到/,
  };
  return rules[questionId]?.test(text) ? { signal: 'red', reason: '该项口述需要在收口时列为待核实信息。' } : { signal: 'none', reason: '' };
}

function applySignal(session, questionId, value) {
  const result = signalFor(questionId, value);
  Object.assign(telemetryFor(session, questionId), { signal: result.signal, signalReason: result.reason });
  return { questionId, ...result };
}

function clarificationFor(questionId, value) {
  const text = textOf(value).trim();
  if (/就是那个|类似于|大概就是那|怎么说呢/.test(text)) return getQuestion(questionId)?.clarification || '你用一个具体的名词叫它什么？';
  if (questionId === 'R0-Q1' && (text.match(/[。！？!?]/g) || []).length > 2) return '如果只用一个名词和一句话，你会怎么介绍它？';
  if (questionId === 'R1-Q1' && /岁|女性|男性|年轻人|宝妈|中产|上班族|白领|人群/.test(text)
    && !/昨天|前天|最近一次|一位|一个|他在|她在|住在|住|经理|设计师|老师|护士|司机|工作|每天|加班/.test(text)) return '这里面最典型的那个人，昨天一天都做了什么？';
  return '';
}

export function submitBatch(session, answers = {}, { extras = {} } = {}) {
  // The UI may pass its extraDrafts object directly; preserve the submitted
  // original before clearing committed draft fields below.
  extras = { ...extras };
  const batch = getCurrentBatch(session);
  if (!batch) return { ok: false, errors: { session: '本次问询已结束。' }, complete: Boolean(session.complete) };
  const errors = {};
  for (const id of batch.questionIds) {
    const value = textOf(Object.hasOwn(answers, id) ? answers[id] : session.drafts[id]);
    setDraft(session, id, value);
    if (!value.trim() && telemetryFor(session, id).maxHelpLevel < 3) errors[id] = '可以先看看案例；如果仍答不上，再看选项，最后可以暂时留白。';
  }
  if (Object.keys(errors).length) return { ok: false, errors, complete: false };
  for (const id of batch.questionIds) {
    const telemetry = telemetryFor(session, id);
    const prompt = clarificationFor(id, session.drafts[id]);
    if (prompt && telemetry.clarificationCount < 1) {
      telemetry.clarificationCount += 1;
      telemetry.stalled = true;
      append(session, 'user', batch.questionIds.map((qid) => `${getQuestion(qid).title}\n${session.drafts[qid] || '（暂时留白）'}${textOf(extras[qid]).trim() ? `\n补充原话：${textOf(extras[qid])}` : ''}`).join('\n\n'), { questionIds: batch.questionIds, kind: 'clarification-original' });
      append(session, 'assistant', prompt, { questionIds: [id], kind: 'clarification' });
      touch(session);
      return { ok: false, errors: {}, complete: false, clarification: { questionId: id, prompt } };
    }
    if (prompt) telemetry.clarificationUnresolved = true;
  }
  // The scene may appear for the first time in this very submission. Ask once
  // before advancing so that this conditional follow-up cannot disappear.
  if (batch.questionIds.includes('R2-Q2')) {
    const social = getSocialContext({ answers: { ...session.answers, ...session.drafts } });
    const telemetry = telemetryFor(session, 'R2-Q2');
    if (social.status === 'present' && !telemetry.socialFollowUpAsked) {
      telemetry.socialFollowUpAsked = true;
      telemetry.changedRoute = true;
      session.routeLog.push({ questionId: 'R2-Q2', route: 'conditional-follow-up', at: now(), reason: '口述同时提及结伴进行与结果当场可比较，补充一次开放追问。' });
      const prompt = '一起进行的都是谁？这个人在同伴面前最在意什么？可以补充在这题里；暂时不知道也可以说明。';
      append(session, 'user', batch.questionIds.map((id) => `${getQuestion(id).title}\n${session.drafts[id] || '（暂时留白）'}${textOf(extras[id]).trim() ? `\n补充原话：${textOf(extras[id])}` : ''}`).join('\n\n'), { questionIds: batch.questionIds, kind: 'follow-up-original' });
      append(session, 'assistant', prompt, { questionIds: ['R2-Q2'], kind: 'conditional-follow-up' });
      touch(session);
      return { ok: false, errors: {}, complete: false, clarification: { questionId: 'R2-Q2', prompt, kind: 'conditional-follow-up' } };
    }
  }
  const signals = [];
  for (const id of batch.questionIds) {
    session.answers[id] = session.drafts[id];
    const telemetry = telemetryFor(session, id);
    telemetry.skipped = !session.answers[id].trim();
    telemetry.volunteeredExtra = textOf(extras[id]);
    signals.push(applySignal(session, id, session.answers[id]));
    delete session.drafts[id];
    if (session.extraDrafts) delete session.extraDrafts[id];
  }
  append(session, 'user', batch.questionIds.map((id) => `${getQuestion(id).title}\n${session.answers[id] || '（暂时留白）'}${textOf(extras[id]).trim() ? `\n补充原话：${textOf(extras[id])}` : ''}`).join('\n\n'), { questionIds: batch.questionIds, batchId: batch.id });
  if (batch.questionIds.includes('R0-Q2')) {
    const stage = session.answers['R0-Q2'];
    const routeText = stage
      .replace(/(?:不是|并非|并不是|不只是)[^，。；!?！？\n]{0,8}(?:想法|还没落地|没做出来)/g, '')
      .replace(/(?:不是|并非|并不是|还不是)[^，。；!?！？\n]{0,8}(?:已经做出来|已经做好|已有样品|已经完成|已经落地|已经上市)/g, '');
    const made = /已经(?:做出来|做出|做好|在卖|有样品|生产)|(?:样品|产品)(?:已经|已)?(?:做出来|做好|完成)|准备(?:卖|上市)|已经有(?:产品|成品)|已(?:生产|上市|落地)|做出了?样品|有(?:成品|现货)|正在(?:卖|销售)/.test(routeText)
      && !/还没(?:做出来|落地|做好)|尚未落地|只是想法|有个想法/.test(routeText);
    const previous = session.route;
    session.route = made ? 'made' : 'idea';
    session.batchOrder = batchOrder(made ? MADE_ROUNDS : IDEA_ROUNDS);
    telemetryFor(session, 'R0-Q2').changedRoute = previous !== session.route;
    session.routeLog.push({ questionId: 'R0-Q2', route: session.route, at: now(), reason: made ? '口述产品已做出，先记录市场选择和已有条件。' : stage.trim() ? '按本次阶段口述，先记录购买者与具体时刻。' : '阶段暂未明确，按默认顺序先记录购买者与具体时刻。' });
  }
  const stop = batch.questionIds.includes('R2-Q3') && telemetryFor(session, 'R2-Q3').signal === 'red';
  session.batchIndex += 1;
  if (stop) {
    session.stopReason = 'weak-need';
    telemetryFor(session, 'R2-Q3').changedRoute = true;
    session.routeLog.push({ questionId: 'R2-Q3', route: 'early-report', at: now(), reason: '按口述的“没有它也可以”提前整理事实与待验证问题。' });
  }
  if (stop || session.batchIndex >= session.batchOrder.length) {
    session.complete = true;
    session.report = buildReport(session);
    append(session, 'assistant', stop ? '先把目前说到的事实、还没对上的地方和需要核实的问题整理出来。常规提问到这里。' : '这轮问询已经完成。下面整理事实、还没对上的地方，以及需要核实的问题。', { kind: 'report-ready' });
  } else {
    append(session, 'assistant', '这些信息已记录。我们接着看下一组。', { kind: 'confirmation' });
    appendBatchPrompt(session);
  }
  touch(session);
  return { ok: true, complete: session.complete, signals, stopReason: session.stopReason };
}

export function getProgress(session) {
  const answered = Object.keys(session.answers || {}).filter((id) => getQuestion(id)).length;
  return { answered, total: QUESTIONS.length, percent: Math.round(answered / QUESTIONS.length * 100),
    completedBatches: session.batchIndex, totalBatches: session.batchOrder?.length || ROUND_BATCHES.length };
}

const FEEDBACK_LABELS = {
  valuableQuestion: '哪一题问到了点上？', uselessQuestion: '哪一题问废了 / 该删？',
  missedQuestion: '你会问、但它没问的是什么？', guidance: '引导案例够不够用？哪里看不懂？',
};
export function validateFeedback(feedback = {}) {
  const errors = {};
  for (const [key, label] of Object.entries(FEEDBACK_LABELS)) if (!textOf(feedback[key]).trim()) errors[key] = `请填写：${label}没有也可以写“暂无”。`;
  if (!['产品负责人', '工厂方', '渠道方', '营销人', '其他'].includes(feedback.role)) errors.role = '请选择被试者身份。';
  if (typeof feedback.awareOfTest !== 'boolean') errors.awareOfTest = '请选择是否事先知道这是测试系统。';
  return { ok: !Object.keys(errors).length, errors };
}

export function saveFeedback(session, feedback) {
  if (!session.complete) return { ok: false, errors: { session: '报告生成后再填写本次反馈。' } };
  const result = validateFeedback(feedback);
  if (!result.ok) return result;
  session.feedback = Object.fromEntries([...Object.keys(FEEDBACK_LABELS), 'role', 'awareOfTest'].map((key) => [key, feedback[key]]));
  session.feedback.submittedAt = now();
  touch(session);
  return result;
}

export function exportSessionJSON(session) {
  return JSON.parse(JSON.stringify({ ...session,
    export: { version: ENGINE_VERSION, exportedAt: now(), status: !session.complete ? '问询未完成的草稿' : session.feedback ? '已完成的试跑档案' : '报告已生成，反馈待填写',
      feedbackComplete: Boolean(session.feedback), externalSearchPerformed: false },
    rawTranscript: session.messages, diagnosis: session.report, verificationGaps: session.report?.gaps || [],
    judgments: session.report?.judgments || [],
    perQuestion: QUESTIONS.map((question) => ({ questionId: question.id, question: question.title,
      answer: session.answers[question.id] ?? null, draft: session.drafts[question.id] ?? null,
      extraDraft: session.extraDrafts?.[question.id] ?? null,
      ...telemetryFor(session, question.id) })),
  }));
}

export function exportSessionMarkdown(session) {
  const exported = exportSessionJSON(session);
  const lines = [`# 新品有数 · 试跑档案`, '', `状态：${exported.export.status}`, `版本：${ENGINE_VERSION}`, `会话：${session.id}`, `生成时间：${exported.export.exportedAt}`, '',
    '## 对话全文', ''];
  for (const message of session.messages) lines.push(`### ${message.role === 'user' ? '用户' : '新品有数'} · ${message.at}`, '', message.text, '');
  if (session.report) {
    const report = session.report;
    lines.push('## 诊断报告', '');
    for (const section of report.sections) {
      lines.push(`### ${section.title}`, '');
      if (section.definition) lines.push(section.definition, '');
      if (section.facts) {
        lines.push('用户口述 / 会话记录：', '');
        for (const fact of section.facts) lines.push(`- ${fact.id}［${fact.source} · ${fact.status}］${fact.text}`);
        lines.push('', '外部已查证事实：无。', section.note || '', '');
      }
      if (section.contradictions) lines.push(...(section.contradictions.length ? section.contradictions : [section.note]), '');
      if (section.judgments) for (const card of section.judgments) lines.push(`#### ${card.id} ${card.title}`, '', `判断：${card.judgment}`, `依据：${card.basisFactIds.join('、')}`, `推翻条件：${card.overturnCondition}`, `置信度：${card.confidence}`, '');
      if (section.gaps) for (const gap of section.gaps) lines.push(`- 缺口：${gap.gap}`, `  - 为什么关键：${gap.why}`, `  - 验证动作：${gap.action}`, `  - 判定标准：${gap.criterion}`, '');
      if (section.candidates) for (const candidate of section.candidates) lines.push(`- ${candidate.label}：${candidate.scene}`, `  - 待验证：${candidate.validation}`, '');
      if (section.deferred) lines.push(...section.deferred.map((item) => `- ${item}`), '');
    }
  }
  lines.push('## 四项校正', '');
  if (session.feedback) {
    for (const [key, label] of Object.entries(FEEDBACK_LABELS)) lines.push(`### ${label}`, '', textOf(session.feedback[key]), '');
    lines.push(`身份：${session.feedback.role}`, `事先知情这是测试系统：${session.feedback.awareOfTest ? '是' : '否'}`, '');
  } else lines.push('反馈尚未填写。此档案不能视作已完成的试跑档案。', '');
  lines.push('## 逐题记录', '');
  for (const record of exported.perQuestion) lines.push(`- ${record.questionId}：${record.question}`, `  - 回答：${record.answer ?? '未回答'}`, `  - 未提交回答草稿：${record.draft ?? '未提供'}`, `  - 未提交补充原话：${record.extraDraft ?? '未提供'}`, `  - 卡壳：${record.stalled ? '是' : '否'}；使用引导：${record.usedHelp ? '是' : '否'}；最高引导级别：${record.maxHelpLevel}`, `  - 改变路由：${record.changedRoute ? '是' : '否'}；信号：${record.signal}；暂时留白：${record.skipped ? '是' : '否'}`, `  - 主动补充原话：${record.volunteeredExtra || '未提供'}`, '');
  return lines.join('\n');
}
