import { ENGINE_VERSION, SCENARIOS, QUESTIONS, getQuestion, getSampleAnswers } from './engine-data.js';
import { createSession, getCurrentBatch, setDraft, advanceHelp, submitBatch, getProgress, buildReport, saveFeedback, exportSessionJSON, exportSessionMarkdown } from './inquiry-engine.js';
import { mountHomeVideo } from './hero-video.js';

const $ = selector => document.querySelector(selector);
const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon = name => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const STORAGE_KEY = 'xinpin-youshu-sessions-v3';
const ROUND_LABELS = {R0:'先认识这个想法',R1:'走近一个具体的人',R2:'回到那个真实的时刻',R3:'看看已有的选择',R4:'说说你已有的积累'};
let sessions = [], current = null, legacy = [], autoPlaying = false, operation = 0, toastTimer;
let errors = {}, clarification = null;
try {
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
  if (saved.version === 3 && Array.isArray(saved.sessions)) {
    sessions = saved.sessions.filter(s => s && s.version === ENGINE_VERSION && typeof s.id === 'string' && s.answers && !Array.isArray(s.answers) && Array.isArray(s.messages) && Array.isArray(s.batchOrder));
    current = sessions.find(s => s.id === saved.activeId) || null;
  }
  const old = JSON.parse(localStorage.getItem('xinpin-youshu-projects-v1') || '{}');
  if (Array.isArray(old.projects)) legacy = old.projects.filter(p => p && Array.isArray(p.answers));
} catch { /* Storage is optional; an export remains available. */ }
const homeVideo = mountHomeVideo({root:$('#landing'),video:$('#home-video'),toggle:$('#motion-toggle'),fileInput:$('#video-file'),notify:toast});
$('#messages').insertAdjacentHTML('afterend','<div id="active-round"></div>');
$('#chat-composer-wrap').hidden = true;
for (const id of ['question-assist','example-callout','answer-options','branch-actions','typing']) $(`#${id}`).hidden = true;

function toast(message) {
  clearTimeout(toastTimer); $('#toast').textContent = message; $('#toast').hidden = false;
  toastTimer = setTimeout(() => { $('#toast').hidden = true; }, 3700);
}
function persist() {
  if (current) current.updatedAt = new Date().toISOString();
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify({version:3,activeId:current?.id || null,sessions})); }
  catch { toast('浏览器暂时无法保存。请通过“思考记录”导出当前记录。'); }
  renderRecent();
}
function renderRecent() {
  $('#project-count').textContent = sessions.length + legacy.length;
  $('#recent-projects').innerHTML = sessions.slice().sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt)).slice(0,4).map(s=>`<button class="recent-project ${current?.id===s.id?'selected':''}" data-action="resume" data-id="${escape(s.id)}"><span>${escape(s.title)}</span></button>`).join('') || '<p class="recent-empty">从一个想法开始，<br>把值得确认的问题留下来。</p>';
}
function resizeEntry() {
  const input=$('#entry-input'); input.style.height='auto'; input.style.height=Math.min(input.scrollHeight,150)+'px';
  $('#entry-form .send-button').disabled=!input.value.trim();
}
function focusRound() {
  requestAnimationFrame(()=>$('#active-round').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'}));
}
function renderMessage(message) {
  if (message.role==='assistant' && message.batchId===getCurrentBatch(current)?.id && message.questionIds?.length) return '';
  if (message.role==='user') return `<div class="message user-message">${escape(message.text)}</div>`;
  return `<div class="message assistant-message"><span class="assistant-avatar">${icon('helix')}</span><div class="message-content"><div class="message-author">新品有数<small>YOUR THINKING PARTNER</small></div><p>${escape(message.text)}</p></div></div>`;
}
function questionBlock(q) {
  const t=current.questionTelemetry[q.id] || {}, level=t.maxHelpLevel || 0;
  return `<div class="question-block" data-question="${q.id}"><label class="question-label" for="answer-${q.id}">${escape(q.title)}</label><p class="question-body">${escape(q.body)}</p>${clarification?.questionId===q.id?`<p class="batch-error" role="status">${escape(clarification.prompt)}</p>`:''}<textarea class="question-answer" id="answer-${q.id}" name="${q.id}" data-draft="${q.id}" rows="3" maxlength="12000" aria-invalid="${Boolean(errors[q.id])}" placeholder="用自己的话说，知道多少说多少。" ${autoPlaying?'disabled':''}>${escape(current.drafts[q.id] ?? '')}</textarea>${errors[q.id]?`<p class="batch-error" role="alert">${escape(errors[q.id])}</p>`:''}${level>=1?`<div class="question-example"><span>换个具体的例子</span><p>${escape(q.example)}</p></div>`:''}${level>=2?`<div class="question-options" aria-label="回答方向">${q.options.map(o=>`<button type="button" data-action="pick-option" data-qid="${q.id}" data-value="${escape(o)}">${escape(o)}</button>`).join('')}</div>`:''}<div class="question-help-count">${level<3?`<button class="help-button" type="button" data-action="help-next" data-qid="${q.id}">${icon('light')}${['不知道怎么说？先看一个例子','还是没思路，看看选项','仍说不清？这题可以先留白'][level]}</button>`:'<p class="question-skip">这题可以留空继续。它会作为待补充信息保留。</p>'}</div><details class="extra-toggle" ${current.extraDrafts?.[q.id]?'open':''}><summary>还有一句想补充的原话</summary><label class="visually-hidden" for="extra-${q.id}">补充原话</label><textarea class="extra-answer" id="extra-${q.id}" data-extra="${q.id}" maxlength="12000" rows="2" placeholder="可选。这里会完整保留你的补充。">${escape(current.extraDrafts?.[q.id] || '')}</textarea></details></div>`;
}
function renderRound() {
  const batch=getCurrentBatch(current);
  if (!batch || current.complete) { $('#active-round').innerHTML=''; return; }
  $('#active-round').innerHTML=`<form id="round-form" class="round-card" novalidate><div class="round-eyebrow">${escape(ROUND_LABELS[batch.round])}<span>本轮 ${batch.questions.length} 个问题</span></div><h2 class="round-title">${escape(batch.round==='R0'?'先从你最确定的地方说起。':'想到什么就说什么。')}</h2>${batch.questions.map(questionBlock).join('')}${(batch.followUps || []).map(f=>`<div class="signal-note"><label for="follow-${escape(f.questionId)}">${escape(f.prompt)}</label><textarea id="follow-${escape(f.questionId)}" class="extra-answer" data-extra="${escape(f.questionId)}" rows="2" maxlength="12000">${escape(current.extraDrafts?.[f.questionId] || '')}</textarea></div>`).join('')}<div class="round-actions"><button type="button" class="secondary-action" data-action="sample-batch">填入人参示例</button><button type="submit" class="batch-submit" ${autoPlaying?'disabled':''}>记下，继续聊${icon('arrow-right')}</button></div><div class="round-actions"><span class="privacy-note">${autoPlaying?'人参案例演示中 · 可随时暂停':'输入自动保存 · 先记录信息，判断放在报告里'}</span><button class="text-button" type="button" data-action="auto-demo">${autoPlaying?'暂停演示':'人参案例完整演示'}</button></div></form>`;
}
function renderNote() {
  const progress=getProgress(current);
  $('#progress-value').textContent=`${progress.answered} / ${progress.total}`;
  $('#progress-label').textContent=current.complete?'本次问询已整理':'已经聊到的问题';
  $('#progress-bar').style.width=progress.percent+'%';
  const highlights=[['R0-Q1','你想做的产品'],['R1-Q1','具体购买者'],['R2-Q1','购买前的画面'],['R2-Q2','实际发生的时刻'],['R4-Q1','已有的积累']];
  $('#captured-notes').innerHTML=highlights.filter(([id])=>current.answers[id] && current.answers[id]!=='待补充').map(([id,label])=>`<div class="captured-note"><span>${label}</span><p>${escape(current.answers[id])}</p></div>`).join('') || '<p class="note-placeholder">这里保留你的原话。<br>尚未核实的信息，会保持待验证。</p>';
  $('.note-description').textContent='先保留原话，再核实依据。';
  $('.note-foot p').innerHTML='一次聊清一小部分。<br>没有答案，也是一条记录。';
}
function factCard(f) {
  return `<article class="fact-card"><span class="fact-tag">${escape(f.id)} · ${escape(f.source || '用户口述')} · ${escape(f.status || '待验证')}</span><p>${escape(f.text ?? f.statement ?? f.content)}</p></article>`;
}
function judgmentCard(j) {
  return `<article class="judgment-card"><span class="fact-tag">${escape(j.id)} · 当前判断</span><h4>${escape(j.judgment)}</h4><p>依据：${(j.basisFactIds || []).map(id=>`<a href="#fact-${escape(id)}">${escape(id)}</a>`).join('、') || '尚无足够事实'}</p><p><strong>什么会推翻它</strong><br>${escape(j.overturnCondition)}</p><div class="judgment-meta">置信度：${escape(j.confidence)} · 仍需外部证据</div></article>`;
}
function renderDiagnosis() {
  const report=current.report || buildReport(current);
  const sections=report.sections;
  const content=sections.map((s,index)=>{
    let body='';
    if(index===0) body=`<p class="report-definition">${escape(s.definition || report.definition)}</p>`;
    if(index===1) body=`<p class="privacy-note">用户口述与演示内容，尚未独立核实。未接入外部搜索，本次没有外部验证事实。</p>${(s.facts || report.facts || []).map(f=>`<div id="fact-${escape(f.id)}">${factCard(f)}</div>`).join('')}`;
    if(index===2) body=`${(s.contradictions || []).length?(s.contradictions || []).map(c=>`<p class="signal-note">${escape(typeof c==='string'?c:c.text || c.description)}</p>`).join(''):'<p>目前没有足够信息确认明确矛盾，后续仍需核对。</p>'}${(s.judgments || report.judgments || []).map(judgmentCard).join('')}`;
    if(index===3) body=(s.gaps || report.gaps || []).map((g,i)=>`<article class="gap-card"><span>0${i+1}</span><div><h4>${escape(g.gap)}</h4><p><strong>为什么关键</strong> ${escape(g.why)}</p><p><strong>怎么查</strong> ${escape(g.action)}</p><p><strong>成立与推翻标准</strong> ${escape(g.criterion)}</p></div></article>`).join('');
    if(index===4) body=(s.candidates || report.candidates || []).map(c=>`<article class="candidate-card"><h4>${escape(typeof c==='string'?c:c.label || c.title || c.scenario || c.entry)}</h4>${typeof c==='object'?`<p>${escape(c.scene || '')}</p><p>${escape(c.condition || c.validation || c.description)}</p>`:''}</article>`).join('')+'<p class="privacy-note">这些是需要验证的候选切口，不是最终产品选择。</p>';
    if(index===5) body=`<ul>${(s.deferred || report.deferred || []).map(d=>`<li>${escape(typeof d==='string'?d:d.decision || d.text)}</li>`).join('')}</ul>`;
    return `<section class="report-section" aria-labelledby="section-${index+1}"><div class="report-section-heading"><span class="report-number">0${index+1}</span><h3 id="section-${index+1}">${escape(s.title)}</h3></div>${body}</section>`;
  }).join('');
  $('#diagnosis').innerHTML=`<div class="report-intro"><div class="round-eyebrow">YOUR IDEA, A LITTLE CLEARER</div><h2>把下一步，放在证据上。</h2><p>${escape(current.title)}</p><p class="privacy-note">${current.stopReason?'本次先整理已经聊到的信息，未完成的部分保留为空。':'本次问询已整理。报告中的判断可被新证据推翻。'}</p></div><div class="report-grid">${content}</div><div class="feedback-banner">${current.feedback?.submittedAt?'<strong>你的反馈已收好。</strong><span>这次记录已包含完整反馈，可以导出归档。</span>':'<strong>最后，请帮这次问询做一次校正。</strong><span>四个简短问题，帮助发现问询遗漏的地方。</span>'}<button class="secondary-action" data-action="feedback">${current.feedback?.submittedAt?'查看或修改反馈':'填写本次反馈'}</button></div><div class="report-toolbar"><button class="export-button" data-action="export-md">${icon('download')}导出 Markdown</button><button class="export-button" data-action="export-json">导出 JSON</button><button class="export-button" data-action="print-report">打印 / 保存 PDF</button><button class="text-button" data-action="notes">完整对话</button></div>`;
}
function render() {
  const inChat=Boolean(current);
  document.body.dataset.view=inChat?'chat':'landing';
  $('meta[name="theme-color"]').content=inChat?'#f5f7fa':'#090c12';
  $('#landing').hidden=inChat; $('#conversation').hidden=!inChat; homeVideo.setVisible(!inChat);
  $('#breadcrumb-current').textContent=inChat?current.title:'新品问询'; renderRecent();
  if (!inChat) return;
  $('#chat-project-label').textContent=current.title;
  $('#messages').innerHTML=current.messages.map(renderMessage).join('');
  renderRound(); renderNote(); $('#diagnosis').hidden=!current.complete;
  if(current.complete) renderDiagnosis();
  if(globalThis.__INQUIRY_DEBUG__) {
    globalThis.__INQUIRY_DEBUG_SESSION__=current;
    document.dispatchEvent(new CustomEvent('xinpin-session',{detail:current}));
  }
}
function start(scenarioId='idea',{opening='',custom=false}={}) {
  operation++; autoPlaying=false; errors={}; clarification=null;
  current=createSession({scenarioId,opening,custom});
  if(!custom && /人参|长白山/.test(opening))current.title='长白山人参 · 精力补充新品';
  sessions.unshift(current);
  $('#entry-input').value=''; document.body.classList.remove('menu-open');
  persist(); render(); window.scrollTo(0,0);
}
function goHome() {
  operation++; autoPlaying=false; current=null; errors={}; clarification=null;
  document.body.classList.remove('menu-open'); persist(); render(); window.scrollTo(0,0); resizeEntry();
}
function submitCurrent(answers,extras={}) {
  if(!current || current.complete)return;
  const result=submitBatch(current,answers,{extras}); errors=result.errors || {}; clarification=result.clarification || null;
  persist(); render();
  if(result.ok && current.complete) {
    requestAnimationFrame(()=>$('#diagnosis').scrollIntoView({block:'start',behavior:'instant'}));
    if(!current.feedback?.submittedAt) openFeedback();
  } else if(result.ok) focusRound();
  else requestAnimationFrame(()=>{ const qid=clarification?.questionId || Object.keys(errors)[0]; if(qid)$(`#answer-${qid}`)?.focus({preventScroll:false}); });
  return result;
}
async function runDemo(fresh=false) {
  if(autoPlaying) { autoPlaying=false;operation++;render();toast('已暂停，当前回答和草稿已保留。');return; }
  if(fresh || !current || current.complete || current.custom) start('idea');
  autoPlaying=true; const token=++operation, id=current.id; render();
  while(autoPlaying && token===operation && current?.id===id && !current.complete) {
    await new Promise(resolve=>setTimeout(resolve,550));
    if(!autoPlaying || token!==operation || current?.id!==id)break;
    const batch=getCurrentBatch(current); if(!batch)break;
    const answers=getSampleAnswers(current.scenarioId,batch.questionIds);
    const result=submitCurrent(answers);
    if(!result?.ok) { autoPlaying=false;toast('示例已暂停，可以在当前问题补充。');break; }
  }
  if(token===operation) {autoPlaying=false; render();}
}
function openDialog(content) {
  $('#dialog-content').innerHTML=content;
  if(!$('#app-dialog').open)$('#app-dialog').showModal();
  document.body.classList.remove('menu-open');
}
function openFeedback() {
  if(!current?.complete)return;
  const f=current.feedbackDraft || current.feedback || {};
  const fields=[['valuableQuestion','哪一问对你最有价值？'],['uselessQuestion','哪一问没用，或者可以删掉？'],['missedQuestion','如果由你来问，还有哪一问是这里漏掉的？'],['guidance','引导案例够用吗？哪里仍不好理解？']];
  openDialog(`<h2 class="dialog-title">用你的反馈，校正这次问询。</h2><p class="dialog-subtitle">四个问题都请留下一句话。“暂时没有”也可以。反馈会和本次完整记录一起保存。</p><form id="feedback-form" class="feedback-form"><div class="feedback-field"><label for="feedback-role">你的角色 <span>必填</span></label><select id="feedback-role" name="role" required><option value="">请选择</option>${['产品负责人','工厂方','渠道方','营销人','其他'].map(r=>`<option ${f.role===r?'selected':''}>${r}</option>`).join('')}</select></div><fieldset class="feedback-field feedback-options"><legend>体验之前，你知道这是一个测试系统吗？</legend>${[[true,'知道'],[false,'不知道']].map(([v,label])=>`<label><input type="radio" name="awareOfTest" value="${v}" required ${f.awareOfTest===v?'checked':''}/> ${label}</label>`).join('')}</fieldset>${fields.map(([name,label])=>`<div class="feedback-field"><label for="feedback-${name}">${label} <span>必填</span></label><textarea id="feedback-${name}" name="${name}" rows="2" maxlength="12000" required>${escape(f[name] || '')}</textarea></div>`).join('')}<p id="feedback-error" class="batch-error" role="alert"></p><div class="feedback-actions"><button type="button" class="secondary-action" data-action="close-dialog">先阅读报告</button><button type="submit" class="batch-submit">保存反馈${icon('check')}</button></div></form>`);
}
function openHelp() {
  openDialog(`<h2 class="dialog-title">做到产品上市前心里有数。</h2><p class="dialog-subtitle">从一个想法，走向一个可以验证的问题。<br>New products measured, innovation in control</p><div class="help-grid"><div class="help-card"><span>01 / A REAL QUESTION</span><h3>一次最多三个问题</h3><p>先讲是什么，再走近具体的人、购买前的画面、真实选择和已有积累。</p></div><div class="help-card"><span>02 / TAKE YOUR TIME</span><h3>想不清，就逐步展开</h3><p>先看案例，再看选项，最后才留白。每一次卡住，也会成为待核实的线索。</p></div><div class="help-card"><span>03 / FOLLOW THE EVIDENCE</span><h3>带走六段问题报告</h3><p>分清口述、矛盾与验证缺口。判断附依据、推翻条件和置信度，最后留下你的反馈。</p></div></div><div class="dialog-note">当前是按你提供的规格运行的规则版演示，支持自由输入、流程分支和记录。尚未连接大模型、外部搜索或额外知识库；口述与人参示例均待验证，不构成市场或功效结论。</div><div class="dialog-buttons"><button class="primary-action" data-action="help-start">开始我的问询${icon('arrow-right')}</button><button class="secondary-action" data-action="demo">体验人参完整案例</button></div>`);
}
function openProjects() {
  const items=sessions.slice().sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt));
  openDialog(`<h2 class="dialog-title">每个想法，都有自己的位置。</h2><p class="dialog-subtitle">已保存 ${items.length} 次新版问询。草稿与反馈都会留在当前浏览器。</p><div class="project-list">${items.map(s=>`<button class="project-card" data-action="resume" data-id="${escape(s.id)}"><span class="project-card-icon">${icon(s.complete?'note':'chat')}</span><span><h3>${escape(s.title)}</h3><p>${getProgress(s).answered} 条回答 · ${new Date(s.createdAt).toLocaleDateString('zh-CN')}</p></span><span class="project-end">${s.complete?(s.feedback?.submittedAt?'已归档':'待反馈'):'继续聊聊 →'}</span></button>`).join('') || '<p class="empty-state">开始一段问询后，记录会出现在这里。</p>'}</div>${legacy.length?`<div class="dialog-note">保留了 ${legacy.length} 条旧版记录。旧记录保持原样，可下载备份。</div><button class="secondary-action" data-action="legacy-export">下载旧版记录 JSON</button>`:''}<div class="dialog-buttons"><button class="primary-action" data-action="help-start">${icon('plus')}开启新的问询</button></div>`);
}
function openNotes() {
  const s=current || sessions[0];
  if(!s){openProjects();return;}
  openDialog(`<h2 class="dialog-title">完整原话，留在这里。</h2><p class="dialog-subtitle">${escape(s.title)} · ${s.complete?'报告已生成':'尚在问询中，导出为草稿'} · ${s.feedback?.submittedAt?'已含反馈':'反馈待填写'}</p><div class="record-list">${s.messages.map(m=>`<div class="record-item"><h3>${m.role==='user'?'你':'新品有数'}</h3><p>${escape(m.text)}</p></div>`).join('')}</div><div class="dialog-buttons"><button class="primary-action" data-action="draft-json" data-id="${escape(s.id)}">导出完整记录 JSON</button><button class="secondary-action" data-action="draft-md" data-id="${escape(s.id)}">导出 Markdown</button></div>`);
}
function download(content,filename,type) {
  const url=URL.createObjectURL(new Blob([content],{type})), link=document.createElement('a');
  link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
}
function exportFile(format,{draft=false,id}={}) {
  const s=id?sessions.find(item=>item.id===id):current; if(!s)return;
  if(s.complete && !s.feedback?.submittedAt && !draft){toast('先留下四项反馈，再导出完整归档。也可以从思考记录导出当前草稿。');openFeedback();return;}
  const suffix=s.feedback?.submittedAt?'完整记录':'草稿';
  if(format==='json') download(JSON.stringify(exportSessionJSON(s),null,2),`新品有数_${suffix}.json`,'application/json;charset=utf-8');
  else download(exportSessionMarkdown(s),`新品有数_${suffix}.md`,'text/markdown;charset=utf-8');
  toast('已准备好下载，本次原话和反馈会完整保留。');
}

document.addEventListener('click',async event=>{
  const el=event.target.closest('[data-action]'); if(!el)return;
  event.preventDefault(); const action=el.dataset.action;
  if(action==='focus-entry'){$('#entry-input').focus({preventScroll:true});return;}
  if(action==='choose-video'){homeVideo.chooseFile();return;}
  if(action==='menu'){document.body.classList.add('menu-open');return;}
  if(action==='close-menu'){document.body.classList.remove('menu-open');return;}
  if(action==='close-dialog'){$('#app-dialog').close();return;}
  if(action==='new'||action==='home'){goHome();return;}
  if(action==='help'){openHelp();return;}
  if(action==='projects'){openProjects();return;}
  if(action==='notes'){openNotes();return;}
  if(action==='scenario'){const scenario=SCENARIOS.find(s=>s.id===el.dataset.scenario);start(scenario?.id || 'idea',{opening:scenario?.answers[0] || ''});return;}
  if(action==='demo'){$('#app-dialog').close();await runDemo(true);return;}
  if(action==='auto-demo'){await runDemo();return;}
  if(action==='help-start'){$('#app-dialog').close();goHome();$('#entry-input').focus();return;}
  if(action==='resume') {const s=sessions.find(p=>p.id===el.dataset.id);if(!s)return;operation++;autoPlaying=false;errors={};clarification=null;current=s;$('#app-dialog').close();document.body.classList.remove('menu-open');persist();render();if(current.complete){$('#diagnosis').scrollIntoView();if(!current.feedback?.submittedAt)openFeedback();}else focusRound();return;}
  if(action==='inspire'){$('#entry-input').value=SCENARIOS[0].answers[0];resizeEntry();$('#entry-input').focus();return;}
  if(action==='profile'){openDialog('<h2 class="dialog-title">白雪的工作空间</h2><p class="dialog-subtitle">问询记录保存在当前浏览器。你可以在“思考记录”里导出 Markdown 和 JSON，保留原话、路径与反馈。</p><div class="dialog-note">规则版交互演示 · 未连接大模型或外部研究服务。清除浏览器数据前，请先导出重要记录。</div>');return;}
  if(action==='legacy-export'){download(JSON.stringify({version:1,projects:legacy},null,2),'新品有数_旧版记录.json','application/json');return;}
  if(action==='feedback'){openFeedback();return;}
  if(action==='export-md'||action==='export-json'){exportFile(action.endsWith('json')?'json':'md');return;}
  if(action==='draft-md'||action==='draft-json'){exportFile(action.endsWith('json')?'json':'md',{draft:true,id:el.dataset.id});return;}
  if(action==='print-report'){if(!current?.feedback?.submittedAt){openFeedback();return;}window.print();return;}
  if(!current || current.complete || autoPlaying)return;
  const batch=getCurrentBatch(current);
  if(action==='help-next'){advanceHelp(current,el.dataset.qid);persist();renderRound();return;}
  if(action==='pick-option'){setDraft(current,el.dataset.qid,el.dataset.value);persist();renderRound();$(`#answer-${el.dataset.qid}`).focus({preventScroll:true});return;}
  if(action==='sample-batch') {if(current.custom){toast('人参示例属于演示内容，会替换当前轮草稿，不代表你的产品。');}const answers=getSampleAnswers(current.scenarioId,batch.questionIds);for(const [id,value]of Object.entries(answers))setDraft(current,id,value);persist();renderRound();return;}
});
document.addEventListener('input',event=>{
  const el=event.target;
  if(el.dataset.draft && current){setDraft(current,el.dataset.draft,el.value);persist();}
  if(el.dataset.extra && current){current.extraDrafts ||= {};current.extraDrafts[el.dataset.extra]=el.value;persist();}
  if(el.closest('#feedback-form') && current){const data=new FormData($('#feedback-form'));current.feedbackDraft=Object.fromEntries(data);if(data.has('awareOfTest'))current.feedbackDraft.awareOfTest=data.get('awareOfTest')==='true';persist();}
});
document.addEventListener('submit',event=>{
  if(event.target.id==='round-form') {event.preventDefault();if(autoPlaying)return;const batch=getCurrentBatch(current),data=new FormData(event.target);submitCurrent(Object.fromEntries(batch.questionIds.map(id=>[id,String(data.get(id) || '')])),current.extraDrafts || {});}
  if(event.target.id==='feedback-form') {event.preventDefault();const data=new FormData(event.target),f=Object.fromEntries(data);f.awareOfTest=data.has('awareOfTest')?data.get('awareOfTest')==='true':undefined;const result=saveFeedback(current,f);if(!result.ok){$('#feedback-error').textContent=Object.values(result.errors || {}).join('；');return;}current.feedbackDraft=null;persist();$('#app-dialog').close();renderDiagnosis();toast('反馈和完整问询记录已保存。');}
});
$('#entry-form').addEventListener('submit',event=>{event.preventDefault();const opening=$('#entry-input').value.trim();if(opening)start('idea',{opening,custom:!(/人参|长白山/.test(opening))});});
$('#entry-input').addEventListener('input',resizeEntry);
$('#entry-input').addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();$('#entry-form').requestSubmit();}});
document.addEventListener('keydown',event=>{if(event.key==='Escape')document.body.classList.remove('menu-open');if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='k'){event.preventDefault();$('#app-dialog').close();goHome();$('#entry-input').focus();}});
$('#app-dialog').addEventListener('click',event=>{if(event.target===$('#app-dialog')){const r=event.target.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)event.target.close();}});
render();resizeEntry();
if(current?.complete && !current.feedback?.submittedAt)openFeedback();
