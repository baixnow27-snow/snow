/** Decorative media stays separate from the product conversation. */
export function mountHomeVideo({ root, video, toggle, fileInput, notify = () => {} }) {
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  let homeVisible = false;
  let wantsMotion = !motionPreference.matches;
  let localUrl = null;
  let loadFailed = false;
  let dragDepth = 0;
  let playAttempt = 0;

  video.muted = true;
  video.defaultMuted = true;
  video.loop = true;
  video.playsInline = true;

  function updateControl() {
    const playing = !video.paused && !video.ended && video.readyState >= 2;
    toggle.setAttribute('aria-label', playing ? '暂停背景视频' : '播放背景视频');
    toggle.setAttribute('aria-pressed', String(!playing));
    toggle.innerHTML = `<svg class="icon" aria-hidden="true"><use href="#i-${playing ? 'pause' : 'play'}"/></svg><span>${playing ? '暂停动效' : '播放动效'}</span>`;
  }

  async function synchronize() {
    const thisAttempt = ++playAttempt;
    if (!homeVisible || document.hidden || !wantsMotion) {
      video.pause();
      updateControl();
      return;
    }
    if (!video.getAttribute('src')) {
      video.src = video.dataset.videoSrc;
      video.load();
    }
    try {
      await video.play();
      if (thisAttempt !== playAttempt) return;
      if (!homeVisible || document.hidden || !wantsMotion) video.pause();
    } catch {
      // A poster remains visible when autoplay or the external URL is unavailable.
    }
    updateControl();
  }

  function selectLocalVideo(file) {
    if (!file) return;
    if (!file.type.startsWith('video/') && !/\.(mp4|webm|mov)$/i.test(file.name)) {
      notify('请选择 MP4 或 WebM 视频。');
      return;
    }
    ++playAttempt;
    video.pause();
    if (localUrl) URL.revokeObjectURL(localUrl);
    localUrl = URL.createObjectURL(file);
    loadFailed = false;
    root.classList.remove('video-ready', 'video-unavailable', 'is-dragging');
    video.src = localUrl;
    video.load();
    wantsMotion = true;
    synchronize();
    notify('已换成你的视频，开始新的思考吧。');
  }

  video.addEventListener('loadeddata', () => {
    loadFailed = false;
    root.classList.add('video-ready');
    root.classList.remove('video-unavailable');
    updateControl();
  });
  video.addEventListener('error', () => {
    loadFailed = true;
    root.classList.remove('video-ready');
    root.classList.add('video-unavailable');
    updateControl();
  });
  for (const event of ['play', 'playing', 'pause', 'ended']) video.addEventListener(event, updateControl);
  toggle.addEventListener('click', () => {
    if (video.paused) {
      wantsMotion = true;
      if (loadFailed) {
        loadFailed = false;
        video.load();
      }
    } else wantsMotion = false;
    synchronize();
  });
  fileInput.addEventListener('change', () => { selectLocalVideo(fileInput.files?.[0]); fileInput.value = ''; });
  document.addEventListener('visibilitychange', synchronize);
  motionPreference.addEventListener('change', () => { wantsMotion = !motionPreference.matches; synchronize(); });
  root.addEventListener('dragenter', event => {
    if (!event.dataTransfer?.types.includes('Files')) return;
    event.preventDefault();
    dragDepth++;
    root.classList.add('is-dragging');
  });
  root.addEventListener('dragover', event => {
    if (!event.dataTransfer?.types.includes('Files')) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  root.addEventListener('dragleave', event => {
    event.preventDefault();
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) root.classList.remove('is-dragging');
  });
  root.addEventListener('drop', event => {
    event.preventDefault();
    dragDepth = 0;
    root.classList.remove('is-dragging');
    selectLocalVideo(event.dataTransfer?.files?.[0]);
  });
  window.addEventListener('pagehide', event => { video.pause(); if (!event.persisted && localUrl) URL.revokeObjectURL(localUrl); });
  window.addEventListener('pageshow', synchronize);
  updateControl();

  return {
    setVisible(value) { homeVisible = value; synchronize(); },
    chooseFile() { fileInput.click(); },
  };
}
