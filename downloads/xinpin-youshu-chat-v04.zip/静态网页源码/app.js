import { ENGINE_VERSION, SCENARIOS, QUESTIONS, getQuestion, getSampleAnswers } from './engine-data.js';
import { createChatSession, upgradeToChat, getCurrentQuestion, getChatTurns, submitChatAnswer, reviseChatAnswer, getReviewQuestions, setDraft, advanceHelp, getProgress, buildReport, saveFeedback, exportSessionJSON, exportSessionMarkdown } from './inquiry-engine.js';
import { inferCategory, getGuidance, getCategoryChoices } from './matched-guidance.js';
import { mountHomeVideo } from './hero-video.js';

const $=selector=>document.querySelector(selector);
const escape=value=>String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=name=>`<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const STORAGE_KEY='xinpin-youshu-sessions-v3';
const ROUND_LABELS={R0:'先聊聊你的想法',R1:'说说会买的那个人',R2:'回到真实发生的时刻',R3:'看看他已有的选择',R4:'聊聊你手里的条件'};
let sessions=[],current=null,legacy=[],autoPlaying=false,operation=0,toastTimer;
let errors={},editError='';
try {
  const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}');
  if(saved.version===3 && Array.isArray(saved.sessions)){
    sessions=saved.sessions.filter(s=>s && s.version===ENGINE_VERSION && typeof s.id==='string' && s.answers && !Array.isArray(s.answers) && Array.isArray(s.messages) && Array.isArray(s.batchOrder));
    sessions.forEach(upgradeToChat);current=sessions.find(s=>s.id===saved.activeId)||null;
  }
  const old=JSON.parse(localStorage.getItem('xinpin-youshu-projects-v1')||'{}');
  if(Array.isArray(old.projects))legacy=old.projects.filter(p=>p && Array.isArray(p.answers));
}catch { /* A new conversation remains usable when storage is unavailable. */ }
const homeVideo=mountHomeVideo({root:$('#landing'),video:$('#home-video'),toggle:$('#motion-toggle'),fileInput:$('#video-file'),notify:toast});
for(const id of ['question-assist','example-callout','answer-options','branch-actions','typing'])$(`#${id}`).hidden=true;
$('#chat-form .composer-bottom').innerHTML=`<div class="composer-tools"><button type="button" class="chat-help" data-action="help-next">${icon('light')}不知道怎么答</button><button type="button" class="chat-category" data-action="category">换一个例子</button></div><div class="send-area"><button type="button" class="chat-skip" data-action="skip-answer" hidden>这题先留白</button><button class="send-button" type="submit" aria-label="发送回答" disabled>${icon('arrow')}</button></div>`;
$('#chat-composer-wrap .chat-footer').innerHTML='<span><span class="auto-save-dot"></span>聊天与草稿自动保存</span><button class="sample-answer" data-action="sample-answer">填入人参示例</button><button class="quick-demo" data-action="auto-demo">人参案例演示</button>';
$('.note-description').textContent='你的原话，会一直留在这里。';

function toast(message){clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').hidden=false;toastTimer=setTimeout(()=>{$('#toast').hidden=true;},3800);}
function persist(){if(current)current.updatedAt=new Date().toISOString();try{localStorage.setItem(STORAGE_KEY,JSON.stringify({version:3,activeId:current?.id||null,sessions}));}catch{toast('浏览器暂时无法保存，可以在“思考记录”里导出当前聊天。');}renderRecent();}
function renderRecent(){
  $('#project-count').textContent=sessions.length+legacy.length;
  $('#recent-projects').innerHTML=sessions.slice().sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt)).slice(0,4).map(s=>`<button class="recent-project ${current?.id===s.id?'selected':''}" data-action="resume" data-id="${escape(s.id)}"><span>${escape(s.title)}</span></button>`).join('')||'<p class="recent-empty">从一个想法开始，<br>我们慢慢聊清楚。</p>';
}
function resizeInput(input){input.style.height='auto';input.style.height=Math.min(input.scrollHeight,input.id==='chat-input'?180:150)+'px';input.closest('form').querySelector('.send-button').disabled=!input.value.trim() || (input.id==='chat-input' && autoPlaying);}
function scrollLatest(instant=false){requestAnimationFrame(()=>window.scrollTo({top:document.documentElement.scrollHeight,behavior:instant||matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'}));}
function keepTurnPosition(qid,action){const node=document.querySelector(`[data-turn-id="${qid}"]`),before=node?.getBoundingClientRect().top;action();requestAnimationFrame(()=>{const next=document.querySelector(`[data-turn-id="${qid}"]`);if(before!==undefined && next)window.scrollBy(0,next.getBoundingClientRect().top-before);});}
function pauseDemo(){if(autoPlaying){autoPlaying=false;operation++;}}
function renderEditor(turn){
  const d=current.editDraft,q=turn.question || getQuestion(turn.questionId);
  return `<form id="edit-answer-form" class="inline-answer-editor" data-qid="${q.id}" novalidate><label for="edited-answer">${d.mode==='append'?'给这条回答补充一点':'修改这条回答'}</label><textarea id="edited-answer" name="editedAnswer" data-edit-draft rows="4" maxlength="12000" placeholder="${d.mode==='append'?'把刚想到的内容补在这里……':'用你现在更准确的说法……'}">${escape(d.text)}</textarea><p class="edit-reason">${current.complete?'保存后，问题报告会按最新回答更新。':'保存后会继续保留前面的对话。'}</p>${editError?`<p class="batch-error" role="alert">${escape(editError)}</p>`:''}<div class="editor-actions"><button type="button" class="secondary-action" data-action="cancel-edit">取消</button><button type="submit" class="primary-action">保存${d.mode==='append'?'补充':'修改'}</button></div></form>`;
}
function renderGuidance(q){
  const level=current.questionTelemetry[q.id]?.maxHelpLevel || 0, guidance=getGuidance(current,q.id),rephrase=current.rephrasedQuestionIds?.includes(q.id);
  if(!level && !rephrase)return '';
  return `<div class="chat-guidance">${rephrase?`<p class="guidance-intro"><strong>换个说法</strong><br>${escape(guidance.simpleExplanation)}</p>`:''}${level>=1?`<div class="guidance-example"><span>${escape(guidance.categoryLabel)} · ${escape(guidance.productName)}</span><p class="guidance-intro">${escape(guidance.productIntro)}</p><p>${escape(guidance.example)}</p><button type="button" class="text-button" data-action="category">换一个我熟悉的例子</button></div>`:''}${level>=2?`<div class="guidance-options" aria-label="可以从这些方向说起">${guidance.options.map(o=>`<button type="button" data-action="pick-option" data-value="${escape(o)}">${escape(o)}</button>`).join('')}</div>`:''}${level>=3?'<p class="turn-status">这题可以先留白，之后仍能回来补充。</p>':''}</div>`;
}
function historicalGuidance(qid){
  const messages=current.messages.filter(m=>m.role==='assistant' && m.questionIds?.includes(qid) && (m.helpLevel || m.kind==='question-rephrase'));
  return messages.length?`<details class="past-guidance"><summary>回看当时的解释和例子</summary>${messages.map(m=>`<p>${escape(m.text)}</p>`).join('')}</details>`:'';
}
function renderChatTurn(turn){
  const q=turn.question || getQuestion(turn.questionId);if(!q)return '';
  const answered=turn.answered ?? Object.hasOwn(current.answers,q.id),active=getCurrentQuestion(current)?.id===q.id;
  const answer=answered?current.answers[q.id] ?? turn.answer:turn.pendingAnswer;
  const extra=turn.extra || current.questionTelemetry[q.id]?.volunteeredExtra || '';
  const edited=(current.answerRevisions || []).some(r=>(r.questionId || r.qid)===q.id);
  const hasAnswer=answered || Boolean(answer);
  return `<article class="chat-turn ${active?'is-current':''}" data-turn-id="${q.id}"><div class="message assistant-message"><span class="assistant-avatar">${icon('helix')}</span><div class="message-content"><div class="message-author">新品有数<small>YOUR THINKING PARTNER</small></div><span class="turn-kicker">${escape(ROUND_LABELS[q.round])}</span><h2 class="turn-question">${escape(q.title)}</h2><p class="turn-description">${escape(q.body)}</p>${active?`<button type="button" class="text-button turn-rephrase" data-action="rephrase">这句话怎么理解？</button>${renderGuidance(q)}`:historicalGuidance(q.id)}</div></div>${hasAnswer?`<div class="message user-message"><p class="answer-text">${escape(answer || '这题先留白，之后再补充。')}</p>${extra?`<p class="answer-extra">补充原话：${escape(extra)}</p>`:''}${answered?`<div class="answer-actions">${edited?'<span class="edited-mark">已更新</span>':''}<button data-action="edit-answer" data-qid="${q.id}" aria-label="修改回答：${escape(q.title)}">修改</button><button data-action="append-answer" data-qid="${q.id}" aria-label="补充回答：${escape(q.title)}">补充</button></div>`:''}</div>`:''}${current.editDraft?.questionId===q.id?renderEditor(turn):''}${active && turn.clarification?`<div class="message assistant-message turn-follow-up"><span class="assistant-avatar">${icon('helix')}</span><div class="message-content"><p>${escape(turn.clarification)}</p><span class="turn-status">接着补充就好，刚才的话会保留。</span></div></div>`:''}${active?'<div class="chat-current-anchor" id="chat-current-anchor"></div>':''}</article>`;
}
function renderComposer(){
  const q=getCurrentQuestion(current);$('#chat-composer-wrap').hidden=!q || current.complete;
  if(!q)return;
  const input=$('#chat-input'),level=current.questionTelemetry[q.id]?.maxHelpLevel || 0;
  input.disabled=autoPlaying;input.value=current.drafts[q.id] || '';
  input.placeholder=current.pendingClarification?'接着刚才的话补充……':'想到什么就说什么……';
  $('.chat-help').innerHTML=icon('light')+(level===0?'不知道怎么答？看个例子':level===1?'还没思路？看看选项':level===2?'还是不确定？可以先留白':'再看看刚才的例子');
  $('.chat-skip').hidden=level<3;
  $('.chat-category').textContent=inferCategory(current).label+' · 换例子';
  $('#chat-composer-wrap .sample-answer').textContent=current.custom?'看一个回答示例':'填入人参示例';
  $('#chat-composer-wrap .quick-demo').textContent=autoPlaying?'暂停演示':current.custom?'体验人参案例':'人参案例演示';
  $('#chat-form').setAttribute('aria-label','和新品有数继续对话');resizeInput(input);
}
function renderNote(){
  const progress=getProgress(current);$('#progress-value').textContent=`${progress.answered} / ${progress.total}`;$('#progress-label').textContent=current.complete?'这次聊天已整理':'已经聊到的问题';$('#progress-bar').style.width=progress.percent+'%';
  const highlights=[['R0-Q1','你的产品想法'],['R1-Q1','想到的购买者'],['R2-Q1','购买前的画面'],['R2-Q2','真实发生的时刻'],['R4-Q1','已有的条件']];
  $('#captured-notes').innerHTML=highlights.filter(([id])=>current.answers[id]?.trim()).map(([id,label])=>`<div class="captured-note"><span>${label}</span><p>${escape(current.answers[id])}</p><button class="text-button" data-action="jump-question" data-qid="${id}">回到这条回答</button></div>`).join('')||'<p class="note-placeholder">这里会保留你提到的线索，<br>随时可以回到原话补充。</p>';
  $('.note-foot p').innerHTML='不必一次说完整。<br>前面的回答，随时能改。';
}

function factCard(f) {
  return `<article class="fact-card"><span class="fact-tag">${escape(f.id)} · ${escape(f.source || '用户口述')} · ${escape(f.status || '待验证')}</span><p>${escape(f.text ?? f.statement ?? f.content)}</p></article>`;
}
function judgmentCard(j) {
  return `<article class="judgment-card"><span class="fact-tag">${escape(j.id)} · 当前判断</span><h4>${escape(j.judgment)}</h4><p>依据：${(j.basisFactIds || []).map(id=>`<a href="#fact-${escape(id)}">${escape(id)}</a>`).join('、') || '尚无足够事实'}</p><p><strong>什么会推翻它</strong><br>${escape(j.overturnCondition)}</p><div class="judgment-meta">置信度：${escape(j.confidence)} · 仍需外部证据</div></article>`;
}
function renderDiagnosis() {
  const report=current.report || buildReport(current);
  const sections=report.sections;
  const content=sections.map((s,index)=>{
    let body='';
    if(index===0) body=`<p class="report-definition">${escape(s.definition || report.definition)}</p>`;
    if(index===1) body=`<p class="privacy-note">用户口述与演示内容，尚未独立核实。未接入外部搜索，本次没有外部验证事实。</p>${(s.facts || report.facts || []).map(f=>`<div id="fact-${escape(f.id)}">${factCard(f)}</div>`).join('')}`;
    if(index===2) body=`${(s.contradictions || []).length?(s.contradictions || []).map(c=>`<p class="signal-note">${escape(typeof c==='string'?c:c.text || c.description)}</p>`).join(''):'<p>目前没有足够信息确认明确矛盾，后续仍需核对。</p>'}${(s.judgments || report.judgments || []).map(judgmentCard).join('')}`;
    if(index===3) body=(s.gaps || report.gaps || []).map((g,i)=>`<article class="gap-card"><span>0${i+1}</span><div><h4>${escape(g.gap)}</h4><p><strong>为什么关键</strong> ${escape(g.why)}</p><p><strong>怎么查</strong> ${escape(g.action)}</p><p><strong>成立与推翻标准</strong> ${escape(g.criterion)}</p></div></article>`).join('');
    if(index===4) body=(s.candidates || report.candidates || []).map(c=>`<article class="candidate-card"><h4>${escape(typeof c==='string'?c:c.label || c.title || c.scenario || c.entry)}</h4>${typeof c==='object'?`<p>${escape(c.scene || '')}</p><p>${escape(c.condition || c.validation || c.description)}</p>`:''}</article>`).join('')+'<p class="privacy-note">这些是需要验证的候选切口，不是最终产品选择。</p>';
    if(index===5) body=`<ul>${(s.deferred || report.deferred || []).map(d=>`<li>${escape(typeof d==='string'?d:d.decision || d.text)}</li>`).join('')}</ul>`;
    return `<section class="report-section" aria-labelledby="section-${index+1}"><div class="report-section-heading"><span class="report-number">0${index+1}</span><h3 id="section-${index+1}">${escape(s.title)}</h3></div>${body}</section>`;
  }).join('');
  $('#diagnosis').innerHTML=`<div class="report-intro"><div class="round-eyebrow">YOUR IDEA, A LITTLE CLEARER</div><h2>把下一步，放在证据上。</h2><p>${escape(current.title)}</p><p class="privacy-note">${current.stopReason?'本次先整理已经聊到的信息，未完成的部分保留为空。':'本次问询已整理。报告中的判断可被新证据推翻。'}</p></div><div class="report-grid">${content}</div><div class="feedback-banner">${current.feedback?.submittedAt?'<strong>你的反馈已收好。</strong><span>这次记录已包含完整反馈，可以导出归档。</span>':'<strong>最后，请帮这次问询做一次校正。</strong><span>问过的问题和你的原话都在，直接点选就好。</span>'}<button class="secondary-action" data-action="feedback">${current.feedback?.submittedAt?'查看或修改反馈':'回看问题，留下反馈'}</button></div><div class="report-toolbar"><button class="export-button" data-action="export-md">${icon('download')}导出 Markdown</button><button class="export-button" data-action="export-json">导出 JSON</button><button class="export-button" data-action="print-report">打印 / 保存 PDF</button><button class="text-button" data-action="notes">完整对话</button></div>`;
}
function render(){
  const inChat=Boolean(current);document.body.dataset.view=inChat?'chat':'landing';$('meta[name="theme-color"]').content=inChat?'#f5f7fa':'#090c12';
  $('#landing').hidden=inChat;$('#conversation').hidden=!inChat;homeVideo.setVisible(!inChat);$('#breadcrumb-current').textContent=inChat?current.title:'新品问询';renderRecent();
  if(!inChat){$('#chat-composer-wrap').hidden=true;return;}
  $('#chat-project-label').textContent=current.title;
  $('#messages').innerHTML=getChatTurns(current).map(renderChatTurn).join('');
  renderNote();renderComposer();$('#diagnosis').hidden=!current.complete;
  if(current.complete)renderDiagnosis();
  if(globalThis.__INQUIRY_DEBUG__){globalThis.__INQUIRY_DEBUG_SESSION__=current;document.dispatchEvent(new CustomEvent('xinpin-session',{detail:current}));}
}
function start(scenarioId='idea',{opening='',custom=false}={}){
  operation++;autoPlaying=false;errors={};editError='';current=createChatSession({scenarioId,opening,custom});
  if(!custom)current.title='长白山人参 · 精力补充新品';sessions.unshift(current);$('#entry-input').value='';document.body.classList.remove('menu-open');persist();render();scrollLatest(true);$('#chat-input').focus({preventScroll:true});
}
function goHome(){operation++;autoPlaying=false;current=null;errors={};document.body.classList.remove('menu-open');persist();render();window.scrollTo(0,0);resizeInput($('#entry-input'));}
function submitCurrent(text,{fromDemo=false}={}){
  if(!current || current.complete || (autoPlaying&&!fromDemo))return;
  const q=getCurrentQuestion(current);if(!q)return;
  const result=submitChatAnswer(current,q.id,text);errors=result.errors || {};
  persist();render();
  if(!result.ok && !result.clarification)toast(Object.values(errors).join('；') || '可以再补充一句，或者看看例子。');
  scrollLatest();
  if(current.complete && result.ok){if(!current.feedback?.submittedAt)openFeedback();}
  else $('#chat-input').focus({preventScroll:true});
  return result;
}
async function runDemo(fresh=false){
  if(autoPlaying){pauseDemo();persist();renderComposer();toast('已暂停。你可以接着回答，也可以修改前面的内容。');return;}
  if(fresh || !current || current.complete || current.custom)start('idea',{opening:SCENARIOS[0].answers[0]});
  autoPlaying=true;const token=++operation,id=current.id;renderComposer();
  while(autoPlaying && token===operation && current?.id===id && !current.complete){
    await new Promise(resolve=>setTimeout(resolve,430));if(!autoPlaying || token!==operation || current?.id!==id)break;
    const q=getCurrentQuestion(current);if(!q)break;
    const answer=getSampleAnswers(current.scenarioId,[q.id])[q.id];const result=submitCurrent(answer,{fromDemo:true});
    if(!result?.ok){autoPlaying=false;toast('演示先停在这里，可以接着补充。');break;}
  }
  if(token===operation){autoPlaying=false;renderComposer();}
}
function openDialog(content,{review=false}={}){$('#app-dialog').classList.toggle('review-dialog',review);$('#dialog-content').innerHTML=content;if(!$('#app-dialog').open)$('#app-dialog').showModal();document.body.classList.remove('menu-open');}
function feedbackSource(){return current.feedbackDraft || current.feedbackUi || current.feedback || {};}
function captureFeedbackDraft(){
  const form=$('#feedback-form');if(!current || !form)return;
  const data=new FormData(form),previous=feedbackSource();
  current.feedbackDraft={...previous,...Object.fromEntries(data)};
  if(data.has('awareOfTest'))current.feedbackDraft.awareOfTest=data.get('awareOfTest')==='true';
  for(const key of ['valuableQuestionIds','uselessQuestionIds','unclearQuestionIds'])current.feedbackDraft[key]=[...(previous[key] || [])];
}
function reviewList(){
  const f=feedbackSource();
  return getReviewQuestions(current).map((q,i)=>`<article class="review-question-row" data-review-qid="${q.questionId}"><div class="review-reference-title"><span>${String(i+1).padStart(2,'0')}</span><h3 class="review-question-title">${escape(q.title)}</h3></div><details class="review-question-toggle"><summary>回看我的回答${q.answered?'':' · 这题还没答'}</summary><div class="review-answer">${escape(q.answer || '这题暂时留白。')}${q.extra?`\n补充：${escape(q.extra)}`:''}</div>${q.example?`<div class="review-guidance"><strong>当时看过的例子</strong><p>${escape(q.example)}</p></div>`:''}${q.answered?`<button type="button" class="text-button" data-action="review-edit" data-qid="${q.questionId}">回到原话修改</button>`:''}</details><div class="review-question-tags">${[['valuableQuestionIds','有帮助'],['uselessQuestionIds','没帮上'],['unclearQuestionIds','没看懂']].map(([kind,label])=>`<button type="button" data-action="review-tag" data-kind="${kind}" data-qid="${q.questionId}" aria-pressed="${(f[kind] || []).includes(q.questionId)}">${label}</button>`).join('')}</div></article>`).join('');
}
function selectedReviewLabels(kind){const f=feedbackSource(),ids=f[kind] || [];return ids.length?`已选 ${ids.length} 题：`+getReviewQuestions(current).filter(q=>ids.includes(q.questionId)).map(q=>q.title).join('；'):'可以在问题旁点选，也可以直接说说感受。';}
function refreshReview(){const panel=$('#review-question-list');if(panel){const expanded=[...panel.querySelectorAll('details[open]')].map(el=>el.closest('[data-review-qid]').dataset.reviewQid),top=panel.scrollTop;panel.innerHTML=reviewList();for(const qid of expanded){const detail=panel.querySelector(`[data-review-qid="${qid}"] details`);if(detail)detail.open=true;}panel.scrollTop=top;}for(const kind of ['valuableQuestionIds','uselessQuestionIds','unclearQuestionIds']){const el=document.querySelector(`[data-selected-summary="${kind}"]`);if(el)el.textContent=selectedReviewLabels(kind);}}
function openFeedback(){
  if(!current?.complete)return;
  const f=feedbackSource(),group=(name,label)=>`<label class="feedback-empty-choice"><input type="radio" name="${name}" value="none" ${f[name]==='none'?'checked':''}/> ${label}</label>`;
  const questionField=(name,title,kind,noneLabel)=>`<div class="feedback-field"><label for="feedback-${name}">${title}</label><p class="feedback-prompt-helper" data-selected-summary="${kind}">${escape(selectedReviewLabels(kind))}</p>${group(name==='valuableQuestion'?'valuableChoice':name==='uselessQuestion'?'uselessChoice':'guidanceChoice',noneLabel)}<textarea id="feedback-${name}" name="${name}" rows="2" maxlength="12000" placeholder="可选，补一句你的感受。">${escape(f[name] || '')}</textarea></div>`;
  openDialog(`<h2 class="dialog-title">回看刚才的聊天，点一下就好。</h2><p class="dialog-subtitle">问题和你的回答都列在这里。不用记住题目，也不用懂背后的理论。</p>${current.feedbackNeedsReview?'<p class="stale-feedback-note">你修改了回答。原反馈仍保留，请按更新后的聊天重新确认。</p>':''}<div class="review-layout"><aside class="review-reference"><div class="review-reference-title"><h3>刚才，我们聊了这些</h3><span>${getReviewQuestions(current).length} 个问题</span></div><p class="feedback-prompt-helper">点“回看我的回答”展开原话，再标记有帮助、没帮上或没看懂。</p><div id="review-question-list" class="review-question-list">${reviewList()}</div></aside><form id="feedback-form" class="feedback-form" novalidate>${questionField('valuableQuestion','哪些问题让你更想清楚了一点？','valuableQuestionIds','暂时没有特别有帮助的')}${questionField('uselessQuestion','哪些问题没帮上忙，或者感觉重复？','uselessQuestionIds','暂时没有这样的题') }<div class="feedback-field"><label for="feedback-missedQuestion">还有什么关于产品的事，你想说却没聊到？</label><p class="feedback-prompt-helper">说一件你还在犹豫或没机会说的事就好，不用替系统设计问题。</p><textarea id="feedback-missedQuestion" name="missedQuestion" rows="3" maxlength="12000" placeholder="例如：我还想聊聊，买的人会不会第二次再买。">${escape(f.missedQuestion || '')}</textarea><button type="button" class="feedback-empty-choice" data-action="feedback-none" data-field="missedQuestion">暂时没有</button></div>${questionField('guidance','哪些说法或例子还是不好懂？','unclearQuestionIds','都能看懂，例子也够用')}<div class="feedback-field"><label for="feedback-role">你的角色</label><select id="feedback-role" name="role"><option value="">请选择</option>${['产品负责人','工厂方','渠道方','营销人','其他'].map(r=>`<option ${f.role===r?'selected':''}>${r}</option>`).join('')}</select></div><fieldset class="feedback-field feedback-options"><legend>体验之前，你知道这是一个测试系统吗？</legend>${[[true,'知道'],[false,'不知道']].map(([v,label])=>`<label><input type="radio" name="awareOfTest" value="${v}" ${f.awareOfTest===v?'checked':''}/> ${label}</label>`).join('')}</fieldset><p id="feedback-error" class="batch-error" role="alert"></p><div class="feedback-actions"><button type="button" class="secondary-action" data-action="close-dialog">先看报告</button><button type="submit" class="batch-submit">保存反馈${icon('check')}</button></div></form></div>`,{review:true});
}
function feedbackPayload(){
  captureFeedbackDraft();const f=current.feedbackDraft || {},questions=getReviewQuestions(current);
  const compile=(field,kind,choice,noneText)=>{const selected=questions.filter(q=>(f[kind] || []).includes(q.questionId)).map(q=>`「${q.title}」`);return [...(selected.length?['所选问题：'+selected.join('；')]:[]),f[field]?.trim(),f[choice]==='none'?noneText:''].filter(Boolean).join('\n');};
  return {...f,valuableQuestion:compile('valuableQuestion','valuableQuestionIds','valuableChoice','暂时没有特别有帮助的问题。'),uselessQuestion:compile('uselessQuestion','uselessQuestionIds','uselessChoice','暂时没有没帮上忙或重复的问题。'),guidance:compile('guidance','unclearQuestionIds','guidanceChoice','都能看懂，例子也够用。')};
}
function openCategory(){const active=current.guidanceCategory || 'auto';openDialog(`<h2 class="dialog-title">换一个你熟悉的例子。</h2><p class="dialog-subtitle">只改变解释问题时用的例子，不会替你填写回答。</p><div class="guidance-category-choices"><button class="secondary-action" data-action="set-category" data-category="auto" aria-pressed="${active==='auto'}">根据我的产品选择</button>${getCategoryChoices().map(c=>`<button class="secondary-action" data-action="set-category" data-category="${escape(c.id)}" aria-pressed="${active===c.id}">${escape(c.label)}</button>`).join('')}</div>`);}
function openHelp(){openDialog(`<h2 class="dialog-title">像聊天一样，把新品想清楚。</h2><p class="dialog-subtitle">不用懂理论，也不用一次说完整。</p><div class="help-grid"><div class="help-card"><span>01 / TALK IT THROUGH</span><h3>一次聊一个问题</h3><p>回答后继续往下聊。前面的问答一直在，向上翻就能看见。</p></div><div class="help-card"><span>02 / MAKE IT FAMILIAR</span><h3>用熟悉的东西解释</h3><p>不明白就换个说法，或看看同类产品的例子。也能主动换成你熟悉的品类。</p></div><div class="help-card"><span>03 / KEEP THINKING</span><h3>想到新内容，随时补</h3><p>每条回答都可以原地修改、补充，报告会随最新回答重新整理。</p></div></div><div class="dialog-note">当前为规则版交互演示，尚未连接大模型或外部搜索。所有口述和示例均待验证。</div><div class="dialog-buttons"><button class="primary-action" data-action="help-start">开始聊聊${icon('arrow-right')}</button><button class="secondary-action" data-action="demo">体验人参案例</button></div>`);}
function openProjects(){const items=sessions.slice().sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt));openDialog(`<h2 class="dialog-title">接着上次的想法聊。</h2><p class="dialog-subtitle">问答、修改和草稿都会留在当前浏览器。</p><div class="project-list">${items.map(s=>`<button class="project-card" data-action="resume" data-id="${escape(s.id)}"><span class="project-card-icon">${icon(s.complete?'note':'chat')}</span><span><h3>${escape(s.title)}</h3><p>${getProgress(s).answered} 条回答 · ${new Date(s.createdAt).toLocaleDateString('zh-CN')}</p></span><span class="project-end">${s.complete?(s.feedback?.submittedAt?'已归档':'待反馈'):'继续聊 →'}</span></button>`).join('')||'<p class="empty-state">开始聊天后，记录会出现在这里。</p>'}</div>${legacy.length?`<div class="dialog-note">保留了 ${legacy.length} 条旧版记录，可下载备份。</div><button class="secondary-action" data-action="legacy-export">下载旧版记录</button>`:''}<div class="dialog-buttons"><button class="primary-action" data-action="help-start">${icon('plus')}开始新的聊天</button></div>`);}
function openNotes(){const s=current || sessions[0];if(!s){openProjects();return;}openDialog(`<h2 class="dialog-title">每一条原话，都留在这里。</h2><p class="dialog-subtitle">${escape(s.title)} · ${s.complete?'报告已生成':'聊天仍在继续'} · ${s.feedback?.submittedAt?'已含反馈':'反馈待确认'}</p><div class="record-list">${getChatTurns(s).map(t=>`<div class="record-item"><h3>${escape(t.question.title)}</h3><p>${escape(t.answer || t.pendingAnswer || '尚未回答')}</p>${t.extra?`<p>补充：${escape(t.extra)}</p>`:''}</div>`).join('')}</div><div class="dialog-buttons"><button class="primary-action" data-action="draft-json" data-id="${escape(s.id)}">导出完整记录 JSON</button><button class="secondary-action" data-action="draft-md" data-id="${escape(s.id)}">导出 Markdown</button></div>`);}
function download(content,filename,type){const url=URL.createObjectURL(new Blob([content],{type})),link=document.createElement('a');link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function exportFile(format,{draft=false,id}={}){const s=id?sessions.find(item=>item.id===id):current;if(!s)return;if(s.complete&&!s.feedback?.submittedAt&&!draft){toast('先回看题目、确认反馈，再导出完整记录。思考记录中也可以先导出草稿。');openFeedback();return;}const suffix=s.feedback?.submittedAt?'完整记录':'草稿';if(format==='json')download(JSON.stringify(exportSessionJSON(s),null,2),`新品有数_${suffix}.json`,'application/json;charset=utf-8');else download(exportSessionMarkdown(s),`新品有数_${suffix}.md`,'text/markdown;charset=utf-8');toast('完整记录已准备好下载。');}
function beginEdit(qid,mode='replace'){pauseDemo();const turn=getChatTurns(current).find(t=>t.questionId===qid);if(!turn?.answered)return;current.editDraft={questionId:qid,mode,text:mode==='append'?'':current.answers[qid] || ''};editError='';persist();keepTurnPosition(qid,render);requestAnimationFrame(()=>$('#edited-answer')?.focus({preventScroll:true}));}
document.addEventListener('click',async event=>{
  const el=event.target.closest('[data-action]');if(!el)return;event.preventDefault();const action=el.dataset.action;
  if(action==='focus-entry'){$('#entry-input').focus({preventScroll:true});return;}
  if(action==='choose-video'){homeVideo.chooseFile();return;}
  if(action==='menu'){document.body.classList.add('menu-open');return;}
  if(action==='close-menu'){document.body.classList.remove('menu-open');return;}
  if(action==='close-dialog'){captureFeedbackDraft();persist();$('#app-dialog').close();return;}
  if(action==='new'||action==='home'){goHome();return;}
  if(action==='help'){openHelp();return;}
  if(action==='projects'){openProjects();return;}
  if(action==='notes'){openNotes();return;}
  if(action==='scenario'){const scenario=SCENARIOS.find(s=>s.id===el.dataset.scenario);start(scenario?.id||'idea',{opening:scenario?.answers[0]||''});return;}
  if(action==='demo'){$('#app-dialog').close();await runDemo(true);return;}
  if(action==='auto-demo'){await runDemo();return;}
  if(action==='help-start'){$('#app-dialog').close();goHome();$('#entry-input').focus();return;}
  if(action==='resume'){const s=sessions.find(p=>p.id===el.dataset.id);if(!s)return;pauseDemo();operation++;current=s;upgradeToChat(current);$('#app-dialog').close();document.body.classList.remove('menu-open');persist();render();scrollLatest(true);return;}
  if(action==='inspire'){$('#entry-input').value=SCENARIOS[0].answers[0];resizeInput($('#entry-input'));$('#entry-input').focus();return;}
  if(action==='profile'){openDialog('<h2 class="dialog-title">白雪的工作空间</h2><p class="dialog-subtitle">聊天、修改和反馈保存在当前浏览器。你可以随时在“思考记录”里导出 Markdown 和 JSON。</p><div class="dialog-note">规则版交互演示，尚未连接大模型或外部研究服务。</div>');return;}
  if(action==='legacy-export'){download(JSON.stringify({version:1,projects:legacy},null,2),'新品有数_旧版记录.json','application/json');return;}
  if(action==='feedback'){openFeedback();return;}
  if(action==='review-tag'){
    captureFeedbackDraft();const kind=el.dataset.kind;if(!['valuableQuestionIds','uselessQuestionIds','unclearQuestionIds'].includes(kind))return;
    const f=current.feedbackDraft,qid=el.dataset.qid,ids=f[kind]||[];f[kind]=ids.includes(qid)?ids.filter(id=>id!==qid):[...ids,qid];
    const choice=kind==='valuableQuestionIds'?'valuableChoice':kind==='uselessQuestionIds'?'uselessChoice':'guidanceChoice';
    if(f[kind].length){delete f[choice];document.querySelectorAll(`[name="${choice}"]`).forEach(input=>{input.checked=false;});}
    persist();refreshReview();return;
  }
  if(action==='feedback-none'){const input=document.querySelector(`#feedback-form [name="${el.dataset.field}"]`);if(input){input.value='暂时没有。';captureFeedbackDraft();persist();}return;}
  if(action==='review-edit'){captureFeedbackDraft();persist();$('#app-dialog').close();beginEdit(el.dataset.qid);document.querySelector(`[data-turn-id="${el.dataset.qid}"]`)?.scrollIntoView({block:'center',behavior:'instant'});return;}
  if(action==='export-md'||action==='export-json'){exportFile(action.endsWith('json')?'json':'md');return;}
  if(action==='draft-md'||action==='draft-json'){exportFile(action.endsWith('json')?'json':'md',{draft:true,id:el.dataset.id});return;}
  if(action==='print-report'){if(!current?.feedback?.submittedAt){openFeedback();return;}window.print();return;}
  if(!current)return;
  if(action==='jump-question'){document.querySelector(`[data-turn-id="${el.dataset.qid}"]`)?.scrollIntoView({behavior:'smooth',block:'center'});return;}
  if(action==='edit-answer'||action==='append-answer'){beginEdit(el.dataset.qid,action==='append-answer'?'append':'replace');return;}
  if(action==='cancel-edit'){const qid=current.editDraft?.questionId;current.editDraft=null;editError='';persist();keepTurnPosition(qid,render);return;}
  if(action==='category'){openCategory();return;}
  if(action==='set-category'){
    const category=el.dataset.category;if(category==='auto')delete current.guidanceCategory;else if(getCategoryChoices().some(c=>c.id===category))current.guidanceCategory=category;else return;
    $('#app-dialog').close();const q=getCurrentQuestion(current);if(q){current.rephrasedQuestionIds=[...new Set([...(current.rephrasedQuestionIds||[]),q.id])];if((current.questionTelemetry[q.id]?.maxHelpLevel||0)<1)advanceHelp(current,q.id);else {const g=getGuidance(current,q.id);current.messages.push({role:'assistant',text:`换一个熟悉的例子：${g.productName}。\n${g.productIntro}\n${g.example}`,questionIds:[q.id],helpLevel:1,productIntro:g.productIntro,categoryId:g.categoryId,kind:'guidance-category-change',at:new Date().toISOString()});}}
    persist();render();scrollLatest();return;
  }
  if(current.complete || autoPlaying)return;
  const q=getCurrentQuestion(current);if(!q)return;
  if(action==='rephrase'){if(!current.rephrasedQuestionIds?.includes(q.id))current.messages.push({role:'assistant',text:getGuidance(current,q.id).simpleExplanation,questionIds:[q.id],kind:'question-rephrase',at:new Date().toISOString()});current.rephrasedQuestionIds=[...new Set([...(current.rephrasedQuestionIds||[]),q.id])];const telemetry=current.questionTelemetry[q.id];if(telemetry){telemetry.stalled=true;telemetry.rephrased=true;}persist();render();scrollLatest();return;}
  if(action==='help-next'){advanceHelp(current,q.id);persist();render();scrollLatest();return;}
  if(action==='pick-option'){setDraft(current,q.id,el.dataset.value);persist();renderComposer();$('#chat-input').focus({preventScroll:true});return;}
  if(action==='sample-answer'){
    if(current.custom){advanceHelp(current,q.id);persist();render();scrollLatest();return;}
    setDraft(current,q.id,getSampleAnswers(current.scenarioId,[q.id])[q.id]);persist();renderComposer();$('#chat-input').focus({preventScroll:true});return;
  }
  if(action==='skip-answer'){submitCurrent('');}
});
document.addEventListener('input',event=>{
  const el=event.target;
  if(el.id==='chat-input' && current){const q=getCurrentQuestion(current);if(q){setDraft(current,q.id,el.value);persist();resizeInput(el);}}
  if(el.hasAttribute('data-edit-draft') && current?.editDraft){current.editDraft.text=el.value;persist();}
  if(el.closest('#feedback-form') && current){captureFeedbackDraft();persist();}
});
document.addEventListener('change',event=>{
  const el=event.target;if(!el.closest('#feedback-form') || !current)return;
  captureFeedbackDraft();
  const kind={valuableChoice:'valuableQuestionIds',uselessChoice:'uselessQuestionIds',guidanceChoice:'unclearQuestionIds'}[el.name];
  if(kind && el.value==='none'){current.feedbackDraft[kind]=[];refreshReview();}
  persist();
});
document.addEventListener('submit',event=>{
  if(event.target.id==='chat-form'){event.preventDefault();submitCurrent($('#chat-input').value);}
  if(event.target.id==='edit-answer-form'){
    event.preventDefault();const qid=current.editDraft?.questionId;if(!qid)return;
    const value=String(new FormData(event.target).get('editedAnswer')||'');
    const result=reviseChatAnswer(current,qid,value,{mode:current.editDraft.mode});
    if(!result.ok){editError=Object.values(result.errors||{}).join('；')||'先写一句你的修改或补充。';keepTurnPosition(qid,render);return;}
    current.editDraft=null;editError='';persist();keepTurnPosition(qid,render);
    toast(result.reopened?'已更新，这次聊天可以继续了。':current.complete?'回答和报告已更新，请按最新内容再确认反馈。':'已更新，前后的聊天都保留着。');
  }
  if(event.target.id==='feedback-form'){
    event.preventDefault();const payload=feedbackPayload(),result=saveFeedback(current,payload);
    if(!result.ok){$('#feedback-error').textContent=Object.values(result.errors||{}).join('；');return;}
    current.feedbackUi={...current.feedbackDraft};current.feedbackDraft=null;persist();$('#app-dialog').close();renderDiagnosis();toast('反馈已保存，所选题目和原话会一起留在记录里。');
  }
});
$('#entry-form').addEventListener('submit',event=>{event.preventDefault();const opening=$('#entry-input').value.trim();if(opening)start('idea',{opening,custom:true});});
$('#entry-input').addEventListener('input',()=>resizeInput($('#entry-input')));
for(const id of ['entry-input','chat-input'])$(`#${id}`).addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();$(`#${id}`).closest('form').requestSubmit();}});
document.addEventListener('keydown',event=>{if(event.key==='Escape')document.body.classList.remove('menu-open');if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='k'){event.preventDefault();$('#app-dialog').close();goHome();$('#entry-input').focus();}});
$('#app-dialog').addEventListener('close',()=>{captureFeedbackDraft();persist();});
$('#app-dialog').addEventListener('click',event=>{if(event.target===$('#app-dialog')){const r=event.target.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom){captureFeedbackDraft();persist();event.target.close();}}});
render();resizeInput($('#entry-input'));
if(current){persist();if(current.editDraft)requestAnimationFrame(()=>$('#edited-answer')?.scrollIntoView({block:'center'}));else scrollLatest(true);}
