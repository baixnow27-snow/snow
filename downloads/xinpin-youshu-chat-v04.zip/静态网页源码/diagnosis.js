import { QUESTIONS, ENGINE_VERSION } from './engine-data.js';

const quote = (value, max = 160) => {
  const text = String(value || '').trim();
  return text.length > max ? `${text.slice(0, max)}…` : text;
};

export function createFactLedger(session) {
  const facts = QUESTIONS.flatMap((question) => {
    const answer = session.answers?.[question.id];
    const extra = session.questionTelemetry?.[question.id]?.volunteeredExtra;
    const statements = [];
    if (String(answer || '').trim()) statements.push({ text: answer, kind: 'answer' });
    if (String(extra || '').trim()) statements.push({ text: extra, kind: 'extra' });
    return statements.map((statement) => ({ questionId: question.id, questionTitle: question.title, ...statement,
      source: '用户口述', sourceType: 'user_statement', status: '待验证', verified: false }));
  });
  // A statement about an empty record is a record fact, never an invented customer statement.
  if (!facts.length) facts.push({ questionId: null, questionTitle: '会话记录',
    text: '本次问询未记录到口述回答。', source: '会话记录', sourceType: 'session_record', status: '已记录', verified: false });
  return facts.map((fact, index) => ({ id: `F${String(index + 1).padStart(2, '0')}`, ...fact }));
}

export function getSocialContext(session) {
  const scene = ['R0-Q1', 'R2-Q1', 'R2-Q2'].map((id) => session.answers?.[id] || '').join('\n');
  const activity = String(session.answers?.['R2-Q2'] || '');
  const solo = /(?:主要|大多|经常|通常|基本|都是|一直)?(?:独自|单独)|一个人(?:进行|参加|去|做|在|使用|完成|钓|练|跑|玩|通勤|工作|买|吃|喝)|不(?:是|会|跟人)?(?:一起|结伴)|没有同伴/.test(activity) || activity.trim() === '一个人';
  if (solo) return { status: 'absent', reason: '口述包含独自进行的情况，需要按具体活动分别核实。' };
  const group = /一起|结伴|几个人|旁边的人|同伴|一群|团队/.test(scene);
  const comparable = /(?:当场|现场|当面|马上|立刻|即时|同时|一眼)[^。！？\n]{0,22}(?:比较|比出|比谁|看出|高低|输赢|排名|结果)|(?:结果|成绩|收获|表现)[^。！？\n]{0,15}(?:当场|当面|即时|立刻|一眼|比出来|能比较)|谁[^。！？\n]{0,10}(?:多|少|快|慢|好)[^。！？\n]{0,10}(?:当场|看得见)/.test(scene);
  return group && comparable
    ? { status: 'present', reason: '口述同时包含结伴进行，以及结果当场可比较；仍需购买者核实。' }
    : { status: 'unconfirmed', reason: '尚未同时确认结伴进行和结果当场可比较。' };
}

export function buildReport(session) {
  const facts = createFactLedger(session);
  const answer = (id) => String(session.answers?.[id] || '').trim();
  const refs = (...ids) => {
    const matches = facts.filter((fact) => ids.includes(fact.questionId)).map((fact) => fact.id);
    return matches.length ? matches : [facts[0].id];
  };
  const stop = session.stopReason === 'weak-need';
  const socialContext = getSocialContext(session);
  const definition = answer('R1-Q1') || answer('R2-Q2')
    ? `需要确认：${answer('R1-Q1') ? `「${quote(answer('R1-Q1'), 85)}」` : '口述中的目标购买者'}，在${answer('R2-Q2') ? `「${quote(answer('R2-Q2'), 95)}」` : '尚未说清的具体时刻'}，是否存在现有做法没有满足、且值得付费解决的问题。`
    : '需要先确认具体购买者、发生问题的时刻，以及现有做法还有什么没有满足。';
  const judgments = [
    { id: 'J1', title: '产品是否需要存在', judgment: stop
      ? '目前口述不足以支持这款新品的存在必要性；先暂停把“能做”当成“需要做”。'
      : '目前只能确认产品设想，尚不能确认它有独立的存在必要性。',
      basisFactIds: refs('R2-Q3', 'R1-Q2', 'R0-Q1'),
      overturnCondition: '若具体购买者能复述反复发生、现有办法仍未满足的问题，并在真实选择中愿意付费，则需要重写此判断。', confidence: '低' },
    { id: 'J2', title: '问题是否来自真实需要', judgment: stop
      ? '你对“没有它也可以”的口述，使需求强度尚未成立；不能据此把产品方的设想当成购买者的真实需要。'
      : '这些购买理由目前来自本次口述，还不能确认购买者自己也这样想。',
      basisFactIds: refs('R0-Q3', 'R2-Q1', 'R2-Q3', 'R2-Q4'),
      overturnCondition: '若购买者在没有产品提示时主动讲出同一问题，且能提供最近一次实际行为或损失，需求假设可重新评估。', confidence: '低' },
  ];
  if (!stop) judgments.push(
    { id: 'J3', title: '现有条件能否支持做出来', judgment: answer('R4-Q2')
      ? '原料、加工经验或客户关系能不能直接用在这款新品上，还需要实际记录来核实。'
      : '还缺少现有条件如何用于这款新品的信息，暂时不能确认是否能把它做出来。',
      basisFactIds: refs('R4-Q1', 'R4-Q2', 'R4-Q3', 'R0-Q2'),
      overturnCondition: '若负责人和实际交付方共同确认关键条件可复用，并用小范围实际交付记录核实尚缺条件，则可重新评估可行性。', confidence: '低' },
    { id: 'J4', title: '现在是否适合投入', judgment: '现阶段缺少真实购买行为和资源核实记录，不建议仅凭本次口述扩大投入。',
      basisFactIds: refs('R2-Q3', 'R3-Q4', 'R4-Q2'),
      overturnCondition: '若需求、替代选择和关键交付条件均经独立记录核实，并得到实际付费或复购证据，则重新评估投入。', confidence: '低' },
  );
  const contradictions = [];
  const allUsable = /(?:所有|全部|现有)[^。！？]{0,10}(?:条件|优势)[^。！？]{0,8}(?:都能|都可|全部可|可以直接|无需重建)/.test(answer('R4-Q1'));
  const noneUsable = /(?:所有|全部|这些)[^。！？]{0,10}(?:都不能|都用不上|全都无关|全部无关)|没有任何[^。！？]{0,8}(?:能用|可迁移)|完全不能迁移/.test(answer('R4-Q2'));
  if (allUsable && noneUsable) {
    contradictions.push(`我这儿有个地方没想通：你在前面列出的条件是「${quote(answer('R4-Q1'))}」，谈到能否用于新品时又说「${quote(answer('R4-Q2'))}」。这些已有条件和新品实际需要的条件，还没有说明怎样对上。`);
  }
  const gaps = [
    { id: 'GAP01', gap: '购买者是否反复在这个具体时刻遇到尚未满足的问题？',
      why: '决定 J1 的存在必要性与 J2 的需求真实性，口述中的动机画面也需要与真实行为核对。',
      action: '问谁：找到与你描述接近的实际购买者；用什么：不展示产品的开放访谈与最近一次行为回看；看什么：发生时间、在场人员、出现频次、未解决的后果，以及行动前想过什么。',
      criterion: '成立：购买者能主动复述相同问题、具体时刻与实际影响；推翻：只在看到产品后表示感兴趣，或无法提供发生记录。' },
    { id: 'GAP02', gap: '现有替代做法是否已经足够，购买者是否真的愿意换？',
      why: '会改变 J1 与 J2；若现有办法已满足需要，新品的必要性不能由产品方代为确认。',
      action: '问谁：最近做过同类选择的购买者和一线店员或电商客服；用什么：购买记录、开放访谈与相关评论核查；看什么：实际使用的替代做法、花费、不满、放弃或再次购买的原因。',
      criterion: '成立：购买者能指出替代做法未满足的具体问题，并有实际换用或付费行为；推翻：现有办法已经足够，愿意换只停留在口头。' },
  ];
  if (!stop) gaps.push({ id: 'GAP03', gap: '现有资源能否覆盖新品需要的实际交付条件？',
    why: '决定 J3 的可行性，并改变 J4 的投入判断；产能、原料或客户关系本身还不能证明条件齐备。',
    action: '问谁：项目负责人、实际生产交付方及一线合作方；用什么：条件清单与真实小范围交付记录核对；看什么：可复用的资源、仍须建立的能力、实际限制及其证据。',
    criterion: '成立：关键条件逐项有可核对的记录，交付方能说明如何覆盖；推翻：核心条件只由内部口述，或试交付暴露未解决的限制。' });
  if (socialContext.status === 'present') gaps.push({ id: 'GAP04', gap: '结伴且结果可当场比较，是否真的影响购买者的选择？',
    why: '这是口述场景的一项成立条件，会改变 J2；它不能自动被当作所有购买者的动机。',
    action: '问谁：结伴参与者及独自参与者；用什么：两类最近一次活动的开放访谈与活动记录；看什么：在场人员、比较发生的时点、购买前后的实际选择、独自活动占比。',
    criterion: '成立：结伴、即时比较与具体选择的关系有行为记录支持；推翻：大部分独自进行，或结果比较没有影响购买。' });
  const candidates = [];
  if (answer('R2-Q2')) candidates.push({ label: '候选 · 口述中已出现的具体时刻',
    scene: answer('R2-Q2'), validation: '先核实这个时刻是否反复发生、现有办法有什么未满足，再决定它能否作为切入点。' });
  if (answer('R2-Q1')) candidates.push({ label: '候选 · 行动之前想到的画面',
    scene: answer('R2-Q1'), validation: '先向真实购买者核实：这是不是行动前已有的想象，是否真正导致了选择。' });
  if (!candidates.length) candidates.push({ label: '候选 · 场景尚待补齐', scene: '目前尚无足够的具体场景口述。', validation: '补充真实购买者最近一次问题发生的时刻和现有做法后，再列候选。' });
  const deferred = ['产品名称与命名方向', '主打卖点与传播表达', '过早缩窄目标人群', '产品改造、具体定价与营销方案'];
  const search = { performed: false, mode: 'user-statements-only', note: '本次未进行外部搜索；市场与竞品信息仅记录用户口述，全部待验证。' };
  return {
    version: ENGINE_VERSION, generatedAt: new Date().toISOString(), flow: stop ? 'stop-loss' : 'regular',
    title: stop ? '先核实必要性的诊断记录' : '新品问题诊断记录', definition, facts,
    externalFacts: [], contradictions, judgments, gaps, candidates, deferred, search, socialContext,
    sections: [
      { id: 'definition', title: '① 一句话问题定义', definition },
      { id: 'facts', title: '② 已确认的事实', facts, externalFacts: [], note: search.note },
      { id: 'contradictions', title: '③ 已确认的矛盾', contradictions, judgments,
        note: contradictions.length ? '' : '目前没有足够信息确认矛盾，暂不将信息缺口写成矛盾。' },
      { id: 'gaps', title: '④ 待验证缺口清单', gaps },
      { id: 'candidates', title: '⑤ 候选场景切入点', candidates },
      { id: 'deferred', title: '⑥ 不建议现在决定的事', deferred },
    ],
  };
}
