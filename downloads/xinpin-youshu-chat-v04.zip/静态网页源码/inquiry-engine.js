import { QUESTIONS, ROUND_BATCHES, SCENARIOS, ENGINE_VERSION, COPY_VERSION, getQuestion } from './engine-data.js';
import { buildReport, getSocialContext } from './diagnosis.js';
import { getGuidance } from './matched-guidance.js';
export { buildReport } from './diagnosis.js';

const IDEA_ROUNDS = ['R0', 'R1', 'R2', 'R3', 'R4'];
const MADE_ROUNDS = ['R0', 'R3', 'R4', 'R1', 'R2'];
const now = () => new Date().toISOString();
const batchOrder = (rounds) => rounds.flatMap((round) => ROUND_BATCHES.filter((batch) => batch.round === round).map((batch) => batch.id));
const telemetryFor = (session, id) => session.questionTelemetry[id] ||= {
  stalled: false, usedHelp: false, maxHelpLevel: 0, changedRoute: false,
  volunteeredExtra: '', signal: 'none', skipped: false, clarificationCount: 0,
};
const append = (session, role, text, extra = {}) => session.messages.push({ role, text, at: now(), ...extra });
const touch = (session) => { session.updatedAt = now(); };
const textOf = (value) => typeof value === 'string' ? value : value == null ? '' : String(value);

function appendBatchPrompt(session) {
  const batch = getCurrentBatch(session);
  if (!batch) return;
  append(session, 'assistant', batch.questions.map((question) => `${question.title}\n${question.body || ''}`).join('\n\n'), {
    questionIds: batch.questionIds, batchId: batch.id,
  });
}

export function createSession({ scenarioId = 'idea', opening = '', custom = false } = {}) {
  const id = globalThis.crypto?.randomUUID?.() || `session-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const session = {
    id, version: ENGINE_VERSION, scenarioId, custom: Boolean(custom),
    title: custom ? '我的新品想法' : SCENARIOS.find((scenario) => scenario.id === scenarioId)?.label || '新的新品问询',
    createdAt: now(), updatedAt: now(), answers: {}, drafts: {}, questionTelemetry: {},
    messages: [], batchOrder: batchOrder(IDEA_ROUNDS), batchIndex: 0,
    complete: false, stopReason: null, feedback: null, report: null,
    route: 'idea', routeLog: [], search: { performed: false, mode: 'user-statements-only' },
  };
  for (const question of QUESTIONS) telemetryFor(session, question.id);
  append(session, 'assistant', '说说你想推的新品，一句话就行。我们先把购买者、发生问题的时刻和已有条件问清楚，再整理一份待验证的问题记录。');
  if (textOf(opening).trim()) {
    session.answers['R0-Q1'] = textOf(opening);
    session.title = textOf(opening).trim().slice(0, 30);
    applySignal(session, 'R0-Q1', textOf(opening));
    append(session, 'user', textOf(opening), { questionIds: ['R0-Q1'] });
  }
  appendBatchPrompt(session);
  return session;
}

export function getCurrentBatch(session) {
  if (session.complete) return null;
  const original = ROUND_BATCHES.find((batch) => batch.id === session.batchOrder[session.batchIndex]);
  if (!original) return null;
  const questionIds = original.questionIds.filter((id) => !Object.hasOwn(session.answers, id));
  const questions = questionIds.map(getQuestion).filter(Boolean);
  // Conditional follow-ups are recorded on submission after reading the full
  // scene, rather than assuming an optional extra answers an unasked question.
  return { ...original, questionIds, questions, followUps: [] };
}

export function setDraft(session, questionId, value) {
  if (!getQuestion(questionId)) return;
  session.drafts[questionId] = textOf(value);
  touch(session);
}

export function advanceHelp(session, questionId) {
  const question = getQuestion(questionId);
  if (!question) return 0;
  if (session.complete || (session.chatMode ? getCurrentQuestion(session)?.id !== questionId : !getCurrentBatch(session)?.questionIds.includes(questionId))) return telemetryFor(session, questionId).maxHelpLevel;
  const telemetry = telemetryFor(session, questionId);
  telemetry.stalled = true;
  telemetry.usedHelp = true;
  telemetry.maxHelpLevel = Math.min(3, telemetry.maxHelpLevel + 1);
  const guidance = getGuidance(session, questionId);
  if (telemetry.maxHelpLevel === 1) append(session, 'assistant', `我们先看个例子：${guidance.example || question.example || '可以从最近一次实际发生的事说起。'}`, { questionIds: [questionId], helpLevel: 1, guidanceCategory: guidance.categoryId, productIntro: guidance.productIntro });
  else if (telemetry.maxHelpLevel === 2) append(session, 'assistant', `如果更接近下面哪种情况，可以选一个，再用自己的话补充：\n${(guidance.options || question.options || []).map((option) => `· ${option}`).join('\n')}`, { questionIds: [questionId], helpLevel: 2 });
  else if (!session.messages.some((message) => message.helpLevel === 3 && message.questionIds?.includes(questionId))) append(session, 'assistant', '这块可以先空着，往下走，后面再补。', { questionIds: [questionId], helpLevel: 3 });
  touch(session);
  return telemetry.maxHelpLevel;
}

export function isWeakNeed(value) {
  const text = textOf(value).replace(/[“”「」"']/g, '');
  if (!text.trim()) return false;
  // Explicitly discussing and rejecting the weak answer must not trigger a stop.
  const cleaned = text
    .replace(/(?:也行|凑合(?:也能过)?|忍忍就过去(?:了)?)(?:是(?:不对|错)的|这个说法不成立|这种说法不成立)/g, '')
    .replace(/(?:不是|并非|并不是|不觉得|不能说|不能算|不会|不可能|绝非|谈不上|不能|不愿意|不接受|不想|无法)[^，。；!?！？\n]{0,10}(?:也行|凑合(?:也能过)?|忍忍(?:就过去(?:了)?)?)/g, '')
    .replace(/不(?:也行|凑合(?:也能过)?|忍忍(?:就过去(?:了)?)?)/g, '');
  if (/(?:也行|凑合(?:也能过)?|忍忍就(?:过去|过了)|忍一忍就过去)/.test(cleaned)) return true;
  return /(?:没有|不用|不买)[^，。；!?！？\n]{0,18}(?:也可以|无所谓|没什么影响|没有影响|不影响|照样过)/.test(cleaned);
}

function signalFor(questionId, value) {
  const text = textOf(value).trim();
  if (!text) return ['R0-Q1', 'R2-Q2', 'R4-Q3'].includes(questionId)
    ? { signal: 'red', reason: '该项暂时留白，需要在收口时记录信息缺口。' }
    : { signal: 'none', reason: '' };
  if (questionId === 'R2-Q3' && isWeakNeed(text)) return { signal: 'red', reason: '口述中表示没有本产品也可以，需提前收口核实需求。' };
  const transferText = text
    .replace(/(?:不需要|不用|无需|不必)重新(?:建立|建|做)/g, '')
    .replace(/(?:不是|并非|并不是)[^，。；!?！？\n]{0,8}(?:无关|不相关|没关系|用不上|不能直接|无法直接|不能迁移|需要重新(?:建立|建|做))/g, '');
  if (questionId === 'R4-Q2' && /(?:完全|基本|确实|其实|都)?(?:无关|不相关|没关系|用不上|不能直接|无法直接|不能迁移)|需要重新(?:建立|建|做)|都要重新|没有可迁移/.test(transferText)) return { signal: 'yellow', reason: '口述中有条件尚不能直接用于新品，需要在收口时核实。' };
  if (questionId === 'R0-Q1' && (text.match(/[。！？!?]/g) || []).length > 2) return { signal: 'red', reason: '产品描述尚未收拢为一句话，仍需核实具体对象。' };
  const rules = {
    'R0-Q1': /就是那个|类似于|不知(?:道)?怎么说|说不清/,
    'R0-Q3': /行业都在做|同行都在做|同行在做|我们得有个新品|感觉有机会|跟风/,
    'R1-Q2': /没什么办法[^。]{0,10}忍|没有办法[^。]{0,10}忍|就忍着|只能忍/,
    'R1-Q3': /不会主动找|不主动(?:去)?找|不会专门找|不(?:会|去)搜索|很少主动找/,
    'R2-Q2': /不知道什么时候|说不出(?:具体)?时|没有具体(?:时|场景)|不清楚什么时候|随时|任何时候|需要的时候/,
    'R3-Q3': /三个月[^。]{0,10}(?:抄|做)|(?:一|两|二|三|1|2|3)个月(?:就)?(?:能|可以|足够)|很容易(?:抄|做)|很快(?:就能|能|可以)(?:抄|做)/,
    'R3-Q4': /成本[^。]{0,15}(?:加|利润|%|％)|成本加成/,
    'R4-Q3': /不知道|说不清|答不上|没(?:有|什么)(?:了|剩|其他)|不剩|还没找到/,
  };
  return rules[questionId]?.test(text) ? { signal: 'red', reason: '该项口述需要在收口时列为待核实信息。' } : { signal: 'none', reason: '' };
}

function applySignal(session, questionId, value) {
  const result = signalFor(questionId, value);
  Object.assign(telemetryFor(session, questionId), { signal: result.signal, signalReason: result.reason });
  return { questionId, ...result };
}

function clarificationFor(questionId, value) {
  const text = textOf(value).trim();
  if (/就是那个|类似于|大概就是那|怎么说呢/.test(text)) return getQuestion(questionId)?.clarification || '你用一个具体的名词叫它什么？';
  if (questionId === 'R0-Q1' && (text.match(/[。！？!?]/g) || []).length > 2) return '如果只用一个名词和一句话，你会怎么介绍它？';
  if (questionId === 'R1-Q1' && /岁|女性|男性|年轻人|宝妈|中产|上班族|白领|人群/.test(text)
    && !/昨天|前天|最近一次|一位|一个|他在|她在|住在|住|经理|设计师|老师|护士|司机|工作|每天|加班/.test(text)) return '这里面最典型的那个人，昨天一天都做了什么？';
  return '';
}

export function submitBatch(session, answers = {}, { extras = {} } = {}) {
  // The UI may pass its extraDrafts object directly; preserve the submitted
  // original before clearing committed draft fields below.
  extras = { ...extras };
  const batch = getCurrentBatch(session);
  if (!batch) return { ok: false, errors: { session: '本次问询已结束。' }, complete: Boolean(session.complete) };
  const errors = {};
  for (const id of batch.questionIds) {
    const value = textOf(Object.hasOwn(answers, id) ? answers[id] : session.drafts[id]);
    setDraft(session, id, value);
    if (!value.trim() && telemetryFor(session, id).maxHelpLevel < 3) errors[id] = '可以先看看案例；如果仍答不上，再看选项，最后可以暂时留白。';
  }
  if (Object.keys(errors).length) return { ok: false, errors, complete: false };
  for (const id of batch.questionIds) {
    const telemetry = telemetryFor(session, id);
    const prompt = clarificationFor(id, session.drafts[id]);
    if (prompt && telemetry.clarificationCount < 1) {
      telemetry.clarificationCount += 1;
      telemetry.stalled = true;
      append(session, 'user', batch.questionIds.map((qid) => `${getQuestion(qid).title}\n${session.drafts[qid] || '（暂时留白）'}${textOf(extras[qid]).trim() ? `\n补充原话：${textOf(extras[qid])}` : ''}`).join('\n\n'), { questionIds: batch.questionIds, kind: 'clarification-original' });
      append(session, 'assistant', prompt, { questionIds: [id], kind: 'clarification' });
      touch(session);
      return { ok: false, errors: {}, complete: false, clarification: { questionId: id, prompt } };
    }
    if (prompt) telemetry.clarificationUnresolved = true;
  }
  // The scene may appear for the first time in this very submission. Ask once
  // before advancing so that this conditional follow-up cannot disappear.
  if (batch.questionIds.includes('R2-Q2')) {
    const social = getSocialContext({ answers: { ...session.answers, ...session.drafts } });
    const telemetry = telemetryFor(session, 'R2-Q2');
    if (social.status === 'present' && !telemetry.socialFollowUpAsked) {
      telemetry.socialFollowUpAsked = true;
      telemetry.changedRoute = true;
      session.routeLog.push({ questionId: 'R2-Q2', route: 'conditional-follow-up', at: now(), reason: '口述同时提及结伴进行与结果当场可比较，补充一次开放追问。' });
      const prompt = '一起进行的都是谁？这个人在同伴面前最在意什么？可以补充在这题里；暂时不知道也可以说明。';
      append(session, 'user', batch.questionIds.map((id) => `${getQuestion(id).title}\n${session.drafts[id] || '（暂时留白）'}${textOf(extras[id]).trim() ? `\n补充原话：${textOf(extras[id])}` : ''}`).join('\n\n'), { questionIds: batch.questionIds, kind: 'follow-up-original' });
      append(session, 'assistant', prompt, { questionIds: ['R2-Q2'], kind: 'conditional-follow-up' });
      touch(session);
      return { ok: false, errors: {}, complete: false, clarification: { questionId: 'R2-Q2', prompt, kind: 'conditional-follow-up' } };
    }
  }
  const signals = [];
  for (const id of batch.questionIds) {
    session.answers[id] = session.drafts[id];
    const telemetry = telemetryFor(session, id);
    telemetry.skipped = !session.answers[id].trim();
    telemetry.volunteeredExtra = textOf(extras[id]);
    signals.push(applySignal(session, id, session.answers[id]));
    delete session.drafts[id];
    if (session.extraDrafts) delete session.extraDrafts[id];
  }
  append(session, 'user', batch.questionIds.map((id) => `${getQuestion(id).title}\n${session.answers[id] || '（暂时留白）'}${textOf(extras[id]).trim() ? `\n补充原话：${textOf(extras[id])}` : ''}`).join('\n\n'), { questionIds: batch.questionIds, batchId: batch.id });
  if (batch.questionIds.includes('R0-Q2')) {
    const stage = session.answers['R0-Q2'];
    const routeText = stage
      .replace(/(?:不是|并非|并不是|不只是)[^，。；!?！？\n]{0,8}(?:想法|还没落地|没做出来)/g, '')
      .replace(/(?:不是|并非|并不是|还不是)[^，。；!?！？\n]{0,8}(?:已经做出来|已经做好|已有样品|已经完成|已经落地|已经上市)/g, '');
    const made = /已经(?:做出来|做出|做好|在卖|有样品|生产)|(?:样品|产品)(?:已经|已)?(?:做出来|做好|完成)|准备(?:卖|上市)|已经有(?:产品|成品)|已(?:生产|上市|落地)|做出了?样品|有(?:成品|现货)|正在(?:卖|销售)/.test(routeText)
      && !/还没(?:做出来|落地|做好)|尚未落地|只是想法|有个想法/.test(routeText);
    const previous = session.route;
    session.route = made ? 'made' : 'idea';
    session.batchOrder = batchOrder(made ? MADE_ROUNDS : IDEA_ROUNDS);
    telemetryFor(session, 'R0-Q2').changedRoute = previous !== session.route;
    session.routeLog.push({ questionId: 'R0-Q2', route: session.route, at: now(), reason: made ? '口述产品已做出，先记录市场选择和已有条件。' : stage.trim() ? '按本次阶段口述，先记录购买者与具体时刻。' : '阶段暂未明确，按默认顺序先记录购买者与具体时刻。' });
  }
  const stop = batch.questionIds.includes('R2-Q3') && telemetryFor(session, 'R2-Q3').signal === 'red';
  session.batchIndex += 1;
  if (stop) {
    session.stopReason = 'weak-need';
    telemetryFor(session, 'R2-Q3').changedRoute = true;
    session.routeLog.push({ questionId: 'R2-Q3', route: 'early-report', at: now(), reason: '按口述的“没有它也可以”提前整理事实与待验证问题。' });
  }
  if (stop || session.batchIndex >= session.batchOrder.length) {
    session.complete = true;
    session.report = buildReport(session);
    append(session, 'assistant', stop ? '先把目前说到的事实、还没对上的地方和需要核实的问题整理出来。常规提问到这里。' : '这轮问询已经完成。下面整理事实、还没对上的地方，以及需要核实的问题。', { kind: 'report-ready' });
  } else {
    append(session, 'assistant', '这些信息已记录。我们接着看下一组。', { kind: 'confirmation' });
    appendBatchPrompt(session);
  }
  touch(session);
  return { ok: true, complete: session.complete, signals, stopReason: session.stopReason };
}

function stageRoute(stage) {
  const routeText = textOf(stage)
    .replace(/(?:不是|并非|并不是|不只是)[^，。；!?！？\n]{0,8}(?:想法|还没落地|没做出来)/g, '')
    .replace(/(?:不是|并非|并不是|还不是)[^，。；!?！？\n]{0,8}(?:已经做出来|已经做好|已有样品|已经完成|已经落地|已经上市)/g, '');
  const made = /已经(?:做出来|做出|做好|在卖|有样品|生产)|(?:样品|产品)(?:已经|已)?(?:做出来|做好|完成)|准备(?:卖|上市)|已经有(?:产品|成品)|已(?:生产|上市|落地)|做出了?样品|有(?:成品|现货)|正在(?:卖|销售)/.test(routeText)
    && !/还没(?:做出来|落地|做好)|尚未落地|只是想法|有个想法/.test(routeText);
  return made ? 'made' : 'idea';
}

const orderedQuestionIds = (session) => (session.route === 'made' ? MADE_ROUNDS : IDEA_ROUNDS)
  .flatMap((round) => QUESTIONS.filter((question) => question.round === round).map((question) => question.id));

function syncBatchCursor(session) {
  session.batchOrder = batchOrder(session.route === 'made' ? MADE_ROUNDS : IDEA_ROUNDS);
  const next = session.batchOrder.findIndex((id) => {
    const batch = ROUND_BATCHES.find((entry) => entry.id === id);
    return batch.questionIds.some((qid) => !Object.hasOwn(session.answers, qid));
  });
  session.batchIndex = next < 0 ? session.batchOrder.length : next;
}

/** Upgrade only the display model. Previously recorded originals are never rewritten. */
export function upgradeToChat(session) {
  if (!session || typeof session !== 'object') return session;
  session.answers ||= {};
  session.drafts ||= {};
  session.questionTelemetry ||= {};
  session.messages ||= [];
  session.routeLog ||= [];
  for (const question of QUESTIONS) telemetryFor(session, question.id);
  if (!session.chatMode) {
    const visited = [];
    for (const message of session.messages) for (const id of message.questionIds || []) {
      if (Object.hasOwn(session.answers, id) && getQuestion(id) && !visited.includes(id)) visited.push(id);
    }
    for (const id of orderedQuestionIds(session)) if (Object.hasOwn(session.answers, id) && !visited.includes(id)) visited.push(id);
    session.chatTurns = visited.map((id) => {
      const first = session.messages.find((message) => message.questionIds?.includes(id));
      return { questionId: id, prompt: getQuestion(id).title, askedAt: first?.at || session.createdAt || now(),
        answeredAt: first?.at || session.updatedAt || now(), revisions: 0 };
    });
    session.chatMode = true;
    session.interactionVersion = 4;
    session.answerRevisions ||= [];
    session.feedbackHistory ||= [];
    session.reportRevision ||= session.report ? 1 : 0;
    syncBatchCursor(session);
  }
  ensureChatPrompt(session);
  return session;
}

export function createChatSession(options = {}) {
  const session = createSession(options);
  // These prompts were created just above; no existing transcript is removed.
  session.messages = session.messages.filter((message) => !message.batchId);
  return upgradeToChat(session);
}

export function getCurrentQuestion(session) {
  if (!session || session.complete) return null;
  const id = orderedQuestionIds(session).find((qid) => !Object.hasOwn(session.answers || {}, qid));
  return getQuestion(id) || null;
}

function ensureChatPrompt(session) {
  if (!session.chatMode) return;
  const question = getCurrentQuestion(session);
  if (!question) return;
  if (session.pendingClarification && session.pendingClarification.questionId !== question.id) {
    session.suspendedClarifications ||= {};
    session.suspendedClarifications[session.pendingClarification.questionId] = session.pendingClarification;
    delete session.pendingClarification;
  }
  if (!session.pendingClarification && session.suspendedClarifications?.[question.id]) {
    session.pendingClarification = session.suspendedClarifications[question.id];
    delete session.suspendedClarifications[question.id];
  }
  session.chatTurns ||= [];
  const found = session.chatTurns.find((turn) => turn.questionId === question.id);
  if (!found) session.chatTurns.push({ questionId: question.id, prompt: question.title, askedAt: now(), revisions: 0 });
  const lastQuestion = [...session.messages].reverse().find((message) => message.kind === 'chat-question');
  if (!session.pendingClarification && (!lastQuestion || lastQuestion.questionIds?.[0] !== question.id)) {
    append(session, 'assistant', `${question.title}\n${question.body || ''}`, { questionIds: [question.id], kind: 'chat-question' });
  }
}

/** Read-only view for rendering, with a single live question at the bottom. */
export function getChatTurns(session) {
  if (!session) return [];
  const active = getCurrentQuestion(session)?.id;
  const saved = Array.isArray(session.chatTurns) ? session.chatTurns : [];
  const answered = saved.filter((turn) => Object.hasOwn(session.answers || {}, turn.questionId));
  const seen = new Set(answered.map((turn) => turn.questionId));
  for (const id of orderedQuestionIds(session)) if (Object.hasOwn(session.answers || {}, id) && !seen.has(id)) {
    answered.push({ questionId: id, prompt: getQuestion(id).title, askedAt: session.createdAt, answeredAt: session.updatedAt });
    seen.add(id);
  }
  const turns = [...answered];
  if (active && !seen.has(active)) turns.push(saved.find((turn) => turn.questionId === active) || { questionId: active, prompt: getQuestion(active).title, askedAt: session.updatedAt });
  return turns.map((turn) => {
    const committed = Object.hasOwn(session.answers || {}, turn.questionId);
    const pending = session.pendingClarification?.questionId === turn.questionId ? session.pendingClarification : null;
    return { ...turn, question: getQuestion(turn.questionId), answered: committed,
      answer: committed ? session.answers[turn.questionId] : pending?.originalAnswer,
      extra: committed ? session.questionTelemetry?.[turn.questionId]?.volunteeredExtra || '' : pending?.originalExtra || '',
      pendingAnswer: pending?.originalAnswer, clarification: pending?.prompt || null,
      clarificationKind: pending?.kind || null,
      revisions: session.answerRevisions?.filter((revision) => revision.questionId === turn.questionId).length || 0 };
  });
}

export function getReviewQuestions(session) {
  return getChatTurns(session).map((turn, index) => {
    const help = [...(session.messages || [])].reverse().find((message) => message.helpLevel === 1 && message.questionIds?.includes(turn.questionId));
    return { questionId: turn.questionId, title: turn.prompt || turn.question.title,
      answer: turn.answer ?? '', extra: turn.extra || '', answered: turn.answered,
      helpLevel: session.questionTelemetry?.[turn.questionId]?.maxHelpLevel || 0,
      example: help?.text || '', productIntro: help?.productIntro || '', order: index + 1 };
  });
}

function setChatRoute(session, stage, kind = 'chat-answer') {
  const before = session.route;
  session.route = stageRoute(stage);
  const changed = before !== session.route;
  telemetryFor(session, 'R0-Q2').changedRoute ||= changed;
  session.routeLog.push({ questionId: 'R0-Q2', route: session.route, at: now(), kind,
    reason: changed ? '根据更新后的产品阶段，调整尚未回答的问题顺序；已有回答保留。' : '记录当前产品阶段。' });
  syncBatchCursor(session);
  return changed;
}

function invalidateFeedback(session, reason) {
  if (session.feedback) {
    session.feedbackHistory ||= [];
    session.feedbackHistory.push({ ...session.feedback, reportRevision: session.reportRevision || 0, invalidatedAt: now(), reason });
    session.feedback = null;
    session.feedbackNeedsReview = true;
  }
}

function refreshChatStatus(session) {
  const weak = Object.hasOwn(session.answers, 'R2-Q3') && telemetryFor(session, 'R2-Q3').signal === 'red';
  session.stopReason = weak ? 'weak-need' : null;
  session.complete = weak || orderedQuestionIds(session).every((id) => Object.hasOwn(session.answers, id));
  syncBatchCursor(session);
  if (session.complete) {
    session.reportRevision = (session.reportRevision || 0) + 1;
    session.report = { ...buildReport(session), revision: session.reportRevision };
  } else session.report = null;
}

function beginClarification(session, question, answer, extra, prompt, kind, recordAnswer = true) {
  session.pendingClarification = { questionId: question.id, originalAnswer: answer, originalExtra: extra, prompt, kind, at: now() };
  session.drafts[question.id] = '';
  if (recordAnswer) append(session, 'user', `${answer || '（暂时留白）'}${extra ? `\n补充原话：${extra}` : ''}`, { questionIds: [question.id], kind: 'chat-clarification-original', answerText: answer });
  append(session, 'assistant', prompt, { questionIds: [question.id], kind });
  touch(session);
  return { ok: false, errors: {}, complete: false, clarification: { questionId: question.id, prompt, kind } };
}

export function submitChatAnswer(session, questionId, value, { extra = '' } = {}) {
  upgradeToChat(session);
  const question = getCurrentQuestion(session);
  if (!question || question.id !== questionId) return { ok: false, errors: { [questionId || 'session']: question ? '请先回答当前这个问题。' : '本次问询已经结束，可在原问题处修改回答。' }, complete: Boolean(session.complete) };
  const entered = textOf(value), suppliedExtra = textOf(extra);
  setDraft(session, questionId, entered);
  const telemetry = telemetryFor(session, questionId);
  if (!entered.trim() && telemetry.maxHelpLevel < 3) return { ok: false, errors: { [questionId]: '可以先看一个例子；仍说不清时，再看选项，最后可以留白。' }, complete: false };
  const pending = session.pendingClarification?.questionId === questionId ? session.pendingClarification : null;
  let answer = entered, answerExtra = suppliedExtra;
  if (pending) {
    answer = entered.trim() && entered.trim() !== pending.originalAnswer.trim()
      ? `${pending.originalAnswer}\n\n补充：${entered}` : pending.originalAnswer;
    answerExtra = suppliedExtra && suppliedExtra !== pending.originalExtra
      ? [pending.originalExtra, suppliedExtra].filter(Boolean).join('\n') : pending.originalExtra;
    append(session, 'user', `${entered || '（暂时留白）'}${suppliedExtra ? `\n补充原话：${suppliedExtra}` : ''}`, { questionIds: [questionId], kind: 'chat-clarification-answer', answerText: entered });
    delete session.pendingClarification;
  }
  const prompt = clarificationFor(questionId, answer);
  if (!pending && prompt && telemetry.clarificationCount < 1) {
    telemetry.clarificationCount += 1;
    telemetry.stalled = true;
    return beginClarification(session, question, answer, answerExtra, prompt, 'clarification');
  }
  if (prompt) telemetry.clarificationUnresolved = true;
  if (questionId === 'R2-Q2') {
    const social = getSocialContext({ answers: { ...session.answers, [questionId]: answer } });
    if (social.status === 'present' && !telemetry.socialFollowUpAsked) {
      telemetry.socialFollowUpAsked = true;
      telemetry.changedRoute = true;
      session.routeLog.push({ questionId, route: 'conditional-follow-up', at: now(), reason: '口述同时提及结伴进行和结果当场可比较，补充一次开放追问。' });
      return beginClarification(session, question, answer, answerExtra, '当时和他一起的是谁？一起做这件事时，他有没有特别在意的事情？不知道也可以直说。', 'conditional-follow-up', !pending);
    }
  }
  session.answers[questionId] = answer;
  telemetry.skipped = !answer.trim();
  telemetry.volunteeredExtra = answerExtra;
  const signal = applySignal(session, questionId, answer);
  delete session.drafts[questionId];
  if (session.extraDrafts) delete session.extraDrafts[questionId];
  if (!pending) append(session, 'user', `${entered || '（暂时留白）'}${suppliedExtra ? `\n补充原话：${suppliedExtra}` : ''}`, { questionIds: [questionId], kind: 'chat-answer', answerText: entered });
  const turn = session.chatTurns.find((entry) => entry.questionId === questionId);
  if (turn) turn.answeredAt = now();
  if (questionId === 'R0-Q1') session.title = answer.trim().slice(0, 30) || session.title;
  if (questionId === 'R0-Q2') setChatRoute(session, answer);
  if (questionId === 'R2-Q3' && signal.signal === 'red') {
    telemetry.changedRoute = true;
    session.routeLog.push({ questionId, route: 'early-report', at: now(), reason: '根据这次口述，先整理现有信息与需要核实的问题。' });
  }
  refreshChatStatus(session);
  if (session.complete) append(session, 'assistant', '已经把这次对话整理好了。你可以往上查看、修改任何一条回答，报告会随之更新。', { kind: 'report-ready' });
  else ensureChatPrompt(session);
  touch(session);
  return { ok: true, complete: session.complete, signals: [signal], stopReason: session.stopReason };
}

export function reviseChatAnswer(session, questionId, value, { extra, mode = 'replace' } = {}) {
  upgradeToChat(session);
  if (!getQuestion(questionId) || !Object.hasOwn(session.answers, questionId)) return { ok: false, errors: { [questionId]: '这条回答尚未完成，请在当前对话里继续。' }, complete: Boolean(session.complete) };
  if (!['replace', 'append'].includes(mode)) return { ok: false, errors: { [questionId]: '请选择修改或补充回答。' }, complete: Boolean(session.complete) };
  const entered = textOf(value);
  if (!entered.trim()) return { ok: false, errors: { [questionId]: '请写下要修改或补充的内容；原有回答会保留。' }, complete: Boolean(session.complete) };
  const beforeAnswer = session.answers[questionId], beforeExtra = telemetryFor(session, questionId).volunteeredExtra;
  const afterAnswer = mode === 'append' ? [beforeAnswer, `补充：${entered}`].filter(Boolean).join('\n\n') : entered;
  const afterExtra = extra === undefined ? beforeExtra : mode === 'append'
    ? [beforeExtra, textOf(extra)].filter(Boolean).join('\n') : textOf(extra);
  if (afterAnswer === beforeAnswer && afterExtra === beforeExtra) return { ok: true, complete: session.complete, reopened: false, routeChanged: false, changed: false };
  const beforeComplete = session.complete, beforeRoute = session.route;
  if (session.report) {
    session.reportHistory ||= [];
    session.reportHistory.push({ reportRevision: session.reportRevision || 0, report: session.report, archivedAt: now(), reason: '回答已修改，保留原报告供反馈复核。' });
  }
  session.answerRevisions ||= [];
  session.answerRevisions.push({ questionId, beforeAnswer, afterAnswer, beforeExtra, afterExtra,
    submittedText: entered, mode, at: now(), reportRevision: session.reportRevision || 0 });
  append(session, 'user', `${mode === 'append' ? '补充' : '修改'}「${getQuestion(questionId).title}」\n${entered}${extra !== undefined ? `\n补充原话：${textOf(extra)}` : ''}`, { questionIds: [questionId], kind: 'answer-revision', revisionMode: mode, answerText: entered });
  session.answers[questionId] = afterAnswer;
  const telemetry = telemetryFor(session, questionId);
  telemetry.volunteeredExtra = afterExtra;
  telemetry.skipped = false;
  const explicitlyStronger = questionId === 'R2-Q3' && mode === 'append'
    && /不是也行|不是凑合|没有它不行|现有[^。！？]{0,12}不够|仍有[^。！？]{0,12}困扰|不能再凑合|不愿[^。！？]{0,8}凑合/.test(entered);
  applySignal(session, questionId, explicitlyStronger ? entered : afterAnswer);
  if (questionId === 'R0-Q2') {
    const stage = mode === 'append' && /阶段|样品|做|想法|落地|上市|成品|准备卖/.test(entered) ? entered : afterAnswer;
    setChatRoute(session, stage, 'answer-revision');
  }
  if (questionId === 'R0-Q1') session.title = afterAnswer.trim().slice(0, 30) || session.title;
  invalidateFeedback(session, '回答已修改，请结合更新后的对话重新确认反馈。');
  if (session.pendingClarification?.questionId === questionId) delete session.pendingClarification;
  refreshChatStatus(session);
  const reopened = beforeComplete && !session.complete;
  if (reopened) append(session, 'assistant', '已更新这条回答。我们从还没聊到的问题继续，原来的回答都保留着。', { kind: 'conversation-reopened' });
  if (!session.complete) ensureChatPrompt(session);
  touch(session);
  return { ok: true, complete: session.complete, reopened, routeChanged: beforeRoute !== session.route };
}

export function getProgress(session) {
  const answered = Object.keys(session.answers || {}).filter((id) => getQuestion(id)).length;
  return { answered, total: QUESTIONS.length, percent: Math.round(answered / QUESTIONS.length * 100),
    completedBatches: session.batchIndex, totalBatches: session.batchOrder?.length || ROUND_BATCHES.length };
}

const FEEDBACK_LABELS = {
  valuableQuestion: '回看问题，哪些对你有帮助？', uselessQuestion: '哪些问题重复、无关，或可以少问？',
  missedQuestion: '聊完后，还有什么你想说却没被问到？', guidance: '哪些问题或例子仍不好理解？',
};
const FEEDBACK_SELECTIONS = ['valuableQuestionIds', 'uselessQuestionIds', 'unclearQuestionIds'];
export function validateFeedback(feedback = {}, session = null) {
  const errors = {};
  for (const [key, label] of Object.entries(FEEDBACK_LABELS)) {
    const selected = key === 'valuableQuestion' ? feedback.valuableQuestionIds : key === 'uselessQuestion' ? feedback.uselessQuestionIds : null;
    if (!textOf(feedback[key]).trim() && !(Array.isArray(selected) && selected.length)) errors[key] = `请填写：${label}没有也可以写“暂无”。`;
  }
  const asked = session ? new Set(getReviewQuestions(session).map((question) => question.questionId)) : null;
  for (const key of FEEDBACK_SELECTIONS) {
    if (!Object.hasOwn(feedback, key)) continue;
    if (!Array.isArray(feedback[key]) || feedback[key].some((id) => typeof id !== 'string' || !getQuestion(id) || (asked && !asked.has(id)))) errors[key] = '请从本次已经展示的问题里选择。';
  }
  if (!['产品负责人', '工厂方', '渠道方', '营销人', '其他'].includes(feedback.role)) errors.role = '请选择被试者身份。';
  if (typeof feedback.awareOfTest !== 'boolean') errors.awareOfTest = '请选择是否事先知道这是测试系统。';
  return { ok: !Object.keys(errors).length, errors };
}

export function saveFeedback(session, feedback) {
  if (!session.complete) return { ok: false, errors: { session: '报告生成后再填写本次反馈。' } };
  const result = validateFeedback(feedback, session);
  if (!result.ok) return result;
  session.feedback = Object.fromEntries([...Object.keys(FEEDBACK_LABELS), 'role', 'awareOfTest'].map((key) => [key, feedback[key]]));
  for (const key of FEEDBACK_SELECTIONS) if (Array.isArray(feedback[key])) session.feedback[key] = [...new Set(feedback[key])];
  session.feedback.reportRevision = session.reportRevision || 0;
  session.feedback.submittedAt = now();
  session.feedbackNeedsReview = false;
  touch(session);
  return result;
}

export function exportSessionJSON(session) {
  return JSON.parse(JSON.stringify({ ...session,
    export: { version: ENGINE_VERSION, questionCopyVersion: COPY_VERSION, interactionVersion: session.interactionVersion || 3, exportedAt: now(), status: !session.complete ? '问询未完成的草稿' : session.feedback ? '已完成的试跑档案' : '报告已生成，反馈待填写',
      feedbackComplete: Boolean(session.feedback), externalSearchPerformed: false },
    rawTranscript: session.messages, diagnosis: session.report, verificationGaps: session.report?.gaps || [],
    questionReview: getReviewQuestions(session),
    judgments: session.report?.judgments || [],
    perQuestion: QUESTIONS.map((question) => ({ questionId: question.id, question: question.title,
      answer: session.answers[question.id] ?? null, draft: session.drafts[question.id] ?? null,
      extraDraft: session.extraDrafts?.[question.id] ?? null,
      ...telemetryFor(session, question.id) })),
  }));
}

export function exportSessionMarkdown(session) {
  const exported = exportSessionJSON(session);
  const lines = [`# 新品有数 · 试跑档案`, '', `状态：${exported.export.status}`, `存档版本：${ENGINE_VERSION}`, `问法版本：${COPY_VERSION}`, `交互版本：${session.interactionVersion || 3}`, `会话：${session.id}`, `生成时间：${exported.export.exportedAt}`, '',
    '## 对话全文', ''];
  for (const message of session.messages) lines.push(`### ${message.role === 'user' ? '用户' : '新品有数'} · ${message.at}`, '', message.text, '');
  if (session.report) {
    const report = session.report;
    lines.push('## 诊断报告', '');
    for (const section of report.sections) {
      lines.push(`### ${section.title}`, '');
      if (section.definition) lines.push(section.definition, '');
      if (section.facts) {
        lines.push('用户口述 / 会话记录：', '');
        for (const fact of section.facts) lines.push(`- ${fact.id}［${fact.source} · ${fact.status}］${fact.text}`);
        lines.push('', '外部已查证事实：无。', section.note || '', '');
      }
      if (section.contradictions) lines.push(...(section.contradictions.length ? section.contradictions : [section.note]), '');
      if (section.judgments) for (const card of section.judgments) lines.push(`#### ${card.id} ${card.title}`, '', `判断：${card.judgment}`, `依据：${card.basisFactIds.join('、')}`, `推翻条件：${card.overturnCondition}`, `置信度：${card.confidence}`, '');
      if (section.gaps) for (const gap of section.gaps) lines.push(`- 缺口：${gap.gap}`, `  - 为什么关键：${gap.why}`, `  - 验证动作：${gap.action}`, `  - 判定标准：${gap.criterion}`, '');
      if (section.candidates) for (const candidate of section.candidates) lines.push(`- ${candidate.label}：${candidate.scene}`, `  - 待验证：${candidate.validation}`, '');
      if (section.deferred) lines.push(...section.deferred.map((item) => `- ${item}`), '');
    }
  }
  lines.push('## 四项校正', '');
  if (session.feedback) {
    for (const [key, label] of Object.entries(FEEDBACK_LABELS)) lines.push(`### ${label}`, '', textOf(session.feedback[key]), '');
    lines.push(`身份：${session.feedback.role}`, `事先知情这是测试系统：${session.feedback.awareOfTest ? '是' : '否'}`, '');
    for (const [key, label] of [['valuableQuestionIds', '有帮助的问题'], ['uselessQuestionIds', '重复或无关的问题'], ['unclearQuestionIds', '不好理解的问题']]) {
      if (session.feedback[key]?.length) lines.push(`${label}：${session.feedback[key].map((id) => `${id} ${getQuestion(id).title}`).join('；')}`, '');
    }
  } else lines.push('反馈尚未填写。此档案不能视作已完成的试跑档案。', '');
  if (session.feedbackHistory?.length) {
    lines.push('## 先前版本的反馈（回答修改后待重新确认）', '');
    for (const previous of session.feedbackHistory) {
      lines.push(`### 报告版本 ${previous.reportRevision ?? '未记录'} · ${previous.submittedAt || ''}`, '', `重新确认原因：${previous.reason || '回答已更新。'}`, '');
      for (const [key, label] of Object.entries(FEEDBACK_LABELS)) lines.push(`${label}`, textOf(previous[key]), '');
    }
  }
  if (session.answerRevisions?.length) {
    lines.push('## 回答修改记录', '');
    for (const revision of session.answerRevisions) lines.push(`### ${revision.questionId} · ${revision.at}`, '', `操作：${revision.mode === 'append' ? '补充' : '修改'}`, '', '修改前：', revision.beforeAnswer, '', '本次输入原话：', revision.submittedText, '', '当前回答：', revision.afterAnswer, '', '修改前补充原话：', revision.beforeExtra || '未提供', '', '当前补充原话：', revision.afterExtra || '未提供', '');
  }
  lines.push('## 逐题记录', '');
  for (const record of exported.perQuestion) lines.push(`- ${record.questionId}：${record.question}`, `  - 回答：${record.answer ?? '未回答'}`, `  - 未提交回答草稿：${record.draft ?? '未提供'}`, `  - 未提交补充原话：${record.extraDraft ?? '未提供'}`, `  - 卡壳：${record.stalled ? '是' : '否'}；使用引导：${record.usedHelp ? '是' : '否'}；最高引导级别：${record.maxHelpLevel}`, `  - 改变路由：${record.changedRoute ? '是' : '否'}；信号：${record.signal}；暂时留白：${record.skipped ? '是' : '否'}`, `  - 主动补充原话：${record.volunteeredExtra || '未提供'}`, '');
  return lines.join('\n');
}
