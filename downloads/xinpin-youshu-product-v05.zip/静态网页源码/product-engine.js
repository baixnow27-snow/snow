import { ENGINE_VERSION, QUESTIONS, ROUNDS, SCENARIOS, getQuestion, getGuidance } from './product-data.js';
import { buildDecisionReport } from './decision-report.js';

const at = () => new Date().toISOString();
const raw = value => typeof value === 'string' ? value : value == null ? '' : String(value);
const has = (object, key) => Object.hasOwn(object || {}, key);
const IDS = ['B1-brand','B2-portfolio','B3-sales','B4-channels','B5-capability','N1-scope','N2-stage','N3-commercial','M1-references','M2-observations','U1-user','U2-goal','U3-journey','U4-learning','U5-evidence','D1-outcome','D2-ideas','D3-delivery','D4-validation'];
const PROJECT_DEPENDENTS = IDS.filter(id => !id.startsWith('B') && id !== 'N1-scope');
const FEEDBACK_LABELS = { valuableQuestion:'回看问题，哪些对你有帮助？', uselessQuestion:'哪些问题重复、无关，或可以少问？', missedQuestion:'还有什么关于产品的事，你想说却没聊到？', guidance:'哪些问题或例子仍不好理解？' };
const FEEDBACK_SELECTIONS = ['valuableQuestionIds','uselessQuestionIds','unclearQuestionIds'];
const unknown = text => /不知道|不清楚|还没想好|还没确定|尚未确定|尚未确认|未确认|暂无统计|没有统计|暂时不确定|说不准|暂时没有|没有资料|没做过|没调研|还没调研|没问过|暂不提供|不便提供|不方便|保密|不透露|不公开|不想说|先留白|暂时跳过/.test(raw(text));
const undisclosed = text => /暂不提供|不便提供|不方便|保密|不透露|不公开|不想说/.test(raw(text));
const touch = session => { session.updatedAt = at(); };
const append = (session, role, text, metadata={}) => session.messages.push({role,text,at:at(),...metadata});
const telemetry = (session,id) => session.questionTelemetry[id] ||= {stalled:false,usedHelp:false,maxHelpLevel:0,clarificationCount:0,changedRoute:false,volunteeredExtra:'',skipped:false,signal:'none'};
const segments = (session,id) => session.answerParts?.[id]?.map(part=>raw(part.text)) || (has(session.answers,id) ? [raw(session.answers[id])] : []);
const latest = (session,id) => segments(session,id).at(-1) || '';
const answer = (session,id) => raw(session.answers?.[id]);
const joined = parts => parts.map(part=>raw(part.text)).filter(Boolean).join('\n\n补充：');
const effective = (session,id) => session.pendingScopeConfirmation && PROJECT_DEPENDENTS.includes(id) ? '' : answer(session,id);
const marketText = text => { const matches=raw(text).match(/中国大陆|国内市场|国内|海外市场|海外|国际市场|国际|北美|美国|加拿大|欧洲|欧盟|英国|日本|韩国|东南亚|中东|澳洲|澳大利亚|全球|出口|中国/g);return matches?[...new Set(matches)].join('、'):''; };
const dequote = text => raw(text).replace(/[「」“”"']/g,'').trim();

function extractBrand(parts) {
  const text=parts.join('\n');
  if(/品牌[^。\n]{0,14}(?:尚未|还没|没有|暂未)(?:命名|名字|名称)|尚未命名|还没命名|未命名|暂未取名/.test(text))return '尚未命名';
  if(/(?:品牌|公司名|名字|名称)[^。\n]{0,14}(?:保密|不方便|不便提供|不公开|不透露)|(?:保密|不公开|不透露)[^。\n]{0,8}(?:品牌|公司名)/.test(text))return '不便提供';
  for(const original of [...parts].reverse()) {
    const part=raw(original).replace(/[（(](?:虚构|演示)[^）)]*[）)]/g,'');
    const explicit=dequote(part).match(/(?:品牌(?:名称)?|公司(?:名称)?)(?:叫做|叫|是|为|：|:|名为)\s*([^，。；\n]{1,28})/);
    if(explicit && !/一个|某个|某家|渔具牌子|渔具品牌|户外品牌|消费品牌/.test(explicit[1]))return explicit[1].replace(/(?:品牌|牌子)$/,'').trim();
    const first=dequote(part).split(/[，。；\n]/)[0].replace(/^(?:我们(?:公司|品牌)?(?:是|叫|暂用|使用)|公司叫|品牌叫|叫做|叫)/,'').trim();
    if(first && first.length<=24 && !/一个|某个|某家|品牌|牌子|公司|渔具|钓具|产品|国内|海外|国际|市场|不知道|不清楚|尚未|没有|还没|未命名|保密|不便|不方便|先做|目前|主要|我们做/.test(first))return first;
  }
  if(undisclosed(text))return '不便提供';
  return '';
}
function scopeFrom(text, clue='') {
  const value=raw(text).replace(/(?:不做|不开发|不讨论|不考虑|不包括|不是)[^，。；\n]{0,15}/g,''),all=value || raw(clue);
  const subtypes=[];
  if(/台钓|手竿|鲫鱼竿|鲤鱼竿/.test(value))subtypes.push('台钓竿');
  if(/海钓|船钓|矶钓|远投竿/.test(value))subtypes.push('海钓竿');
  if(/路亚|lure/i.test(value))subtypes.push('路亚竿');
  if(/飞蝇|fly fishing/i.test(value))subtypes.push('飞蝇竿');
  const focused=value.match(/(?:这次|本次|当前项目|先做|只做|聚焦|选定|选)(?:就|只|先|是|做|一款|的是|的是一款|在|一把|一支|一根)*[^，。；\n]{0,12}(台钓|海钓|路亚|飞蝇)/);
  let subcategory=focused?`${focused[1]}竿`:subtypes.length===1?subtypes[0]:'';
  const category=/钓竿|鱼竿|钓具|渔具|台钓|海钓|路亚|飞蝇/.test(all)?'钓竿':/牙刷/.test(all)?'牙刷':/帐篷/.test(all)?'帐篷':/鞋|徒步/.test(all)?'鞋':/人参|红参|饮品|饮料/.test(all)?'饮品':/水壶|保温壶/.test(all)?'水壶':/雨伞/.test(all)?'雨伞':'';
  if(!subcategory && category==='牙刷') {if(/电动/.test(value))subcategory='电动牙刷';else if(/手动/.test(value))subcategory='手动牙刷';else if(/儿童/.test(value))subcategory='儿童牙刷';}
  if(!subcategory && category==='饮品' && /(?:人参|红参)[^，。；\n]{0,12}(?:饮|原浆|小支)|(?:便携|小支)[^，。；\n]{0,12}(?:人参|红参)/.test(value))subcategory='人参便携饮品';
  if(!subcategory && category && !['钓竿','牙刷'].includes(category) && value.trim().length>=6 && !/都有|都做|各类|各种|还没定|没想好/.test(value))subcategory=value.trim();
  if(!category && value.trim().length>=6 && !/都有|周边|各类|各种|一个产品|新产品|还没定|没想好/.test(value))subcategory=value.trim();
  const named=value.match(/(?:项目(?:名|名称)?|产品(?:名|名称)?)(?:叫|是|为|：|:)\s*[「“"]?([^」”"，。；\n]{1,36})/);
  return {category,subcategory,name:named?named[1].trim():'',multiple:subtypes.length>1 && !focused,mentionedSubtypes:subtypes};
}
function revenueParts(parts) {
  const text=parts.join('\n');
  const periods=text.match(/20\d{2}(?:年度|年)?|去年|今年|上一年|上年度|近一年|过去一年|最近一年|本年度/g);
  const money=text.match(/(?:人民币|RMB|CNY|美元|USD|欧元|EUR|¥|￥|\$)?\s*(?:[0-9][0-9,.]*|[一二三四五六七八九十百千万亿两]+)\s*(?:(?:[-~～—至到]\s*)(?:[0-9][0-9,.]*|[一二三四五六七八九十百千万亿两]+)\s*)?(?:亿|千万|百万|十万|万元|万|千元|元|美元|人民币|USD|CNY|EUR)(?:左右|上下|以内|以上|以下)?/g);
  const amount=money?.filter(piece=>!/^20\d{2}元?$/.test(piece.trim())).at(-1)?.trim() || '';
  const notSelling=/尚未销售|还没销售|未销售|没有销售|还没开卖|没有收入|未上市|尚未上市/.test(text);
  return {annualRevenue:amount || (notSelling?'尚未销售':undisclosed(text)?'不便提供':unknown(text)?'尚未提供':text),revenuePeriod:periods?.at(-1) || (notSelling?'尚未销售':undisclosed(text)?'不便提供':'')};
}
function missingFor(session,id,parts) {
  const text=parts.map(part=>part.text).join('\n'),last=raw(parts.at(-1)?.text),lastScope=scopeFrom(last,session.projectClue),scope=lastScope.subcategory?lastScope:scopeFrom(text,session.projectClue);
  if(unknown(last) || (id==='B1-brand' && /尚未命名|未命名|还没命名/.test(last) && marketText(text)))return null;
  if(id==='B1-brand') {
    if(!extractBrand(parts.map(part=>part.text)))return {field:'brand',prompt:'你说的品牌具体叫什么？如果还没命名，或不方便提供名字，直接这样说也可以。'};
    if(!marketText(text))return {field:'companyMarket',prompt:'这个品牌目前主要做国内市场，还是也做海外？如果还没确定，可以说“市场还没定”。'};
  }
  if(id==='B2-portfolio' && (/^(?:我们(?:是|做)?|主要(?:是|做)?)?(?:钓具|渔具|钓竿|钓鱼竿|鱼竿|户外用品|产品|消费品)[。！]?$/u.test(text.trim()) || text.trim().length<3))return {field:'portfolio',prompt:'品牌目前有哪些产品线？比如钓具里是台钓竿、路亚竿、鱼线或其他周边，可以说多种；这一步先记公司范围。'};
  if(id==='B3-sales') {
    const revenue=revenueParts(parts.map(part=>part.text));
    if(!revenue.annualRevenue || (!/元|万|亿|美元|USD|CNY|EUR|千|百|十|人民币/.test(revenue.annualRevenue) && !/尚未销售|不便提供/.test(revenue.annualRevenue)))return {field:'annualRevenue',prompt:'能说一下某一年的销售额大概范围吗？不用精确数；还没销售、不方便透露或暂时不知道，也都可以直接说。'};
    if(!revenue.revenuePeriod)return {field:'revenuePeriod',prompt:'这个销售范围对应哪一年？说“去年”“2025年”都可以；年份不方便提供也没关系。'};
    if(/月销售|月销|每月/.test(text) && !/年销售|年销|年度|全年/.test(text))return {field:'annualRevenue',prompt:'你刚才说的是月销售。有没有最近一个完整年度的大概范围？如果没有年度口径，直接说“年度数据暂时没有”，我会保留月度原话。'};
  }
  if(id==='B4-channels') {
    if(/^(?:线上线下(?:都有|都有做)?|线上|线下|经销商|电商)[。！]?$/.test(text.trim()))return {field:'channels',prompt:'主要是哪些具体渠道？例如哪个电商平台、经销商、渔具店或自营门店。'};
    if(!/[0-9一二三四五六七八九十百千万几多]+\s*(?:家|个|间|位|名|省|城|县)|自营|旗舰店|直营|全国|多省|单店|小范围/.test(text))return {field:'channelScale',prompt:'这些渠道你们大概能直接触达多大范围？可以说门店、经销商或店铺的大概数量；暂时不知道或不便提供也可以。'};
  }
  if(id==='B5-capability') {
    if(!/工艺|碳布|开模|打样|设备|产线|生产线|配方|研发[^。\n]{0,10}(?:人|团队|工程)|[0-9一二三四五六七八九十]+\s*(?:人|年|项|台|天|周)|测试|检测|自有工厂|自己的工厂|专利|采购|供应商|装配|加工|小批量|供应关系|追溯|合作工厂|交付/.test(text))return {field:'capabilities',prompt:'能举一个具体例子吗：你们自己能做什么工艺、有没有研发或生产团队、能完成哪一步打样或交付？只说“技术强”还看不出能用在哪。'};
  }
  if(id==='N1-scope') {
    if(scope.category==='钓竿' && (!scope.subcategory || scope.multiple))return {field:'subcategory',prompt:'公司做的产品范围我记下了。我们这次先聚焦哪一款钓竿：台钓、海钓、路亚，还是另一种？先选本次项目，不替公司其他产品下结论。'};
    if(scope.category==='牙刷' && !scope.subcategory)return {field:'subcategory',prompt:'这次说的是哪一款牙刷？例如手动、电动或儿童用，请先聚焦本次准备开发的那一款。'};
    if(!scope.subcategory && !scope.name)return {field:'subcategory',prompt:'我们先把这次要讨论的一款产品说具体：它属于哪一种、准备给谁在什么活动里用？如果还没定，也可以明确说“本次产品暂时没定”。'};
  }
  if(id==='N2-stage' && !/想法|构想|样品|打样|开发|研发|上市|在卖|销售|成品|量产|试产|试用|没做出来|没做过|没有产品|概念/.test(text))return {field:'stage',prompt:'这款新品现在是只有想法、正在研发、已经有样品，还是已经在卖？它还没做出来也很正常。'};
  const vagueGoal=/^(?:希望|就是|想|要|让人|用户|他|她|更|很|比较|能|可以|觉得|感觉|主要是|产品|这款产品|新品|一点|一些|好玩|开心|好用|更好|沉稳|高级|有趣|轻松|体验好|方便|愉快|舒服|创新|品质好|美观|漂亮|时尚|\s|[，。！、])+$/;
  if((id==='U2-goal'||id==='D1-outcome')&&vagueGoal.test(last.trim()))return {field:'concreteOutcome',prompt:'你说的“'+last.trim().replace(/[，。！]/g,'')+'”，具体体现在使用者做哪件事、或感受到什么变化？可以是学会一步、看懂反馈、愿意和朋友参与，不一定是解决麻烦。先说一个这次最想看到的结果。'};
  if(id==='U3-journey'&&/^(?:就是|一般|平时|周末|户外|去|在|玩|钓鱼|路亚|娱乐|活动|通勤|喝饮料|用产品|体验|就这些|而已|\s|[，。！])+$/u.test(last.trim()))return {field:'activitySteps',prompt:'我们把这次活动拆开一点：从准备开始，到使用结束，这个人会先做什么、接着做什么？可以描述同类活动或首次尝试的设想，不需要他已经用过未上市的新品。'};
  return null;
}

function contextFrom(session) {
  const b1=segments(session,'B1-brand'),financial=revenueParts(segments(session,'B3-sales'));
  const rawScope=effective(session,'N1-scope'),scope=session.sameScopeOverride || scopeFrom(segments(session,'N1-scope').at(-1) || rawScope,session.projectClue);
  const commercial=[effective(session,'N3-commercial'),effective(session,'N1-scope'),effective(session,'D3-delivery')].filter(Boolean).join('；');
  const companyChannels=answer(session,'B4-channels'),channelScale=companyChannels.match(/(?:[0-9一二三四五六七八九十百千万几多]+\s*(?:[-~～—–至到]\s*[0-9一二三四五六七八九十百千万几多]+)?\s*(?:家|个|间|位|名|省|城|县))[^，。；\n]{0,14}|全国|多省|单店|小范围/g)?.join('、') || (undisclosed(companyChannels)?'不便提供':'');
  const user=effective(session,'U1-user'),experience=/新手|初学|第一次|入门|零基础/.test(user)?'新手或初次接触':/老手|熟练|多年|资深|专业|有经验/.test(user)?'已有经验':'';
  const priceMatches=commercial.match(/(?:人民币|RMB|CNY|USD|美元|欧元|¥|￥|\$)?\s*\d[\d,.]*(?:\s*[-~～—–至到]\s*\d[\d,.]*)?\s*(?:元|万|美元|人民币|USD|CNY|EUR)(?:左右|以内|以上|以下)?/g) ;
  const targetPrice=priceMatches?[...new Set(priceMatches)].join('；'):(/没定|不确定|未知/.test(commercial)?'尚未确定':'');
  const channelMatches=commercial.match(/天猫|淘宝|京东|抖音|小红书|直营网店|自营网店|网店|自营门店|合作门店|线下门店|经销商|渔具店|钓具门店|钓具店|办公空间|亚马逊|Amazon|官网|门店/g);
  const plannedChannels=channelMatches?[...new Set(channelMatches)].join('、'):'';
  const researchReferences=(session.researchReferences || []).filter(reference=>!reference.outdated);
  const company={brand:extractBrand(b1),market:marketText(b1.join('\n')),portfolio:[answer(session,'B2-portfolio'),...(session.companyScopeNotes || [])].filter(Boolean).join('\n补充：'),annualRevenue:has(session.answers,'B3-sales')?financial.annualRevenue:'',revenuePeriod:has(session.answers,'B3-sales')?financial.revenuePeriod:'',channels:companyChannels,channelScale,capabilities:answer(session,'B5-capability')};
  const project={category:scope.category,subcategory:scope.subcategory,name:scope.name || '',stage:effective(session,'N2-stage'),targetPrice,targetMarket:marketText(commercial),plannedChannels,targetUser:user,experienceLevel:experience,desiredOutcome:effective(session,'D1-outcome') || effective(session,'U2-goal')};
  const sources=researchReferences.map(reference=>({id:reference.id,url:reference.sourceUrl,title:reference.sourceTitle,quote:reference.quote,asOf:reference.asOf,providedAt:reference.providedAt,verification:'user-supplied-not-checked',verified:false}));
  const research={status:researchReferences.length?'user-supplied-not-checked':'not-run',performed:false,queries:researchQueries(company,project),sources,competitors:researchReferences.map(reference=>({...reference,benefit:reference.benefits,source:reference.sourceUrl,status:'用户补充，尚未核实',verified:false})),scopeConfirmed:!session.pendingScopeConfirmation};
  return {company,project,research};
}
function researchQueries(company,project) {
  const specific=project.subcategory || project.category;
  if(!specific)return [];
  const brand=/尚未命名|不便提供/.test(company.brand)?'':company.brand;
  const terms={'路亚竿':'lure fishing rod','台钓竿':'telescopic pole fishing rod','海钓竿':'saltwater fishing rod','飞蝇竿':'fly fishing rod','电动牙刷':'electric toothbrush','手动牙刷':'manual toothbrush','儿童牙刷':'kids toothbrush','人参便携饮品':'ginseng beverage'};
  const english=terms[project.subcategory] || ({'钓竿':'fishing rod','牙刷':'toothbrush','帐篷':'camping tent','鞋':'outdoor footwear','饮品':'beverage','水壶':'outdoor water bottle','雨伞':'umbrella'}[project.category] || specific);
  const adjacent=project.category==='钓竿'?'新手 徒步鞋 帐篷 户外水壶 体验 设计':project.category==='牙刷'?'个人护理 手柄 握持 引导 操作 体验':'相邻品类 使用过程 体验 设计';
  return [
    {id:'domestic-brand',market:'domestic',query:[brand,specific,'官方 参数 价格 渠道'].filter(Boolean).join(' '),focus:'品牌与具体产品信息',language:'zh',engines:['Bing','百度','官方站点']},
    {id:'domestic-category',market:'domestic',query:`${specific} 品牌 对比 京东 天猫 销量 排行榜 用户评价`,focus:'同类产品与平台观察；排名和销量须看来源及时间',language:'zh',engines:['Bing','京东','天猫']},
    {id:'international-category',market:'international',query:`${english} beginner review specifications price comparison`,focus:'国际同类产品与设计对比',language:'en',engines:['Bing','Google','official brand sites']},
    {id:'adjacent-design',market:'adjacent',query:`${specific} ${adjacent}`,focus:'横向借鉴，不视为直接竞争或已验证方案',language:'zh',engines:['Bing','百度']},
  ];
}
function syncContext(session) {session.context=contextFrom(session);session.projectContext=session.context;return session.context;}
export function getProjectContext(session) {return contextFrom(session);}
export function buildReport(session) {syncContext(session);return buildDecisionReport(session);}

function ensurePrompt(session) {
  const question=getCurrentQuestion(session);if(!question)return;
  if(!session.chatTurns.some(turn=>turn.questionId===question.id))session.chatTurns.push({questionId:question.id,prompt:getQuestion(question.id).title,askedAt:at()});
  const lastQuestion=[...session.messages].reverse().find(message=>message.kind==='product-question');
  if(!session.pendingClarification && !session.pendingScopeConfirmation && lastQuestion?.questionIds?.[0]!==question.id)append(session,'assistant',`${question.title}\n${question.body || ''}`,{questionIds:[question.id],kind:'product-question'});
}
function initSession(session) {
  session.answers ||= {};session.answerParts ||= {};session.drafts ||= {};session.extraDrafts ||= {};session.messages ||= [];session.chatTurns ||= [];session.questionTelemetry ||= {};session.answerRevisions ||= [];session.feedbackHistory ||= [];session.researchReferences ||= [];session.researchReferenceHistory ||= [];session.scopeHistory ||= [];session.outdatedAnswers ||= {};session.answerHistory ||= [];session.companyScopeNotes ||= [];session.routeLog ||= [];
  for(const question of QUESTIONS)telemetry(session,question.id);
  session.batchOrder=ROUNDS.map(round=>round.id);session.batchIndex=0;
  return session;
}
export function createChatSession({scenarioId='fishing',opening='',custom=false}={}) {
  const id=globalThis.crypto?.randomUUID?.() || `product-${Date.now()}-${Math.random().toString(36).slice(2,10)}`;
  const scenario=SCENARIOS.find(entry=>entry.id===scenarioId);
  const session=initSession({id,version:ENGINE_VERSION,engineKind:'product-v05',interactionVersion:5,chatMode:true,scenarioId:scenario?.id || 'fishing',custom:Boolean(custom),demoEvidenceStatus:custom?'':scenario?.evidenceStatus || '',title:opening?raw(opening).trim().slice(0,35):scenario?.label || '一次新品开发讨论',projectClue:raw(opening),createdAt:at(),updatedAt:at(),complete:false,stopReason:null,feedback:null,report:null,reportRevision:0});
  append(session,'assistant','先了解你的品牌和现有生意，再聚焦这一次要开发的产品。之后一起看市场、使用过程和可以验证的设计方向。',{kind:'product-opening'});
  if(raw(opening).trim())append(session,'user',raw(opening),{kind:'project-clue',questionIds:[]});
  syncContext(session);ensurePrompt(session);return session;
}
export function upgradeToChat(session) {
  if(!session || session.engineKind!=='product-v05')return session;
  initSession(session);session.chatMode=true;session.interactionVersion=5;syncContext(session);ensurePrompt(session);return session;
}
function scopeConfirmationQuestion(session) {
  const base=getQuestion('N1-scope'),pending=session.pendingScopeConfirmation;
  return {...base,baseTitle:base.title,title:'这次是换了一款产品，还是只调整刚才的说法？',body:'如果换了产品，我们会保留公司信息，并重新确认这款产品的阶段、市场、用户与设计。旧回答都会留档。',isFollowUp:true,followUpKind:'scope-confirmation',options:['按新项目重聊','还是同一款，只是改说法','撤回这次修改'],confirmation:pending};
}
export function getCurrentQuestion(session) {
  if(!session || session.engineKind!=='product-v05' || session.complete)return null;
  if(session.pendingScopeConfirmation)return scopeConfirmationQuestion(session);
  if(session.pendingClarification){const base=getQuestion(session.pendingClarification.questionId);return {...base,baseTitle:base.title,title:session.pendingClarification.prompt,body:session.pendingClarification.body || '补充你知道的部分就好；暂时不知道或不方便提供，都可以直接说。',isFollowUp:true,followUpKind:session.pendingClarification.field};}
  return QUESTIONS.find(question=>!has(session.answers,question.id)) || null;
}
export function getChatTurns(session) {
  if(!session || session.engineKind!=='product-v05')return [];
  const active=getCurrentQuestion(session)?.id;
  const turns=session.chatTurns.filter(turn=>has(session.answers,turn.questionId) || turn.questionId===active || session.outdatedAnswers?.[turn.questionId]?.length);
  const seen=new Set(turns.map(turn=>turn.questionId));
  for(const id of IDS)if((has(session.answers,id)||id===active)&&!seen.has(id)){turns.push({questionId:id,prompt:getQuestion(id)?.title,askedAt:session.createdAt});seen.add(id);}
  return turns.map(turn=>{
    const id=turn.questionId,committed=has(session.answers,id),pending=session.pendingClarification?.questionId===id?session.pendingClarification:null,confirmation=id==='N1-scope'?session.pendingScopeConfirmation:null;
    const old=session.outdatedAnswers?.[id]?.at(-1);
    const outdated=Boolean(old && !committed) || Boolean(session.pendingScopeConfirmation && PROJECT_DEPENDENTS.includes(id));
    return {...turn,question:getQuestion(id),answered:committed && !outdated,answer:committed?session.answers[id]:pending?joined(pending.responses):old?.answer,extra:committed?telemetry(session,id).volunteeredExtra:old?.extra || '',pendingAnswer:pending?joined(pending.responses):confirmation?session.answers[id]:undefined,clarification:pending?.prompt || (confirmation?'请确认：按新项目重聊、还是同一款只改说法，或者撤回这次修改。':null),clarificationKind:pending?.field || (confirmation?'scope-confirmation':null),clarificationResponses:pending?.responses || [],outdated,outdatedAt:old?.outdatedAt || null,revisions:session.answerRevisions.filter(revision=>revision.questionId===id).length};
  });
}
export function getReviewQuestions(session) {return getChatTurns(session).filter(turn=>!turn.outdated).map((turn,index)=>{const help=[...session.messages].reverse().find(message=>message.helpLevel===1&&message.questionIds?.includes(turn.questionId));return {questionId:turn.questionId,title:turn.question.title,answer:turn.answer || '',extra:turn.extra || '',answered:turn.answered,helpLevel:session.questionTelemetry[turn.questionId]?.maxHelpLevel || 0,example:help?.text || '',order:index+1};});}
export function setDraft(session,id,value) {if(getQuestion(id)){session.drafts[id]=raw(value);touch(session);}}
export function advanceHelp(session,id) {
  if(getCurrentQuestion(session)?.id!==id)return session.questionTelemetry?.[id]?.maxHelpLevel || 0;
  const record=telemetry(session,id),guidance=getGuidance(session,id);record.stalled=true;record.usedHelp=true;record.maxHelpLevel=Math.min(3,record.maxHelpLevel+1);
  const text=record.maxHelpLevel===1?`${guidance.productName}：${guidance.productIntro}\n${guidance.example}`:record.maxHelpLevel===2?guidance.options.map(option=>`· ${option}`).join('\n'):'暂时不知道可以直接说。我们会把这项列为待补信息，不替你猜。';
  append(session,'assistant',text,{questionIds:[id],helpLevel:record.maxHelpLevel,guidanceCategory:guidance.categoryId,productIntro:guidance.productIntro});touch(session);return record.maxHelpLevel;
}
function invalidateFeedback(session,reason) {if(session.feedback){session.feedbackHistory.push({...session.feedback,invalidatedAt:at(),reason,reportRevision:session.reportRevision});session.feedback=null;session.feedbackNeedsReview=true;}}
function archiveReport(session,reason) {if(session.report){session.reportHistory ||= [];session.reportHistory.push({report:session.report,revision:session.reportRevision,archivedAt:at(),reason});}}
function refreshStatus(session) {
  session.stopReason=null;
  session.complete=!session.pendingClarification&&!session.pendingScopeConfirmation&&IDS.every(id=>has(session.answers,id));
  syncContext(session);
  if(session.complete){session.reportRevision++;session.report=buildReport(session);session.report.revision=session.reportRevision;}else session.report=null;
}
function clarify(session,id,parts,missing) {
  const record=telemetry(session,id);record.stalled=true;record.clarificationCount++;
  session.pendingClarification={questionId:id,prompt:missing.prompt,field:missing.field,responses:parts,originalAnswer:joined(parts),originalExtra:parts.map(part=>part.extra).filter(Boolean).join('\n'),at:at()};
  session.drafts[id]='';append(session,'assistant',missing.prompt,{questionIds:[id],kind:'product-clarification',missingField:missing.field,clarificationNumber:record.clarificationCount});touch(session);
  return {ok:false,complete:false,errors:{},clarification:{questionId:id,prompt:missing.prompt,kind:'missing-detail',field:missing.field}};
}
function rememberCompanyScope(session,text) {if(/我们|公司|旗下|品牌/.test(text)&&/都有|都做|台钓.*路亚|路亚.*台钓|周边/.test(text)&&!session.companyScopeNotes.includes(text))session.companyScopeNotes.push(text);}
function markScopeChanged(session,decision) {
  const pending=session.pendingScopeConfirmation;
  const when=at(),archived=[];
  for(const id of PROJECT_DEPENDENTS)if(has(session.answers,id)){
    const previous={questionId:id,answer:session.answers[id],parts:session.answerParts[id] || [{text:session.answers[id],at:when}],extra:telemetry(session,id).volunteeredExtra,outdatedAt:when,scope:pending.previousScope,reason:'本次讨论产品已更换，原回答仅作旧项目记录。'};
    (session.outdatedAnswers[id] ||= []).push(previous);session.answerHistory.push(previous);archived.push(id);delete session.answers[id];delete session.answerParts[id];delete session.drafts[id];delete session.extraDrafts[id];
    const record=telemetry(session,id);record.volunteeredExtra='';record.skipped=false;record.currentScopeAnswered=false;
  }
  for(const reference of session.researchReferences)if(!reference.outdated){reference.outdated=true;reference.outdatedAt=when;reference.previousScope=pending.previousScope;}
  const snapshot={...pending,decision,confirmedAt:when,archivedQuestionIds:archived};session.scopeHistory.push(snapshot);session.scopeChanges=session.scopeHistory;
  delete session.sameScopeOverride;delete session.pendingScopeConfirmation;delete session.pendingClarification;
  append(session,'assistant','已按新项目继续。公司信息保留；原来的产品阶段、市场资料、用户与设计回答已留作旧项目记录，我们重新确认。',{kind:'scope-confirmed'});
}
function submitScopeConfirmation(session,text) {
  const pending=session.pendingScopeConfirmation;
  append(session,'user',text,{questionIds:['N1-scope'],kind:'scope-confirmation-answer'});
  if(/撤回|取消这次|取消修改|恢复原来|撤销/.test(text)) {
    session.answers['N1-scope']=pending.previousAnswer;session.answerParts['N1-scope']=pending.previousParts;telemetry(session,'N1-scope').volunteeredExtra=pending.previousExtra;
    session.scopeHistory.push({...pending,decision:'reverted',confirmedAt:at()});delete session.pendingScopeConfirmation;append(session,'assistant','已撤回这次范围修改，继续原来的产品。修改过程仍保留在记录里。',{kind:'scope-reverted'});
  } else if(/同一款|同一个|只是改|只是润色|不换|没换|原项目|原来的项目|只改说法/.test(text)) {
    session.sameScopeOverride=pending.previousScope;session.scopeHistory.push({...pending,decision:'same-project',confirmedAt:at()});delete session.pendingScopeConfirmation;append(session,'assistant','已确认仍是同一款产品，保留前面的项目回答。',{kind:'scope-kept'});
  } else if(/新项目|换项目|换产品|按新的|按新方向|确认更换|确实换|重新聊|重聊|新的产品/.test(text) || /^(?:是的|确认|确定|好|可以|是)[。！]?\s*$/.test(text))markScopeChanged(session,'new-project');
  else {session.pendingScopeConfirmation.responses ||= [];session.pendingScopeConfirmation.responses.push({text,at:at()});const prompt='我先不替你判断。请确认：是“按新项目重聊”，还是“同一款产品，只改说法”？也可以撤回这次修改。';append(session,'assistant',prompt,{questionIds:['N1-scope'],kind:'scope-confirmation'});session.drafts['N1-scope']='';touch(session);return {ok:false,complete:false,errors:{},clarification:{questionId:'N1-scope',prompt,kind:'scope-confirmation'},requiresScopeConfirmation:true};}
  delete session.drafts['N1-scope'];refreshStatus(session);if(!session.complete)ensurePrompt(session);touch(session);return {ok:true,complete:session.complete,scopeConfirmed:true,reopened:!session.complete};
}
export function submitChatAnswer(session,id,value,{extra=''}={}) {
  upgradeToChat(session);const question=getCurrentQuestion(session),text=raw(value),extraText=raw(extra);
  if(!question||question.id!==id)return {ok:false,complete:Boolean(session.complete),errors:{[id || 'session']:question?'请先回答当前这个问题。':'这次讨论已整理，你仍可以在原问题处修改。'}};
  setDraft(session,id,text);
  if(!text.trim()&&telemetry(session,id).maxHelpLevel<3)return {ok:false,complete:false,errors:{[id]:'可以先看例子；暂时不知道，也可以直接说。'}};
  if(session.pendingScopeConfirmation)return submitScopeConfirmation(session,text || '暂时不知道');
  const pending=session.pendingClarification?.questionId===id?session.pendingClarification:null;
  const parts=[...(pending?.responses || []),{text:text || '暂时不知道',extra:extraText,at:at()}];
  append(session,'user',text || '（暂时留白）',{questionIds:[id],kind:pending?'product-clarification-answer':'product-answer',answerText:text,extra:extraText});
  if(id==='N1-scope')rememberCompanyScope(session,text);
  const missing=missingFor(session,id,parts);
  if(missing)return clarify(session,id,parts,missing);
  session.answers[id]=joined(parts);session.answerParts[id]=parts;
  const record=telemetry(session,id);record.volunteeredExtra=parts.map(part=>part.extra).filter(Boolean).join('\n');record.skipped=!text.trim()||unknown(text);record.signal='none';record.currentScopeAnswered=true;record.missingFields=unknown(text)?[pending?.field || getQuestion(id).field]:[];
  delete session.pendingClarification;delete session.drafts[id];delete session.extraDrafts[id];
  const turn=session.chatTurns.find(entry=>entry.questionId===id);if(turn)turn.answeredAt=at();
  refreshStatus(session);
  if(session.complete)append(session,'assistant','公司、本次产品、市场线索、使用者与设计条件都整理好了。下面给出当前的产品方向、可借鉴的设计假设，以及还要验证的地方。',{kind:'report-ready'});else ensurePrompt(session);
  touch(session);return {ok:true,complete:session.complete,signals:[],stopReason:null};
}
export function reviseChatAnswer(session,id,value,{extra,mode='replace'}={}) {
  upgradeToChat(session);
  if(!has(session.answers,id)||!getQuestion(id))return {ok:false,complete:Boolean(session.complete),errors:{[id]:'这条还没有当前项目的完整回答，请在聊天里继续。'}};
  if(!['replace','append'].includes(mode)||!raw(value).trim())return {ok:false,complete:Boolean(session.complete),errors:{[id]:'请写下要修改或补充的内容。'}};
  const text=raw(value),previousAnswer=session.answers[id],previousParts=session.answerParts[id] || [{text:previousAnswer,at:session.createdAt}],previousExtra=telemetry(session,id).volunteeredExtra;
  const beforeComplete=session.complete,previousScope=getProjectContext(session).project;
  const parts=mode==='append'?[...previousParts,{text,extra:extra===undefined?'':raw(extra),at:at()}]:[{text,extra:extra===undefined?previousExtra:raw(extra),at:at()}];
  const next=joined(parts),nextExtra=extra===undefined?previousExtra:mode==='append'?[previousExtra,raw(extra)].filter(Boolean).join('\n'):raw(extra);
  if(next===previousAnswer&&nextExtra===previousExtra)return {ok:true,complete:session.complete,changed:false};
  archiveReport(session,'回答已修改。');invalidateFeedback(session,'回答已修改，请结合更新后的产品讨论复核反馈。');
  session.answerRevisions.push({questionId:id,beforeAnswer:previousAnswer,afterAnswer:next,submittedText:text,beforeExtra:previousExtra,afterExtra:nextExtra,mode,at:at(),reportRevision:session.reportRevision});
  append(session,'user',`${mode==='append'?'补充':'修改'}「${getQuestion(id).title}」\n${text}`,{questionIds:[id],kind:'answer-revision',answerText:text,extra:extra===undefined?'':raw(extra),revisionMode:mode});
  session.answers[id]=next;session.answerParts[id]=parts;telemetry(session,id).volunteeredExtra=nextExtra;
  if(id==='N1-scope') {
    rememberCompanyScope(session,text);delete session.sameScopeOverride;
    session.pendingScopeConfirmation={questionId:id,previousAnswer,previousParts,previousExtra,previousScope,proposedAnswer:next,proposedScope:scopeFrom(next,session.projectClue),at:at(),responses:[]};
    session.complete=false;session.report=null;delete session.pendingClarification;syncContext(session);
    append(session,'assistant','这次是换了一款产品，还是只改刚才的说法？请回复“按新项目重聊”“还是同一款，只是改说法”，或“撤回这次修改”。旧项目资料都会保留。',{questionIds:[id],kind:'scope-confirmation'});
    touch(session);return {ok:true,complete:false,reopened:beforeComplete,requiresScopeConfirmation:true,scopeChanged:true};
  }
  const missing=missingFor(session,id,parts);
  if(missing){delete session.answers[id];session.pendingClarification={questionId:id,prompt:missing.prompt,field:missing.field,responses:parts,originalAnswer:next,at:at()};append(session,'assistant',missing.prompt,{questionIds:[id],kind:'product-clarification',missingField:missing.field});session.complete=false;session.report=null;syncContext(session);touch(session);return {ok:true,complete:false,reopened:beforeComplete,clarification:{questionId:id,prompt:missing.prompt}};}
  refreshStatus(session);if(!session.complete)ensurePrompt(session);touch(session);return {ok:true,complete:session.complete,reopened:beforeComplete&&!session.complete};
}
export function getProgress(session) {const answered=IDS.filter(id=>has(session.answers,id)&&!(session.pendingScopeConfirmation&&PROJECT_DEPENDENTS.includes(id))).length;return {answered,total:IDS.length,percent:Math.round(answered/IDS.length*100),completedBatches:ROUNDS.filter(round=>round.questionIds.every(id=>has(session.answers,id))).length,totalBatches:ROUNDS.length};}

function researchChange(session,reason) {archiveReport(session,reason);invalidateFeedback(session,reason);syncContext(session);if(session.complete){session.reportRevision++;session.report=buildReport(session);session.report.revision=session.reportRevision;}touch(session);}
export function addResearchReference(session,reference={}) {
  if(session.engineKind!=='product-v05')return {ok:false,errors:{session:'请在当前新品开发项目中添加资料。'}};
  let url;try{url=new URL(raw(reference.sourceUrl));}catch{return {ok:false,errors:{sourceUrl:'请填写能回看的资料网址。'}};}
  if(!['http:','https:'].includes(url.protocol))return {ok:false,errors:{sourceUrl:'资料网址需以 http 或 https 开头。'}};
  if(!raw(reference.brand).trim()&&!raw(reference.product).trim()&&!raw(reference.model).trim())return {ok:false,errors:{product:'请至少写下品牌、型号或产品名称中的一项。'}};
  const id=globalThis.crypto?.randomUUID?.() || `reference-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
  const record={id};for(const key of ['brand','model','product','price','benefits','place','promotion','sales','ranking','sourceUrl','sourceTitle','quote','asOf','directness'])record[key]=raw(reference[key]);
  record.sourceUrl=url.href;record.providedAt=at();record.sourceVerification='user-supplied-not-checked';record.verified=false;record.outdated=false;record.scope={...getProjectContext(session).project};
  session.researchReferences.push(record);session.researchReferenceHistory.push({action:'added',reference:{...record},at:at()});
  append(session,'user',`补充市场资料：${[record.brand,record.model,record.product].filter(Boolean).join(' ')}\n来源：${record.sourceUrl}${record.quote?`\n原文摘录：${record.quote}`:''}`,{kind:'research-reference-added',referenceId:id});
  researchChange(session,'市场资料已更新，需要结合新资料复核当前产品方向。');return {ok:true,id,reference:record};
}
export function removeResearchReference(session,id) {
  const index=session.researchReferences?.findIndex(reference=>reference.id===id) ?? -1;if(index<0)return {ok:false,errors:{reference:'没有找到这条资料。'}};
  const [reference]=session.researchReferences.splice(index,1);session.researchReferenceHistory.push({action:'removed',reference,at:at()});append(session,'user',`移除本次使用的市场资料：${[reference.brand,reference.model,reference.product].filter(Boolean).join(' ')}`,{kind:'research-reference-removed',referenceId:id});researchChange(session,'市场资料已移除，需要复核当前产品方向。');return {ok:true};
}
export function validateFeedback(feedback={},session=null) {
  const errors={};for(const [key,label]of Object.entries(FEEDBACK_LABELS)){const selected=key==='valuableQuestion'?feedback.valuableQuestionIds:key==='uselessQuestion'?feedback.uselessQuestionIds:null;if(!raw(feedback[key]).trim()&&!(Array.isArray(selected)&&selected.length))errors[key]=`请说说：${label}没有也可以写“暂时没有”。`;}
  if(!['产品负责人','工厂方','渠道方','营销人','其他'].includes(feedback.role))errors.role='请选择你的角色。';if(typeof feedback.awareOfTest!=='boolean')errors.awareOfTest='请选择是否事先知道这是测试系统。';
  const shown=session?new Set(getReviewQuestions(session).map(question=>question.questionId)):null;
  for(const key of FEEDBACK_SELECTIONS)if(has(feedback,key)&&(!Array.isArray(feedback[key])||feedback[key].some(id=>!getQuestion(id)||(shown&&!shown.has(id)))))errors[key]='请从本次展示过的问题里选择。';
  return {ok:!Object.keys(errors).length,errors};
}
export function saveFeedback(session,feedback) {
  if(!session.complete)return {ok:false,errors:{session:'这次产品讨论整理完成后，再保存整轮反馈。'}};
  const result=validateFeedback(feedback,session);if(!result.ok)return result;
  if(session.feedback)session.feedbackHistory.push({...session.feedback,replacedAt:at(),reason:'用户更新反馈。'});
  session.feedback=Object.fromEntries([...Object.keys(FEEDBACK_LABELS),'role','awareOfTest'].map(key=>[key,feedback[key]]));
  for(const key of FEEDBACK_SELECTIONS)if(Array.isArray(feedback[key]))session.feedback[key]=[...new Set(feedback[key])];
  session.feedback.submittedAt=at();session.feedback.reportRevision=session.reportRevision;session.feedbackNeedsReview=false;touch(session);return result;
}
export function exportSessionJSON(session) {
  const context=getProjectContext(session);
  return JSON.parse(JSON.stringify({...session,context,projectContext:context,rawTranscript:session.messages,questionReview:getReviewQuestions(session),diagnosis:session.report,perQuestion:QUESTIONS.map(question=>({questionId:question.id,question:question.title,answer:session.answers[question.id] ?? null,draft:session.drafts[question.id] ?? null,outdated:session.outdatedAnswers[question.id] || [],...session.questionTelemetry[question.id]})),export:{version:ENGINE_VERSION,exportedAt:at(),status:session.complete?'产品方向已整理':'产品讨论草稿',feedbackComplete:Boolean(session.feedback),externalSearchPerformed:false,researchVerification:'用户提供的来源未由系统读取或核实'}}));
}
function mdText(value){if(value==null)return '';if(Array.isArray(value))return value.map(mdText).join('；');if(typeof value==='object')return mdText(value.text || value.label || value.value || value.title || value.name || '');return String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function fenced(value){const text=raw(value),runs=text.match(/`+/g)||[],fence='`'.repeat(Math.max(3,...runs.map(run=>run.length+1)));return `${fence}text\n${text}\n${fence}`;}
function mdSource(source){if(!source)return '';let url='';try{const parsed=new URL(raw(source.url));if(['http:','https:'].includes(parsed.protocol))url=parsed.href;}catch{}return [mdText(source.title || source.label || '用户提供的来源'),url,source.quote?`摘录：${mdText(source.quote)}`:''].filter(Boolean).join(' · ');}
export function exportSessionMarkdown(session) {
  const context=getProjectContext(session),report=session.report,lines=[`# ${mdText(context.company.brand || '新品有数')} · ${mdText(context.project.name || context.project.subcategory || '本次新品')}开发建议`,'',`日期：${new Date().toISOString().slice(0,10)} · ${session.complete?'本轮已整理':'讨论仍在进行'}`,''];
  if(session.demoEvidenceStatus)lines.push('**演示说明：本报告使用虚构品牌和经营数字，展示报告结构；设计方向尚未经过真实用户或市场验证。**','');
  if(report){
    lines.push('## 本轮建议','',mdText(report.summary.recommendation),'',mdText(report.summary.rationale),'',`说明：${mdText(report.summary.assumption)}`,'','## 企业与本次新品','');
    for(const item of [...(report.companyFacts || []),...(report.projectFacts || [])])lines.push(`- **${mdText(item.label)}**：${mdText(item.value)}`);
    if(report.context.companyStage)lines.push('',mdText(report.context.companyStage.label),mdText(report.context.companyStage.basis),mdText(report.context.companyStage.caveat));
    lines.push('','## 竞品与市场研究','',mdText(report.sections.find(section=>section.id==='competition')?.lead),'');
    for(const c of report.competitorComparison || [])lines.push(`### ${mdText(c.brand)} · ${mdText(c.model)}`,'',`- 产品与实际利益：${mdText(c.product)}；${mdText(c.benefit)}`,`- 价格与币种：${mdText(c.price)}`,`- 销售渠道：${mdText(c.place)}`,`- 对外主张：${mdText(c.promotion)}`,`- 对位关系：${mdText(c.directness)}`,`- 销量：${mdText(c.sales)}`,`- 排名：${mdText(c.ranking)}`,`- 资料状态：${mdText(c.status)}`,`- 来源：${mdSource(c.source)}`,'');
    for(const task of report.researchPlan?.tasks || [])lines.push(`### ${mdText(task.name)}`,'',mdText(task.question),`需要取得：${mdText(task.requiredFields)}`,`查看哪里：${mdText(task.whereToLook)}`,'');
    for(const query of report.researchPlan?.queries || [])lines.push(`- ${mdText(query.focus || '待执行查询')}：${mdText(query.query)}`);
    lines.push('','## 使用者的目标和活动过程','',`使用者：${mdText(report.userJourney.targetUser)}`,`经验阶段：${mdText(report.userJourney.experienceLevel)}`,`想获得的结果或体验：${mdText(report.userJourney.desiredExperience)}`,`活动场景：${mdText(report.userJourney.scene)}`,'');
    for(const step of report.userJourney.steps || [])lines.push(`- **${mdText(step.stage)}**：${mdText(step.action)}。${mdText(step.opportunity)}`);
    lines.push('',mdText(report.userJourney.learningPrinciple),'','## 建议打样的产品方向','');
    for(const [index,d]of report.designDirections.entries()){
      lines.push(`### ${index+1}. ${mdText(d.name)}`,'',`**给使用者的实际好处**：${mdText(d.benefit)}`,'',`- 场景：${mdText(d.scenario)}`,`- 目标：${mdText(d.goal)}`,`- 具体动作：${mdText(d.userAction)}`,`- 当前的机会或阻力：${mdText(d.currentBarrierOrOpportunity)}`,`- 建议的设计机制：${mdText(d.proposedMechanism)}`,`- 功能怎样体现：${mdText(d.function)}`,`- 企业条件怎样用上：${mdText(d.companyFit)}`,'');
      for(const basis of d.evidenceBasis || [])lines.push(`> ${mdText(basis.label)}：${mdText(basis.quote)}`,'');
      lines.push('**样品怎样试**',mdText(d.validation.action),`观察：${mdText(d.validation.measure)}`,`怎样判断：${mdText(d.validation.successCondition)}`,`当前状态：${mdText(d.status)}`,'');
    }
    lines.push('## 下一步与研发决策','');
    for(const test of report.validationPlan || [])lines.push(`### ${mdText(test.title)}`,'',mdText(test.action),`观察什么：${mdText(test.measure)}`,`怎样判断：${mdText(test.successCondition)}`,`据此做哪个决定：${mdText(test.decision)}`,`需要准备：${mdText(test.requiredInputs)}`,'');
    lines.push('## 来源与资料范围','');for(const note of report.sourceNotes || [])lines.push(`- **${mdText(note.label)}**：${mdText(note.text)}${note.url?`（${mdText(note.url)}）`:''}`);
  }else lines.push('本轮还没有生成完整开发建议。下面保留已经聊到的信息，未提供的数据不会自动补齐。','');
  lines.push('','## 本次反馈','');
  if(session.feedback){for(const [key,label]of Object.entries(FEEDBACK_LABELS))lines.push(`### ${label}`,'',raw(session.feedback[key]),'');lines.push(`角色：${raw(session.feedback.role)}`,`是否事先知道是测试系统：${session.feedback.awareOfTest?'知道':'不知道'}`,'');}else lines.push('本次尚未填写体验反馈。','');
  lines.push('## 附录：完整对话原文','');for(const message of session.messages)lines.push(`### ${message.role==='user'?'你':'新品有数'}`,'',fenced(message.text),...(message.extra?['',fenced(message.extra)]:[]),'');
  if(session.answerRevisions.length){lines.push('## 附录：回答修改与补充','');for(const revision of session.answerRevisions)lines.push(`### ${getQuestion(revision.questionId)?.title || '回答修改'}`,'',`操作：${revision.mode==='append'?'补充':'修改'}`,'','修改前：',fenced(revision.beforeAnswer),'','本次输入：',fenced(revision.submittedText),'','更新后：',fenced(revision.afterAnswer),'');}
  if(session.feedbackHistory.length){lines.push('## 附录：先前版本的反馈','');for(const previous of session.feedbackHistory){lines.push(`说明：${mdText(previous.reason || '对应先前版本的报告')}`,'');for(const [key,label]of Object.entries(FEEDBACK_LABELS))lines.push(`${label}`,fenced(previous[key]),'');}}
  if(Object.keys(session.outdatedAnswers).length){lines.push('## 附录：先前项目的回答（未用于本次结论）','');for(const [id,entries]of Object.entries(session.outdatedAnswers))for(const entry of entries)lines.push(`### ${getQuestion(id)?.title || '旧项目回答'}`,'',fenced(entry.answer),'');}
  for(const [id,draft]of Object.entries(session.drafts))if(raw(draft).trim())lines.push(`## 未提交草稿：${getQuestion(id)?.title || '聊天草稿'}`,'',fenced(draft),'');
  return lines.join('\n');
}
