// No product facts were retrieved. This is not a completed market scan.
// Keep this empty until an official product page or another attributable
// source has actually been read and its relevant claims recorded.
export const MARKET_REFERENCES = [];

export const MARKET_REFERENCE_STATUS = {
  status: 'not-retrieved',
  checkedAt: '2026-10-22T06:02:12+00:00',
  verifiedProductCount: 0,
  reason: '官方网页未能取得正文，尚未形成可引用的竞品资料。',
  scope: 'product-reference-only',
  salesDataAvailable: false,
  rankingDataAvailable: false,
};
