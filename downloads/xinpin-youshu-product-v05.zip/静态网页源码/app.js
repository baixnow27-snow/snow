import { ENGINE_VERSION, SCENARIOS, QUESTIONS, getQuestion, getSampleAnswers } from './product-data.js';
import { createChatSession, upgradeToChat, getCurrentQuestion, getChatTurns, submitChatAnswer, reviseChatAnswer, getReviewQuestions, setDraft, advanceHelp, getProgress, getProjectContext, addResearchReference, removeResearchReference, buildReport, saveFeedback, exportSessionJSON, exportSessionMarkdown } from './product-engine.js';
import { inferCategory, getGuidance, getCategoryChoices } from './product-data.js';
import { mountHomeVideo } from './hero-video.js';

const $=selector=>document.querySelector(selector);
const escape=value=>String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=name=>`<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const STORAGE_KEY='xinpin-youshu-projects-v5';
const ROUND_LABELS={B:'先了解你的企业',N:'明确本次新品',M:'梳理市场与竞品',U:'理解使用者的目标和过程',D:'形成设计方向与样品计划'};
let sessions=[],current=null,legacy=[],archived=[],autoPlaying=false,operation=0,toastTimer;
let errors={},editError='';
try {
  const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}');
  if(saved.version===5 && Array.isArray(saved.sessions)){
    sessions=saved.sessions.filter(s=>s && s.version===ENGINE_VERSION && typeof s.id==='string' && s.answers && !Array.isArray(s.answers) && Array.isArray(s.messages));
    sessions.forEach(upgradeToChat);current=sessions.find(s=>s.id===saved.activeId)||null;
  }
  const previous=JSON.parse(localStorage.getItem('xinpin-youshu-sessions-v3')||'{}');
  if(Array.isArray(previous.sessions))archived=previous.sessions;
  const old=JSON.parse(localStorage.getItem('xinpin-youshu-projects-v1')||'{}');
  if(Array.isArray(old.projects))legacy=old.projects.filter(p=>p && Array.isArray(p.answers));
}catch { /* A new conversation remains usable when storage is unavailable. */ }
const homeVideo=mountHomeVideo({root:$('#landing'),video:$('#home-video'),toggle:$('#motion-toggle'),fileInput:$('#video-file'),notify:toast});
for(const id of ['question-assist','example-callout','answer-options','branch-actions','typing'])$(`#${id}`).hidden=true;
$('#chat-form .composer-bottom').innerHTML=`<div class="composer-tools"><button type="button" class="chat-help" data-action="help-next">${icon('light')}不知道怎么答</button><button type="button" class="chat-category" data-action="category">换一个例子</button></div><div class="send-area"><button type="button" class="chat-skip" data-action="skip-answer" hidden>这题先留白</button><button class="send-button" type="submit" aria-label="发送回答" disabled>${icon('arrow')}</button></div>`;
$('#chat-composer-wrap .chat-footer').innerHTML='<span><span class="auto-save-dot"></span>聊天与草稿自动保存</span><button class="sample-answer" data-action="sample-answer">填入当前案例示例</button><button class="quick-demo" data-action="auto-demo">完整案例演示</button>';
$('.note-description').textContent='你的原话，会一直留在这里。';

function toast(message){clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').hidden=false;toastTimer=setTimeout(()=>{$('#toast').hidden=true;},3800);}
function persist(){if(current)current.updatedAt=new Date().toISOString();try{localStorage.setItem(STORAGE_KEY,JSON.stringify({version:5,activeId:current?.id||null,sessions}));}catch{toast('浏览器暂时无法保存，可以在“思考记录”里导出当前聊天。');}renderRecent();}
function renderRecent(){
  $('#project-count').textContent=sessions.length+legacy.length+archived.length;
  $('#recent-projects').innerHTML=sessions.slice().sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt)).slice(0,4).map(s=>`<button class="recent-project ${current?.id===s.id?'selected':''}" data-action="resume" data-id="${escape(s.id)}"><span>${escape(s.title)}</span></button>`).join('')||'<p class="recent-empty">从一个想法开始，<br>我们慢慢聊清楚。</p>';
}
function resizeInput(input){input.style.height='auto';input.style.height=Math.min(input.scrollHeight,input.id==='chat-input'?180:150)+'px';input.closest('form').querySelector('.send-button').disabled=!input.value.trim() || (input.id==='chat-input' && autoPlaying);}
function scrollLatest(instant=false){requestAnimationFrame(()=>window.scrollTo({top:document.documentElement.scrollHeight,behavior:instant||matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'}));}
function keepTurnPosition(qid,action){const node=document.querySelector(`[data-turn-id="${qid}"]`),before=node?.getBoundingClientRect().top;action();requestAnimationFrame(()=>{const next=document.querySelector(`[data-turn-id="${qid}"]`);if(before!==undefined && next)window.scrollBy(0,next.getBoundingClientRect().top-before);});}
function pauseDemo(){if(autoPlaying){autoPlaying=false;operation++;}}
function renderEditor(turn){
  const d=current.editDraft,q=turn.question || getQuestion(turn.questionId);
  return `<form id="edit-answer-form" class="inline-answer-editor" data-qid="${q.id}" novalidate><label for="edited-answer">${d.mode==='append'?'给这条回答补充一点':'修改这条回答'}</label><textarea id="edited-answer" name="editedAnswer" data-edit-draft rows="4" maxlength="12000" placeholder="${d.mode==='append'?'把刚想到的内容补在这里……':'用你现在更准确的说法……'}">${escape(d.text)}</textarea><p class="edit-reason">${current.complete?'保存后，问题报告会按最新回答更新。':'保存后会继续保留前面的对话。'}</p>${editError?`<p class="batch-error" role="alert">${escape(editError)}</p>`:''}<div class="editor-actions"><button type="button" class="secondary-action" data-action="cancel-edit">取消</button><button type="submit" class="primary-action">保存${d.mode==='append'?'补充':'修改'}</button></div></form>`;
}
function renderGuidance(q){
  const level=current.questionTelemetry[q.id]?.maxHelpLevel || 0, guidance=getGuidance(current,q.id),rephrase=current.rephrasedQuestionIds?.includes(q.id);
  if(!level && !rephrase)return '';
  return `<div class="chat-guidance">${rephrase?`<p class="guidance-intro"><strong>换个说法</strong><br>${escape(guidance.simpleExplanation)}</p>`:''}${level>=1?`<div class="guidance-example"><span>${escape(guidance.categoryLabel)} · ${escape(guidance.productName)}</span><p class="guidance-intro">${escape(guidance.productIntro)}</p><p>${escape(guidance.example)}</p><button type="button" class="text-button" data-action="category">换一个我熟悉的例子</button></div>`:''}${level>=2?`<div class="guidance-options" aria-label="可以从这些方向说起">${guidance.options.map(o=>`<button type="button" data-action="pick-option" data-value="${escape(o)}">${escape(o)}</button>`).join('')}</div>`:''}${level>=3?'<p class="turn-status">这题可以先留白，之后仍能回来补充。</p>':''}</div>`;
}
function historicalGuidance(qid){
  const messages=current.messages.filter(m=>m.role==='assistant' && m.questionIds?.includes(qid) && (m.helpLevel || m.kind==='question-rephrase'));
  return messages.length?`<details class="past-guidance"><summary>回看当时的解释和例子</summary>${messages.map(m=>`<p>${escape(m.text)}</p>`).join('')}</details>`:'';
}
function renderChatTurn(turn){
  const q=turn.question || getQuestion(turn.questionId);if(!q)return '';
  const answered=turn.answered ?? Object.hasOwn(current.answers,q.id),active=getCurrentQuestion(current)?.id===q.id;
  const answer=turn.outdated?turn.answer:answered?current.answers[q.id] ?? turn.answer:turn.pendingAnswer;
  const extra=turn.extra || current.questionTelemetry[q.id]?.volunteeredExtra || '';
  const edited=(current.answerRevisions || []).some(r=>(r.questionId || r.qid)===q.id);
  const hasAnswer=answered || Boolean(answer);
  return `<article class="chat-turn ${active?'is-current':''}" data-turn-id="${q.id}"><div class="message assistant-message"><span class="assistant-avatar">${icon('helix')}</span><div class="message-content"><div class="message-author">新品有数<small>YOUR THINKING PARTNER</small></div><span class="turn-kicker">${escape(ROUND_LABELS[q.round])}${['M','U','D'].includes(q.round) && getProjectContext(current).project.subcategory?` · 本次讨论：${escape(getProjectContext(current).project.subcategory)}`:''}</span><h2 class="turn-question">${escape(q.title)}</h2><p class="turn-description">${escape(q.body)}</p>${active?`<button type="button" class="text-button turn-rephrase" data-action="rephrase">这句话怎么理解？</button>${renderGuidance(q)}`:historicalGuidance(q.id)}</div></div>${hasAnswer?`<div class="message user-message">${turn.potentialOutdated || turn.outdated?'<p class="turn-status">属于修改前的新品，等待确认是否沿用。</p>':''}<p class="answer-text">${escape(answer || '这题先留白，之后再补充。')}</p>${extra?`<p class="answer-extra">补充原话：${escape(extra)}</p>`:''}${answered?`<div class="answer-actions">${edited?'<span class="edited-mark">已更新</span>':''}<button data-action="edit-answer" data-qid="${q.id}" aria-label="修改回答：${escape(q.title)}">修改</button><button data-action="append-answer" data-qid="${q.id}" aria-label="补充回答：${escape(q.title)}">补充</button></div>`:''}</div>`:''}${current.editDraft?.questionId===q.id?renderEditor(turn):''}${active && turn.clarification?`<div class="message assistant-message turn-follow-up"><span class="assistant-avatar">${icon('helix')}</span><div class="message-content"><p>${escape(turn.clarification)}</p><span class="turn-status">接着补充就好，刚才的话会保留。</span></div></div>`:''}${active?'<div class="chat-current-anchor" id="chat-current-anchor"></div>':''}</article>`;
}
function renderComposer(){
  const q=getCurrentQuestion(current);$('#chat-composer-wrap').hidden=!q || current.complete;
  if(!q)return;
  const input=$('#chat-input'),level=current.questionTelemetry[q.id]?.maxHelpLevel || 0;
  input.disabled=autoPlaying;input.value=current.drafts[q.id] || '';
  input.placeholder=current.pendingClarification?'接着刚才的话补充……':'想到什么就说什么……';
  $('.chat-help').innerHTML=icon('light')+(level===0?'不知道怎么答？看个例子':level===1?'还没思路？看看选项':level===2?'还是不确定？可以先留白':'再看看刚才的例子');
  $('.chat-skip').hidden=level<3;
  $('.chat-category').textContent=inferCategory(current).label+' · 换例子';
  $('#chat-composer-wrap .sample-answer').textContent=current.custom?'看一个回答示例':'填入当前案例示例';
  $('#chat-composer-wrap .quick-demo').textContent=autoPlaying?'暂停演示':current.custom?'体验示例项目':'完整案例演示';
  $('#chat-form').setAttribute('aria-label','和新品有数继续对话');resizeInput(input);
}
function plain(value){if(value==null)return '';if(typeof value==='string'||typeof value==='number')return String(value);if(Array.isArray(value))return value.map(plain).filter(Boolean).join('；');return plain(value.text ?? value.value ?? value.label ?? value.name ?? value.title ?? value.description ?? '');}
function urlOf(value){try{const url=new URL(typeof value==='string'?value:value?.url);return ['http:','https:'].includes(url.protocol)?url.href:'';}catch{return '';}}
function sourceLink(source){if(!source)return '';if(Array.isArray(source))return source.map(sourceLink).join(' ');const href=urlOf(source),label=typeof source==='string'?source:source.title || source.label || source.publisher || '来源资料';return href?`<a class="source-chip" href="${escape(href)}" target="_blank" rel="noopener noreferrer">${escape(label)}</a>`:`<span class="data-origin">${escape(label)}</span>`;}
function contextFields(items){return `<dl class="decision-context-grid">${items.map(([label,value])=>`<div class="context-item"><dt>${escape(label)}</dt><dd>${escape(plain(value)||'本次尚未提供')}</dd></div>`).join('')}</dl>`;}
function renderNote(){
  const p=getProgress(current),c=getProjectContext(current),company=c.company||{},project=c.project||{};
  $('#progress-value').textContent=`${p.answered} / ${p.total}`;$('#progress-label').textContent=current.complete?'开发建议已整理':'已经聊到的信息';$('#progress-bar').style.width=p.percent+'%';
  $('#captured-notes').innerHTML=`<div class="context-summary">${[['品牌',company.brand],['企业经营范围',company.portfolio],['本次新品',project.name || project.subcategory],['年销售额',company.annualRevenue],['渠道规模',company.channelScale || company.channels],['研发与制造条件',company.capabilities]].filter(([,value])=>plain(value)).map(([label,value])=>`<div class="captured-note"><span>${label}</span><p>${escape(plain(value))}</p></div>`).join('')}</div>` || '<p class="note-placeholder">先说明品牌、品类和经营情况，<br>再一起聚焦这次新品。</p>';
  $('.note-description').textContent='企业背景与本次新品分开记录。';$('.note-foot p').innerHTML='需求来自人的目标和过程。<br>功能方案由产品团队设计、验证。';
}
function reportPrice(price){if(!price)return '尚未取得';if(typeof price==='object')return [price.amount,price.currency,price.region].filter(Boolean).join(' ')||plain(price);return String(price);}
function directionCard(d,index){
  const validation=d.validation||{},allEvidence=Array.isArray(d.evidenceBasis)?d.evidenceBasis:d.evidenceBasis?[d.evidenceBasis]:[],evidence=allEvidence.filter(e=>['U3-journey','U4-learning','D1-outcome','D3-delivery'].includes(e.questionId)).slice(0,2);
  return `<article class="design-direction"><div class="direction-heading"><span class="priority-tag">${escape(d.priority || `方向 ${index+1}`)}</span><h4>${escape(d.name || d.title)}</h4></div><p class="benefit-line">${escape(d.benefit || d.goal)}</p><dl class="direction-grid">${[['给谁 / 什么场景',d.scenario],['想让他做到什么',d.goal],['用户在做哪一步',d.userAction],['目前的机会或阻力',d.currentBarrierOrOpportunity],['建议怎么设计',d.proposedMechanism || d.function],['需要怎样的功能',d.function],['企业条件怎样用上',d.companyFit]].filter(([,v])=>plain(v)).map(([label,value])=>`<div class="direction-field"><dt>${label}</dt><dd>${escape(plain(value))}</dd></div>`).join('')}</dl>${evidence.length?`<div class="evidence-note">${evidence.map(e=>`<p><strong>${escape(e.label || '依据')}</strong> ${escape(String(typeof e==='string'?e:e.quote || e.text || '').slice(0,180))}${String(e.quote || e.text || '').length>180?'…':''}${e.status?` · ${escape(e.status)}`:''}</p>`).join('')}</div>`:''}<div class="experiment-box"><strong>样品怎样试</strong><p>${escape(validation.action || validation.test || '把设计做成可体验的样品，观察目标使用者如何完成任务。')}</p>${validation.measure?`<p>观察：${escape(plain(validation.measure))}</p>`:''}${validation.successCondition?`<p>判断标准：${escape(plain(validation.successCondition))}</p>`:''}</div><p class="unknown-note">${escape(d.status || '这是本轮建议验证的设计方向，具体参数通过样品试验确定。')}</p></article>`;
}
function queryRows(report){
  const plan=report.researchPlan,context=getProjectContext(current),rows=[];
  const add=(list,label)=>{for(const item of Array.isArray(list)?list:[]){const query=typeof item==='string'?item:item.query || item.text || item.keyword;if(query)rows.push({query,label:typeof item==='object'?(item.scope || item.label || ({domestic:'国内品牌与竞品',international:'国际同类产品',adjacent:'横向设计借鉴'}[item.market]) || label):label});}};
  if(Array.isArray(plan))add(plan,'研究查询');else if(plan){add(plan.queries,'研究查询');add(plan.domestic,'国内竞品');add(plan.international,'国际同行');add(plan.crossCategory || plan.horizontal,'横向借鉴');}
  if(!rows.length)add(context.research?.queries,'研究查询');
  return rows.map(r=>`<a class="research-query" href="https://www.bing.com/search?q=${encodeURIComponent(r.query)}" target="_blank" rel="noopener noreferrer"><span>${escape(r.label || '查询')}</span>${escape(r.query)} ↗</a>`).join('');
}
function renderDiagnosis(){
  const report=current.report || buildReport(current),context=report.context || getProjectContext(current),company=context.company||{},project=context.project||{},summary=report.summary||{},journey=report.userJourney||{},competitors=report.competitorComparison||[],competition=report.sections?.find(s=>s.id==='competition')?.data||{},tasks=competition.tasks||[],directions=report.designDirections||[],tests=report.validationPlan||[];
  const headings=['本轮开发建议','企业与本次新品','竞争格局与直接对标','使用者的目标与上手过程','建议打样的产品方向','样品验证与下一步'];
  const section=(index,body)=>`<section class="decision-section"><span class="section-kicker">${String(index+1).padStart(2,'0')}</span><h3>${escape(report.sections?.[index]?.title || headings[index])}</h3>${body}</section>`;
  const recommendation=`<p class="decision-rationale">${escape(plain(summary.rationale))}</p>${summary.assumption?`<p class="unknown-note">本轮判断的前提：${escape(plain(summary.assumption))}</p>`:''}${summary.stage?`<p>${escape(plain(summary.stage))}</p>`:''}`;
  const background=contextFields([['品牌 / 企业',company.brand],['主要市场',company.market],['企业经营的品类',company.portfolio],['年销售额',company.annualRevenue],['销售额对应期间',company.revenuePeriod],['已覆盖渠道',company.channels],['渠道规模',company.channelScale],['技术与研发条件',company.capabilities],['本次具体新品',project.name || project.subcategory],['所属子品类',project.subcategory || project.category],['产品阶段',project.stage],['目标售价',project.targetPrice],['本次目标市场',project.targetMarket],['拟发售渠道',project.plannedChannels]])+(context.companyStage?`<div class="research-state"><strong>${escape(context.companyStage.label || '企业经营线索')}</strong><p>${escape(plain(context.companyStage.basis))}</p><p class="unknown-note">${escape(context.companyStage.caveat || '')}</p></div>`:'');
  const table=competitors.length?`<div class="comparison-scroll"><table class="comparison-table"><thead><tr><th>品牌 / 对应款</th><th>产品与实际利益</th><th>价格 / 价格带</th><th>销售渠道</th><th>传播主张</th><th>与本次新品的关系</th><th>销量 / 排名及来源</th></tr></thead><tbody>${competitors.map(c=>`<tr><td><strong>${escape(c.brand)}</strong><br>${escape(c.model)}</td><td>${escape(plain(c.product))}<br>${escape(plain(c.benefit || c.benefits))}</td><td>${escape(reportPrice(c.price))}</td><td>${escape(plain(c.place)||'尚未取得')}</td><td>${escape(plain(c.promotion)||'尚未取得')}</td><td>${escape(plain(c.directness)||'需核对人群、使用方式及同币种价格')}</td><td>销量：${escape(plain(c.sales)||'尚未取得同口径数据')}<br>排名：${escape(plain(c.ranking)||'尚未取得同口径数据')}<br>${sourceLink(c.source || c.sources)}<br><span class="data-origin">${escape(c.status || '用户提供的资料，尚未独立核实')}</span></td></tr>`).join('')}</tbody></table></div>`:'<p class="unknown-note">还没有可核对的具体竞品资料。本节先给出按本次新品生成的研究清单，填入真实产品与来源后再做逐款对标。</p>';
  const research=`<p class="data-origin">${escape(report.sections?.find(s=>s.id==='competition')?.lead || '本版尚未执行实时市场检索；排名、销量和价格只在有实际资料时呈现。')}</p>${table}${tasks.map(t=>`<article class="research-state"><strong>${escape(t.name || t.title)}</strong><p>${escape(t.question || t.description)}</p><p>${escape(plain(t.requiredFields))}</p><p class="unknown-note">${escape(plain(t.whereToLook))}</p></article>`).join('')}<div class="research-queries">${queryRows(report)}</div><div class="decision-actions"><button class="secondary-action" data-action="research-input">补充一款竞品及其来源</button></div>`;
  const users=contextFields([['本次针对谁',journey.targetUser || project.targetUser],['目前经验阶段',journey.experienceLevel || project.experienceLevel],['希望获得的体验或结果',journey.desiredExperience || project.desiredOutcome],['具体活动 / 使用场景',journey.scene]])+`<div class="journey-grid">${(journey.steps || []).map((step,i)=>`<article class="journey-step"><span>${String(i+1).padStart(2,'0')} · ${escape(step.stage)}</span><h4>${escape(step.action)}</h4><p>${escape(step.opportunity)}</p><p class="data-origin">${escape(step.status || '从本次描述整理的活动过程')}</p></article>`).join('')}</div>${journey.learningPrinciple?`<p>${escape(plain(journey.learningPrinciple))}</p>`:''}${(journey.evidence || []).map(e=>`<p class="evidence-note"><strong>${escape(e.label || '已有信息')}</strong> ${escape(e.quote || e.text)} · ${escape(e.status || '用户口述')}</p>`).join('')}`;
  const design=`<p>${escape(report.sections?.find(s=>s.id==='design')?.lead || '以下是本轮建议打样验证的产品方向，具体结构与参数通过试验确定。')}</p>${directions.map(directionCard).join('')}`;
  const validation=tests.map(t=>`<article class="experiment-box"><span class="priority-tag">${escape(t.priority || '下一步')}</span><h4>${escape(t.title)}</h4><p>${escape(t.action)}</p><p><strong>观察什么：</strong>${escape(plain(t.measure))}</p><p><strong>怎样判断：</strong>${escape(plain(t.successCondition))}</p><p><strong>据此做哪个决定：</strong>${escape(plain(t.decision))}</p>${t.requiredInputs?`<p class="unknown-note">需要准备：${escape(plain(t.requiredInputs))}</p>`:''}</article>`).join('');
  $('#diagnosis').innerHTML=`<div class="decision-report"><header class="decision-hero"><span class="decision-label">新品有数 · 新品开发建议${current.demoEvidenceStatus?' · 虚构品牌演示':''}</span><h2>${escape(report.title || `${plain(company.brand)||'你的品牌'} · ${plain(project.name || project.subcategory)||'本次新品'}`)}</h2><p class="decision-recommendation">${escape(summary.recommendation || '先把企业条件与使用者想完成的事连接起来，形成可试做的产品方向。')}</p></header>${section(0,recommendation)}${section(1,background)}${section(2,research)}${section(3,users)}${section(4,design)}${section(5,validation)}<div class="source-notes">${(report.sourceNotes || []).map(n=>`<p class="data-origin"><strong>${escape(n.label)}</strong> ${escape(n.text)} ${sourceLink(n.url?{url:n.url,title:'查看来源'}:null)}</p>`).join('')}</div><div class="feedback-banner"><strong>${current.feedback?.submittedAt?'反馈已记录。':'回看刚才的聊天，留下你的感受。'}</strong><span>${current.feedbackNeedsReview?'你更新了项目或答案，请按最新报告重新确认反馈。':'问题、原话和看过的解释都可以回看。'}</span><button class="secondary-action" data-action="feedback">${current.feedback?.submittedAt?'查看或修改反馈':'回看问题，留下反馈'}</button></div><div class="report-toolbar"><button class="export-button" data-action="export-md">${icon('download')}导出开发建议 Markdown</button><button class="export-button" data-action="export-json">导出完整记录 JSON</button><button class="export-button" data-action="print-report">打印 / 保存 PDF</button><button class="text-button" data-action="notes">完整对话</button><button class="text-button" data-action="research-input">补充竞品资料</button></div></div>`;
}

function render(){
  const inChat=Boolean(current);document.body.dataset.view=inChat?'chat':'landing';$('meta[name="theme-color"]').content=inChat?'#f5f7fa':'#090c12';
  $('#landing').hidden=inChat;$('#conversation').hidden=!inChat;homeVideo.setVisible(!inChat);$('#breadcrumb-current').textContent=inChat?current.title:'新品问询';renderRecent();
  if(!inChat){$('#chat-composer-wrap').hidden=true;return;}
  $('#chat-project-label').textContent=current.title;$('.demo-badge').innerHTML='<span></span>'+(!current.custom?'虚构案例演示':'本次新品讨论');
  $('#messages').innerHTML=getChatTurns(current).map(renderChatTurn).join('');
  renderNote();renderComposer();$('#diagnosis').hidden=!current.complete;
  if(current.complete)renderDiagnosis();
  if(globalThis.__INQUIRY_DEBUG__){globalThis.__INQUIRY_DEBUG_SESSION__=current;document.dispatchEvent(new CustomEvent('xinpin-session',{detail:current}));}
}
function start(scenarioId='fishing',{opening='',custom=false}={}){
  operation++;autoPlaying=false;errors={};editError='';current=createChatSession({scenarioId,opening,custom});
  if(!custom)current.title=SCENARIOS.find(s=>s.id===scenarioId)?.title || '新品开发讨论';sessions.unshift(current);$('#entry-input').value='';document.body.classList.remove('menu-open');persist();render();scrollLatest(true);$('#chat-input').focus({preventScroll:true});
}
function goHome(){operation++;autoPlaying=false;current=null;errors={};document.body.classList.remove('menu-open');persist();render();window.scrollTo(0,0);resizeInput($('#entry-input'));}
function submitCurrent(text,{fromDemo=false}={}){
  if(!current || current.complete || (autoPlaying&&!fromDemo))return;
  const q=getCurrentQuestion(current);if(!q)return;
  const result=submitChatAnswer(current,q.id,text);errors=result.errors || {};
  persist();render();
  if(!result.ok && !result.clarification)toast(Object.values(errors).join('；') || '可以再补充一句，或者看看例子。');
  scrollLatest();
  if(current.complete && result.ok){if(!current.feedback?.submittedAt)openFeedback();}
  else $('#chat-input').focus({preventScroll:true});
  return result;
}
async function runDemo(fresh=false,scenarioId=current?.scenarioId || 'fishing'){
  if(autoPlaying){pauseDemo();persist();renderComposer();toast('已暂停。你可以接着回答，也可以修改前面的内容。');return;}
  if(fresh || !current || current.complete || current.custom)start(scenarioId,{opening:SCENARIOS.find(s=>s.id===scenarioId)?.opening || SCENARIOS[0].opening});
  autoPlaying=true;const token=++operation,id=current.id;renderComposer();
  while(autoPlaying && token===operation && current?.id===id && !current.complete){
    await new Promise(resolve=>setTimeout(resolve,430));if(!autoPlaying || token!==operation || current?.id!==id)break;
    const q=getCurrentQuestion(current);if(!q)break;
    const answer=getSampleAnswers(current.scenarioId,[q.id])[q.id];const result=submitCurrent(answer,{fromDemo:true});
    if(!result?.ok){autoPlaying=false;toast('演示先停在这里，可以接着补充。');break;}
  }
  if(token===operation){autoPlaying=false;renderComposer();}
}
function openDialog(content,{review=false}={}){$('#app-dialog').classList.toggle('review-dialog',review);$('#dialog-content').innerHTML=content;if(!$('#app-dialog').open)$('#app-dialog').showModal();document.body.classList.remove('menu-open');}
function feedbackSource(){return current.feedbackDraft || current.feedbackUi || current.feedback || {};}
function captureFeedbackDraft(){
  const form=$('#feedback-form');if(!current || !form)return;
  const data=new FormData(form),previous=feedbackSource();
  current.feedbackDraft={...previous,...Object.fromEntries(data)};
  if(data.has('awareOfTest'))current.feedbackDraft.awareOfTest=data.get('awareOfTest')==='true';
  for(const key of ['valuableQuestionIds','uselessQuestionIds','unclearQuestionIds'])current.feedbackDraft[key]=[...(previous[key] || [])];
}
function reviewList(){
  const f=feedbackSource();
  return getReviewQuestions(current).map((q,i)=>`<article class="review-question-row" data-review-qid="${q.questionId}"><div class="review-reference-title"><span>${String(i+1).padStart(2,'0')}</span><h3 class="review-question-title">${escape(q.title)}</h3></div><details class="review-question-toggle"><summary>回看我的回答${q.answered?'':' · 这题还没答'}</summary><div class="review-answer">${escape(q.answer || '这题暂时留白。')}${q.extra?`\n补充：${escape(q.extra)}`:''}</div>${q.example?`<div class="review-guidance"><strong>当时看过的例子</strong><p>${escape(q.example)}</p></div>`:''}${q.answered?`<button type="button" class="text-button" data-action="review-edit" data-qid="${q.questionId}">回到原话修改</button>`:''}</details><div class="review-question-tags">${[['valuableQuestionIds','有帮助'],['uselessQuestionIds','没帮上'],['unclearQuestionIds','没看懂']].map(([kind,label])=>`<button type="button" data-action="review-tag" data-kind="${kind}" data-qid="${q.questionId}" aria-pressed="${(f[kind] || []).includes(q.questionId)}">${label}</button>`).join('')}</div></article>`).join('');
}
function selectedReviewLabels(kind){const f=feedbackSource(),ids=f[kind] || [];return ids.length?`已选 ${ids.length} 题：`+getReviewQuestions(current).filter(q=>ids.includes(q.questionId)).map(q=>q.title).join('；'):'可以在问题旁点选，也可以直接说说感受。';}
function refreshReview(){const panel=$('#review-question-list');if(panel){const expanded=[...panel.querySelectorAll('details[open]')].map(el=>el.closest('[data-review-qid]').dataset.reviewQid),top=panel.scrollTop;panel.innerHTML=reviewList();for(const qid of expanded){const detail=panel.querySelector(`[data-review-qid="${qid}"] details`);if(detail)detail.open=true;}panel.scrollTop=top;}for(const kind of ['valuableQuestionIds','uselessQuestionIds','unclearQuestionIds']){const el=document.querySelector(`[data-selected-summary="${kind}"]`);if(el)el.textContent=selectedReviewLabels(kind);}}
function openFeedback(){
  if(!current?.complete)return;
  const f=feedbackSource(),group=(name,label)=>`<label class="feedback-empty-choice"><input type="radio" name="${name}" value="none" ${f[name]==='none'?'checked':''}/> ${label}</label>`;
  const questionField=(name,title,kind,noneLabel)=>`<div class="feedback-field"><label for="feedback-${name}">${title}</label><p class="feedback-prompt-helper" data-selected-summary="${kind}">${escape(selectedReviewLabels(kind))}</p>${group(name==='valuableQuestion'?'valuableChoice':name==='uselessQuestion'?'uselessChoice':'guidanceChoice',noneLabel)}<textarea id="feedback-${name}" name="${name}" rows="2" maxlength="12000" placeholder="可选，补一句你的感受。">${escape(f[name] || '')}</textarea></div>`;
  openDialog(`<h2 class="dialog-title">回看刚才的聊天，点一下就好。</h2><p class="dialog-subtitle">问题和你的回答都列在这里。不用记住题目，也不用懂背后的理论。</p>${current.feedbackNeedsReview?'<p class="stale-feedback-note">你修改了回答。原反馈仍保留，请按更新后的聊天重新确认。</p>':''}<div class="review-layout"><aside class="review-reference"><div class="review-reference-title"><h3>刚才，我们聊了这些</h3><span>${getReviewQuestions(current).length} 个问题</span></div><p class="feedback-prompt-helper">点“回看我的回答”展开原话，再标记有帮助、没帮上或没看懂。</p><div id="review-question-list" class="review-question-list">${reviewList()}</div></aside><form id="feedback-form" class="feedback-form" novalidate>${questionField('valuableQuestion','哪些问题让你更想清楚了一点？','valuableQuestionIds','暂时没有特别有帮助的')}${questionField('uselessQuestion','哪些问题没帮上忙，或者感觉重复？','uselessQuestionIds','暂时没有这样的题') }<div class="feedback-field"><label for="feedback-missedQuestion">还有什么关于产品的事，你想说却没聊到？</label><p class="feedback-prompt-helper">说一件你还在犹豫或没机会说的事就好，不用替系统设计问题。</p><textarea id="feedback-missedQuestion" name="missedQuestion" rows="3" maxlength="12000" placeholder="例如：我还想聊聊，买的人会不会第二次再买。">${escape(f.missedQuestion || '')}</textarea><button type="button" class="feedback-empty-choice" data-action="feedback-none" data-field="missedQuestion">暂时没有</button></div>${questionField('guidance','哪些说法或例子还是不好懂？','unclearQuestionIds','都能看懂，例子也够用')}<div class="feedback-field"><label for="feedback-role">你的角色</label><select id="feedback-role" name="role"><option value="">请选择</option>${['产品负责人','工厂方','渠道方','营销人','其他'].map(r=>`<option ${f.role===r?'selected':''}>${r}</option>`).join('')}</select></div><fieldset class="feedback-field feedback-options"><legend>体验之前，你知道这是一个测试系统吗？</legend>${[[true,'知道'],[false,'不知道']].map(([v,label])=>`<label><input type="radio" name="awareOfTest" value="${v}" ${f.awareOfTest===v?'checked':''}/> ${label}</label>`).join('')}</fieldset><p id="feedback-error" class="batch-error" role="alert"></p><div class="feedback-actions"><button type="button" class="secondary-action" data-action="close-dialog">先看报告</button><button type="submit" class="batch-submit">保存反馈${icon('check')}</button></div></form></div>`,{review:true});
}
function feedbackPayload(){
  captureFeedbackDraft();const f=current.feedbackDraft || {},questions=getReviewQuestions(current);
  const compile=(field,kind,choice,noneText)=>{const selected=questions.filter(q=>(f[kind] || []).includes(q.questionId)).map(q=>`「${q.title}」`);return [...(selected.length?['所选问题：'+selected.join('；')]:[]),f[field]?.trim(),f[choice]==='none'?noneText:''].filter(Boolean).join('\n');};
  return {...f,valuableQuestion:compile('valuableQuestion','valuableQuestionIds','valuableChoice','暂时没有特别有帮助的问题。'),uselessQuestion:compile('uselessQuestion','uselessQuestionIds','uselessChoice','暂时没有没帮上忙或重复的问题。'),guidance:compile('guidance','unclearQuestionIds','guidanceChoice','都能看懂，例子也够用。')};
}
function openCategory(){const active=current.guidanceCategory || 'auto';openDialog(`<h2 class="dialog-title">换一个你熟悉的例子。</h2><p class="dialog-subtitle">只改变解释问题时用的例子，不会替你填写回答。</p><div class="guidance-category-choices"><button class="secondary-action" data-action="set-category" data-category="auto" aria-pressed="${active==='auto'}">根据我的产品选择</button>${getCategoryChoices().map(c=>`<button class="secondary-action" data-action="set-category" data-category="${escape(c.id)}" aria-pressed="${active===c.id}">${escape(c.label)}</button>`).join('')}</div>`);}
function openHelp(){openDialog(`<h2 class="dialog-title">像聊天一样，把新品想清楚。</h2><p class="dialog-subtitle">不用懂理论，也不用一次说完整。</p><div class="help-grid"><div class="help-card"><span>01 / TALK IT THROUGH</span><h3>一次聊一个问题</h3><p>回答后继续往下聊。前面的问答一直在，向上翻就能看见。</p></div><div class="help-card"><span>02 / MAKE IT FAMILIAR</span><h3>用熟悉的东西解释</h3><p>不明白就换个说法，或看看同类产品的例子。也能主动换成你熟悉的品类。</p></div><div class="help-card"><span>03 / KEEP THINKING</span><h3>想到新内容，随时补</h3><p>每条回答都可以原地修改、补充，报告会随最新回答重新整理。</p></div></div><div class="dialog-note">当前为规则版交互演示，尚未连接大模型或外部搜索。所有口述和示例均待验证。</div><div class="dialog-buttons"><button class="primary-action" data-action="help-start">开始聊聊${icon('arrow-right')}</button><button class="secondary-action" data-action="demo">体验完整案例</button></div>`);}
function openProjects(){const items=sessions.slice().sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt));openDialog(`<h2 class="dialog-title">接着上次的想法聊。</h2><p class="dialog-subtitle">问答、修改和草稿都会留在当前浏览器。</p><div class="project-list">${items.map(s=>`<button class="project-card" data-action="resume" data-id="${escape(s.id)}"><span class="project-card-icon">${icon(s.complete?'note':'chat')}</span><span><h3>${escape(s.title)}</h3><p>${getProgress(s).answered} 条回答 · ${new Date(s.createdAt).toLocaleDateString('zh-CN')}</p></span><span class="project-end">${s.complete?(s.feedback?.submittedAt?'已归档':'待反馈'):'继续聊 →'}</span></button>`).join('')||'<p class="empty-state">开始聊天后，记录会出现在这里。</p>'}</div>${legacy.length+archived.length?`<div class="dialog-note">已保留 ${legacy.length+archived.length} 条旧版记录。新版增加了企业与研发信息，旧版记录保持原样。</div><button class="secondary-action" data-action="legacy-export">下载全部旧版记录</button>${archived.map(a=>`<button class="project-card" data-action="view-archive" data-id="${escape(a.id)}">${escape(a.title || '之前的问询')} · 回看原记录</button>`).join('')}`:''}<div class="dialog-buttons"><button class="primary-action" data-action="help-start">${icon('plus')}开始新的聊天</button></div>`);}
function openNotes(){const s=current || sessions[0];if(!s){openProjects();return;}openDialog(`<h2 class="dialog-title">每一条原话，都留在这里。</h2><p class="dialog-subtitle">${escape(s.title)} · ${s.complete?'报告已生成':'聊天仍在继续'} · ${s.feedback?.submittedAt?'已含反馈':'反馈待确认'}</p><div class="record-list">${getChatTurns(s).map(t=>`<div class="record-item"><h3>${escape(t.question.title)}</h3><p>${escape(t.answer || t.pendingAnswer || '尚未回答')}</p>${t.extra?`<p>补充：${escape(t.extra)}</p>`:''}</div>`).join('')}</div><div class="dialog-buttons"><button class="primary-action" data-action="draft-json" data-id="${escape(s.id)}">导出完整记录 JSON</button><button class="secondary-action" data-action="draft-md" data-id="${escape(s.id)}">导出 Markdown</button></div>`);}
function download(content,filename,type){const url=URL.createObjectURL(new Blob([content],{type})),link=document.createElement('a');link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function exportFile(format,{draft=false,id}={}){const s=id?sessions.find(item=>item.id===id):current;if(!s)return;const suffix=s.complete?'新品开发建议':'讨论草稿';if(format==='json')download(JSON.stringify(exportSessionJSON(s),null,2),`新品有数_${suffix}.json`,'application/json;charset=utf-8');else download(exportSessionMarkdown(s),`新品有数_${suffix}.md`,'text/markdown;charset=utf-8');toast('完整记录已准备好下载。');}
function beginEdit(qid,mode='replace'){pauseDemo();const turn=getChatTurns(current).find(t=>t.questionId===qid);if(!turn?.answered)return;current.editDraft={questionId:qid,mode,text:mode==='append'?'':current.answers[qid] || ''};editError='';persist();keepTurnPosition(qid,render);requestAnimationFrame(()=>$('#edited-answer')?.focus({preventScroll:true}));}
function openResearchInput(){
  openDialog(`<h2 class="dialog-title">补充一款具体竞品和来源。</h2><p class="dialog-subtitle">把已有的官网、电商或行业资料放进来。填写来源不等于独立核实；销量和排名请注明平台、时期与口径。</p><form id="research-form" class="feedback-form"><div class="feedback-field"><label>品牌<input name="brand" required maxlength="120" placeholder="资料中实际出现的品牌"/></label></div><div class="feedback-field"><label>具体款 / 型号<input name="model" required maxlength="160" placeholder="具体到可对比的产品款式"/></label></div>${[['product','产品内容 / 规格'],['benefit','主打的用户利益'],['price','价格、币种和销售地区'],['place','主要销售渠道'],['promotion','对外宣传的主张'],['sales','销量及平台、时期、口径（没有可以空着）'],['ranking','排名及榜单范围、时期（没有可以空着）'],['sourceTitle','来源标题 / 发布机构'],['asOf','数据对应日期 / 期间']].map(([name,label])=>`<div class="feedback-field"><label>${label}<input name="${name}" maxlength="800"/></label></div>`).join('')}<div class="feedback-field"><label>来源链接<input name="sourceUrl" type="url" required placeholder="https://…"/></label></div><div class="feedback-field"><label>摘录原文<textarea name="quote" rows="4" maxlength="12000" placeholder="保留支持以上产品参数或数据的原文。"></textarea></label></div><p id="research-error" class="batch-error" role="alert"></p><div class="feedback-actions"><button type="button" class="secondary-action" data-action="close-dialog">取消</button><button type="submit" class="primary-action">保存资料，更新对标</button></div></form>`);
}
function openArchive(id){const s=archived.find(item=>item.id===id);if(!s)return;openDialog(`<h2 class="dialog-title">${escape(s.title || '之前的问询')}</h2><p class="dialog-subtitle">这是升级前的原始记录，内容已完整保留。新版会先补齐企业与本次新品信息。</p><div class="record-list">${(s.messages || []).map(m=>`<div class="record-item"><h3>${m.role==='user'?'你':'新品有数'}</h3><p>${escape(m.text)}</p></div>`).join('')}</div><button class="secondary-action" data-action="legacy-export">下载全部旧记录</button>`);}

document.addEventListener('click',async event=>{
  const el=event.target.closest('[data-action]');if(!el)return;event.preventDefault();const action=el.dataset.action;
  if(action==='focus-entry'){$('#entry-input').focus({preventScroll:true});return;}
  if(action==='choose-video'){homeVideo.chooseFile();return;}
  if(action==='menu'){document.body.classList.add('menu-open');return;}
  if(action==='close-menu'){document.body.classList.remove('menu-open');return;}
  if(action==='close-dialog'){captureFeedbackDraft();persist();$('#app-dialog').close();return;}
  if(action==='new'||action==='home'){goHome();return;}
  if(action==='help'){openHelp();return;}
  if(action==='projects'){openProjects();return;}
  if(action==='notes'){openNotes();return;}
  if(action==='scenario'){const scenario=SCENARIOS.find(s=>s.id===el.dataset.scenario);start(scenario?.id||'fishing',{opening:scenario?.opening||''});return;}
  if(action==='demo'){$('#app-dialog').close();await runDemo(true,el.dataset.scenario || 'fishing');return;}
  if(action==='auto-demo'){await runDemo();return;}
  if(action==='help-start'){$('#app-dialog').close();goHome();$('#entry-input').focus();return;}
  if(action==='resume'){const s=sessions.find(p=>p.id===el.dataset.id);if(!s)return;pauseDemo();operation++;current=s;upgradeToChat(current);$('#app-dialog').close();document.body.classList.remove('menu-open');persist();render();scrollLatest(true);return;}
  if(action==='inspire'){$('#entry-input').value=SCENARIOS[0].opening;resizeInput($('#entry-input'));$('#entry-input').focus();return;}
  if(action==='profile'){openDialog('<h2 class="dialog-title">白雪的工作空间</h2><p class="dialog-subtitle">聊天、修改和反馈保存在当前浏览器。你可以随时在“思考记录”里导出 Markdown 和 JSON。</p><div class="dialog-note">规则版交互演示，尚未连接大模型或外部研究服务。</div>');return;}
  if(action==='legacy-export'){download(JSON.stringify({oldProjects:legacy,previousSessions:archived},null,2),'新品有数_旧版记录.json','application/json');return;}
  if(action==='feedback'){openFeedback();return;}
  if(action==='view-archive'){openArchive(el.dataset.id);return;}
  if(action==='research-input'){openResearchInput();return;}
  if(action==='review-tag'){
    captureFeedbackDraft();const kind=el.dataset.kind;if(!['valuableQuestionIds','uselessQuestionIds','unclearQuestionIds'].includes(kind))return;
    const f=current.feedbackDraft,qid=el.dataset.qid,ids=f[kind]||[];f[kind]=ids.includes(qid)?ids.filter(id=>id!==qid):[...ids,qid];
    const choice=kind==='valuableQuestionIds'?'valuableChoice':kind==='uselessQuestionIds'?'uselessChoice':'guidanceChoice';
    if(f[kind].length){delete f[choice];document.querySelectorAll(`[name="${choice}"]`).forEach(input=>{input.checked=false;});}
    persist();refreshReview();return;
  }
  if(action==='feedback-none'){const input=document.querySelector(`#feedback-form [name="${el.dataset.field}"]`);if(input){input.value='暂时没有。';captureFeedbackDraft();persist();}return;}
  if(action==='review-edit'){captureFeedbackDraft();persist();$('#app-dialog').close();beginEdit(el.dataset.qid);document.querySelector(`[data-turn-id="${el.dataset.qid}"]`)?.scrollIntoView({block:'center',behavior:'instant'});return;}
  if(action==='export-md'||action==='export-json'){exportFile(action.endsWith('json')?'json':'md');return;}
  if(action==='draft-md'||action==='draft-json'){exportFile(action.endsWith('json')?'json':'md',{draft:true,id:el.dataset.id});return;}
  if(action==='print-report'){window.print();return;}
  if(!current)return;
  if(action==='jump-question'){document.querySelector(`[data-turn-id="${el.dataset.qid}"]`)?.scrollIntoView({behavior:'smooth',block:'center'});return;}
  if(action==='edit-answer'||action==='append-answer'){beginEdit(el.dataset.qid,action==='append-answer'?'append':'replace');return;}
  if(action==='cancel-edit'){const qid=current.editDraft?.questionId;current.editDraft=null;editError='';persist();keepTurnPosition(qid,render);return;}
  if(action==='category'){openCategory();return;}
  if(action==='set-category'){
    const category=el.dataset.category;if(category==='auto')delete current.guidanceCategory;else if(getCategoryChoices().some(c=>c.id===category))current.guidanceCategory=category;else return;
    $('#app-dialog').close();const q=getCurrentQuestion(current);if(q){current.rephrasedQuestionIds=[...new Set([...(current.rephrasedQuestionIds||[]),q.id])];if((current.questionTelemetry[q.id]?.maxHelpLevel||0)<1)advanceHelp(current,q.id);else {const g=getGuidance(current,q.id);current.messages.push({role:'assistant',text:`换一个熟悉的例子：${g.productName}。\n${g.productIntro}\n${g.example}`,questionIds:[q.id],helpLevel:1,productIntro:g.productIntro,categoryId:g.categoryId,kind:'guidance-category-change',at:new Date().toISOString()});}}
    persist();render();scrollLatest();return;
  }
  if(current.complete || autoPlaying)return;
  const q=getCurrentQuestion(current);if(!q)return;
  if(action==='rephrase'){if(!current.rephrasedQuestionIds?.includes(q.id))current.messages.push({role:'assistant',text:getGuidance(current,q.id).simpleExplanation,questionIds:[q.id],kind:'question-rephrase',at:new Date().toISOString()});current.rephrasedQuestionIds=[...new Set([...(current.rephrasedQuestionIds||[]),q.id])];const telemetry=current.questionTelemetry[q.id];if(telemetry){telemetry.stalled=true;telemetry.rephrased=true;}persist();render();scrollLatest();return;}
  if(action==='help-next'){advanceHelp(current,q.id);persist();render();scrollLatest();return;}
  if(action==='pick-option'){setDraft(current,q.id,el.dataset.value);persist();renderComposer();$('#chat-input').focus({preventScroll:true});return;}
  if(action==='sample-answer'){
    if(current.custom){advanceHelp(current,q.id);persist();render();scrollLatest();return;}
    setDraft(current,q.id,getSampleAnswers(current.scenarioId,[q.id])[q.id]);persist();renderComposer();$('#chat-input').focus({preventScroll:true});return;
  }
  if(action==='skip-answer'){submitCurrent('');}
});
document.addEventListener('input',event=>{
  const el=event.target;
  if(el.id==='chat-input' && current){const q=getCurrentQuestion(current);if(q){setDraft(current,q.id,el.value);persist();resizeInput(el);}}
  if(el.hasAttribute('data-edit-draft') && current?.editDraft){current.editDraft.text=el.value;persist();}
  if(el.closest('#feedback-form') && current){captureFeedbackDraft();persist();}
});
document.addEventListener('change',event=>{
  const el=event.target;if(!el.closest('#feedback-form') || !current)return;
  captureFeedbackDraft();
  const kind={valuableChoice:'valuableQuestionIds',uselessChoice:'uselessQuestionIds',guidanceChoice:'unclearQuestionIds'}[el.name];
  if(kind && el.value==='none'){current.feedbackDraft[kind]=[];refreshReview();}
  persist();
});
document.addEventListener('submit',event=>{
  if(event.target.id==='chat-form'){event.preventDefault();submitCurrent($('#chat-input').value);}
  if(event.target.id==='edit-answer-form'){
    event.preventDefault();const qid=current.editDraft?.questionId;if(!qid)return;
    const value=String(new FormData(event.target).get('editedAnswer')||'');
    const result=reviseChatAnswer(current,qid,value,{mode:current.editDraft.mode});
    if(!result.ok){editError=Object.values(result.errors||{}).join('；')||'先写一句你的修改或补充。';keepTurnPosition(qid,render);return;}
    current.editDraft=null;editError='';persist();keepTurnPosition(qid,render);
    if(result.requiresScopeConfirmation){scrollLatest();toast('请在聊天里确认本次是否换了新品。原来的回答已保留。');return;}
    toast(result.reopened?'已更新，这次聊天可以继续了。':current.complete?'回答和报告已更新，请按最新内容再确认反馈。':'已更新，前后的聊天都保留着。');
  }
  if(event.target.id==='research-form'){
    event.preventDefault();const fields=Object.fromEntries(new FormData(event.target));const reference={...fields,benefits:fields.benefit?[fields.benefit]:[],source:{url:fields.sourceUrl,title:fields.sourceTitle,quote:fields.quote,asOf:fields.asOf},sourceVerification:'user-supplied-not-checked'};const result=addResearchReference(current,reference);if(!result.ok){$('#research-error').textContent=Object.values(result.errors || {}).join('；');return;}persist();$('#app-dialog').close();render();toast('已保存为有来源的待核实资料，对标内容已更新。');
  }
  if(event.target.id==='feedback-form'){
    event.preventDefault();const payload=feedbackPayload(),result=saveFeedback(current,payload);
    if(!result.ok){$('#feedback-error').textContent=Object.values(result.errors||{}).join('；');return;}
    current.feedbackUi={...current.feedbackDraft};current.feedbackDraft=null;persist();$('#app-dialog').close();renderDiagnosis();toast('反馈已保存，所选题目和原话会一起留在记录里。');
  }
});
$('#entry-form').addEventListener('submit',event=>{event.preventDefault();const opening=$('#entry-input').value.trim();if(opening)start('fishing',{opening,custom:true});});
$('#entry-input').addEventListener('input',()=>resizeInput($('#entry-input')));
for(const id of ['entry-input','chat-input'])$(`#${id}`).addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();$(`#${id}`).closest('form').requestSubmit();}});
document.addEventListener('keydown',event=>{if(event.key==='Escape')document.body.classList.remove('menu-open');if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='k'){event.preventDefault();$('#app-dialog').close();goHome();$('#entry-input').focus();}});
$('#app-dialog').addEventListener('close',()=>{captureFeedbackDraft();persist();});
$('#app-dialog').addEventListener('click',event=>{if(event.target===$('#app-dialog')){const r=event.target.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom){captureFeedbackDraft();persist();event.target.close();}}});
render();resizeInput($('#entry-input'));
if(current){persist();if(current.editDraft)requestAnimationFrame(()=>$('#edited-answer')?.scrollIntoView({block:'center'}));else scrollLatest(true);}
