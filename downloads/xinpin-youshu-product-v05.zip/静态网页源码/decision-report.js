// Product decisions are derived from this project's statements and attributed
// references. A proposed mechanism is a design hypothesis, never market proof.
const text = value => {
  if (value == null) return '';
  if (typeof value === 'string' || typeof value === 'number') return String(value).trim();
  if (Array.isArray(value)) return value.map(text).filter(Boolean).join('；');
  return text(value.raw || value.text || value.value || value.summary || '');
};
const brief = (value, length = 180) => { const s = text(value); return s.length > length ? `${s.slice(0, length)}…` : s; };
const meaningful = value => text(value) && !/^(?:不知道|暂时不知道|不清楚|暂无|还没有|还没想好|暂时没有|待补充|未提供|先留白)[。！.!\s]*$/.test(text(value));
const safeURL = value => { try { const u = new URL(text(value)); return ['https:', 'http:'].includes(u.protocol) && !u.username && !u.password ? u.href : ''; } catch { return ''; } };
const LABELS = {
  'B1-brand':'品牌与主要市场', 'B2-portfolio':'企业现有品类', 'B3-sales':'年销售额与统计期间',
  'B4-channels':'现有渠道及规模', 'B5-capability':'技术、研发与制造条件',
  'N1-scope':'本次具体新品', 'N2-stage':'当前研发阶段', 'N3-commercial':'目标售价与发售计划',
  'M1-references':'已知竞争参考', 'M2-observations':'现有市场资料',
  'U1-user':'目标使用者与经验', 'U2-goal':'希望获得的体验', 'U3-journey':'使用过程',
  'U4-learning':'第一次使用与学习', 'U5-evidence':'判断来自什么观察',
  'D1-outcome':'优先改善的结果', 'D2-ideas':'已经想到的设计', 'D3-delivery':'实现条件与约束', 'D4-validation':'样品验证安排',
};

function normalizeContext(session) {
  const a = id => text(session.answers?.[id]);
  const raw = session.context || session.projectContext || {};
  const c = raw.company || {}, p = raw.project || {};
  const company = {
    brand:text(c.brand) || a('B1-brand'), market:text(c.market),
    portfolio:text(c.portfolio) || a('B2-portfolio'),
    annualRevenue:text(c.annualRevenue) || a('B3-sales'), revenuePeriod:text(c.revenuePeriod),
    channels:text(c.channels) || a('B4-channels'), channelScale:text(c.channelScale),
    capabilities:text(c.capabilities) || a('B5-capability'),
  };
  const project = {
    category:text(p.category), subcategory:text(p.subcategory),
    name:text(p.name) || text(p.subcategory) || a('N1-scope'), stage:text(p.stage) || a('N2-stage'),
    targetPrice:text(p.targetPrice), targetMarket:text(p.targetMarket), plannedChannels:text(p.plannedChannels),
    targetUser:text(p.targetUser) || a('U1-user'), experienceLevel:text(p.experienceLevel),
    desiredOutcome:text(p.desiredOutcome) || a('D1-outcome') || a('U2-goal'),
    commercialBrief:a('N3-commercial'),
  };
  if (!project.name) project.name = text(session.opening || session.initialIdea) || '本次待开发新品';
  const companyWords = `${company.portfolio} ${company.channels} ${company.capabilities}`;
  let stage = '先按已提供的经营情况评估新品项目';
  if (/未销售|还没销售|尚未销售|未开始销售|没有销售|未商业化/.test(company.annualRevenue)) stage = '业务尚在探索，本次先验证产品与第一批购买';
  else if (/代工|OEM|供料|供货/.test(companyWords) && /自有品牌|自己品牌|做品牌|转品牌/.test(`${companyWords} ${a('N1-scope')}`)) stage = '已有供货或制造基础，正在开展自有品牌新品';
  else if (meaningful(company.annualRevenue) && meaningful(company.channels)) stage = '已有经营与渠道基础，当前是新品开发项目';
  else if (meaningful(company.capabilities)) stage = '已有部分研发或交付条件，需要围绕具体新品配置';
  return { company, project, companyStage:{label:stage,basis:[company.annualRevenue && `销售情况：${company.annualRevenue}`,company.channels && `渠道情况：${company.channels}`].filter(Boolean),caveat:'企业经营阶段与本次新品研发阶段分开看；不把销售额直接等同于利润、研发能力或市场地位。'} };
}

function getDomain(context, answers) {
  const scope = `${context.project.subcategory || context.project.name || context.project.category || text(answers['N1-scope']).replace(/(?:不做|不包含|不讨论|不是)[^，。；\n]{0,20}/g,'')}`;
  if (/路亚/.test(scope)) return 'lure';
  if (/台钓|手竿|鲫鱼竿|鲤鱼竿/.test(scope)) return 'pole';
  if (/海钓|船钓|矶钓|冲浪钓/.test(scope)) return 'sea';
  if (/钓竿|钓鱼|渔具|鱼竿/.test(scope)) return 'fishing';
  if (/电动牙刷|牙刷/.test(scope)) return 'brush';
  if (/人参|红参|饮料|饮品|酸奶|咖啡|能量饮/.test(scope)) return 'beverage';
  if (/红酒|葡萄酒|品酒/.test(scope)) return 'wine';
  if (/登山鞋|防滑鞋|徒步鞋|雨衣|防雨|防滑/.test(scope)) return 'protection';
  return 'general';
}

function targetLabel(context, domain) {
  const scope = `${context.project.name} ${context.project.subcategory}`;
  const beginner = /新手|入门|初学|第一次|初次|刚开始/.test(`${scope} ${context.project.targetUser} ${context.project.experienceLevel}`);
  if (domain === 'lure') return beginner ? '新手路亚竿' : '本次路亚竿新品';
  if (domain === 'pole') return beginner ? '新手台钓竿' : '本次台钓竿新品';
  if (domain === 'sea') return beginner ? '新手海钓竿' : '本次海钓竿新品';
  return brief(context.project.name || context.project.subcategory || context.project.category, 72);
}

function evidence(session, ids) {
  return ids.filter(id => meaningful(session.answers?.[id])).map(id => ({
    questionId:id,label:LABELS[id] || '本次问答',quote:text(session.answers[id]),
    status:'企业或受访者提供的信息，尚未独立核实',
  }));
}

function companyFit(context, action, supplement) {
  const c = context.company;
  const existing = [meaningful(c.capabilities) ? `你提到的技术与研发条件「${brief(c.capabilities, 110)}」` : '', meaningful(c.channels) ? `现有渠道「${brief(c.channels, 90)}」` : ''].filter(Boolean);
  return `${existing.length ? `可先借助${existing.join('，以及')}，` : '先确认一位研发负责人和可接触的实际使用者，'}${action}。${supplement}`;
}

function fishingDirections(context, session, domain) {
  const a = id => text(session.answers?.[id]);
  const words = [a('U3-journey'),a('U4-learning'),a('D1-outcome'),a('D2-ideas')].join(' ');
  const novice = /新手|入门|初学|第一次|初次|从未|没有经验/.test(`${context.project.name} ${a('U1-user')} ${context.project.experienceLevel}`);
  const target = targetLabel(context,domain);
  const social = /一起|同伴|朋友|家人|社交|成就|分享|好玩|乐趣/.test(`${a('U2-goal')} ${a('U3-journey')}`);
  const base = {status:'设计假设',scope:target,evidenceBasis:evidence(session,['U1-user','U2-goal','U3-journey','U4-learning','D1-outcome','D2-ideas','D3-delivery'])};
  const list = [];
  function add(key, keywords, d, bonus=0) { const hits = keywords.filter(word => words.includes(word)).length;list.push({...base,...d,key,score:hits*3+bonus}); }
  if (domain === 'lure' || domain === 'fishing') {
    add('preparation',['组装','装配','装轮','线轮','穿线','选线','选饵','绑','搭配','准备'],{
      name:'让第一次准备装备有清楚的操作路径',goal:'让目标使用者能完成准备，而不是先掌握一套专业参数',
      scenario:'第一次准备这款钓竿，或到达钓场后开始组装与选择搭配时',userAction:'辨认握位和装轮方向，完成竿、轮、线及适配范围的准备',
      currentBarrierOrOpportunity:novice?'新手可能不知道操作顺序及各部件怎样匹配；这不等于他要先提出结构方案。':'把经常重复的装备准备步骤做得更清楚、一致，减少无效调整。',
      proposedMechanism:'在握柄、装配方向和关键操作位置设计可辨认的触觉或形态引导；明确可执行的竿轮线搭配范围。需要套装配合的部分单列确认，不默认整套系统已经具备。',
      function:'握位、装配方向与竿轮线匹配引导',benefit:'第一次使用时更容易知道先做什么、怎样做对，减少依赖别人逐步代劳',
      companyFit:companyFit(context,'用现有打样条件比较普通版本与操作引导版本','竿轮适配和制造限制由研发实测，不能仅用标识代替结构可用性。'),
      validation:{action:'招募符合本次目标的使用者，分别用两版样品完成同一套准备任务，记录哪里求助、返工或停住。',measure:'独立完成的步骤、求助与错误位置、准备时长，以及使用者能否解释接下来怎么做。',successCondition:'先约定任务、对照版本与合格标准；若引导版本能稳定减少关键错误且不影响正常操作，就保留。否则改机制，而不是换颜色。'}
    },novice?2:0);
    add('casting',['抛投','抛','甩','炸线','发力','握姿','握持','练习','缠线','角度'],{
      name:'把第一次抛投做成能练会、能纠正的体验',goal:'让初学者逐步掌握动作，而不是把会不会钓鱼当作使用前提',
      scenario:'第一次在合适的练习环境中学习握竿与抛投时',userAction:'建立握姿、理解发力与释放的顺序，并知道哪一步需要调整',
      currentBarrierOrOpportunity:'新品可以创造更容易上手的体验，不需要使用者先说出要怎样改竿体或握柄。',
      proposedMechanism:'把握位、方向与动作提示整合进握柄或可试验的辅助结构；设计从少量动作到完整抛投的练习路径。对不同结构版本做同任务比较，不能只凭材料名或“更轻”推定更好学。',
      function:'握姿与方向提示，配合分阶段抛投练习',benefit:'更快理解如何开始练习、哪里做错，在减少反复挫败的同时建立继续钓鱼的信心',
      companyFit:companyFit(context,'让研发与一线教练一起比较握柄或辅助件样型','具体结构、配重与性能边界由样品测试确定，不能承诺自动抛准或自动中鱼。'),
      validation:{action:'在受控练习场景中，让同经验者分别尝试普通样品与辅助样品；给相同说明，观察连续几轮练习。',measure:'能否独立完成约定动作、错误类型是否减少、是否理解纠正方法，以及愿不愿继续练习。',successCondition:'提前和研发、教练约定安全与完成标准。只有完成率或学习表现改善且没有引入操作负担，才进入下一轮结构优化。'}
    },novice?3:0);
  } else {
    add('setup',['准备','调漂','线组','绑','组装','搭配','鱼漂','钓组'],{
      name:domain==='pole'?'让线组准备与基础操作更容易掌握':'让首次装备准备和基础操作更清楚',goal:'围绕本次具体钓法完成关键准备，不套用另一钓法的操作系统',
      scenario:'开始本次钓法的第一次准备和练习时',userAction:domain==='pole'?'辨认竿、线组、浮漂的关系，完成基本准备并理解接下来的操作':'按照本次海钓方式完成装备准备和基础动作',
      currentBarrierOrOpportunity:'第一次尝试时可以通过产品引导和练习降低理解门槛，而不是要求使用者先给出研发规格。',
      proposedMechanism:'把本次钓法的必要准备顺序、握持与适配关系转化为可试验的结构引导和配置；需要线组或辅件合作的部分明确边界。',
      function:'与具体钓法相符的准备、握持与配置引导',benefit:'使用者更容易独立开始，而不是依赖专业人员全程代劳',companyFit:companyFit(context,'先围绕已经能打样的部件试做必要引导','不同钓法的操作和安全要求分别核实，不把路亚练习方案直接移用。'),
      validation:{action:'让目标经验水平的使用者按实际钓法完成准备任务，比较常规版本与引导版本。',measure:'独立完成步骤、求助位置、关键错误与使用负担。',successCondition:'事先约定对应钓法的完成和安全标准；引导应改善关键任务，不能只让演示看起来更复杂。'}
    },novice?3:1);
  }
  add('feedback',['鱼讯','信号','反馈','触底','挂底','挂障','感知','辨认','判断','振动','手感'],{
    name:'让使用者能理解关键反馈，而不只是感觉到变化',goal:'把真实使用中的感受转成可理解、可练习的判断',
    scenario:'第一次遇到受力、触底或其他反馈，尚不知道它代表什么时',userAction:'区分不同反馈并选择接下来怎样操作',currentBarrierOrOpportunity:'“信号更强”与“新手能看懂信号”不是同一件事；这是值得通过设计验证的体验机会。',
    proposedMechanism:'结合握柄或反馈传递样型，设计可重复、能对比的基础感受练习；先在受控条件下说明不同反馈，再观察真实场景能否迁移。具体材料与参数由研发确定。',
    function:'可辨认的反馈传递与配套基础练习',benefit:'知道自己感受到了什么、接下来能做什么，增强理解和掌控感',
    companyFit:companyFit(context,'用可重复的受力或反馈演示比较样型','若现有技术不能带来可辨认差异，应调整方案，不把抽象“手感好”直接当购买理由。'),
    validation:{action:'用可复现的模拟任务，再接真实场景，让使用者说出所感受的差异和判断依据。',measure:'辨认正确性、判断所需帮助、重复体验后能否独立操作，以及主观掌控感。',successCondition:'先约定可区分的反馈与操作标准；需要在多次任务中表现出可学习的区别，单次“感觉不错”不算通过。'}
  },novice?1:3);
  add('progression',['进阶','渐进','适应','持续','第二次','放弃','复用','成长','陪伴','好玩'],{
    name:novice?'把第一次尝试接到后续进阶':'让目标体验可以重复获得',goal:novice?'让入门之后有继续用下去的路径':'让熟练使用者在不同次数中获得稳定体验',
    scenario:'从第一次练习到再次使用这款新品时',userAction:novice?'先完成基础操作，再逐步理解更多组合与反馈':'按目标玩法重复完成关键动作并比较表现',
    currentBarrierOrOpportunity:social?'参与、分享或与同伴一起玩的体验也可以构成开发目标，不必先证明生活中存在一个麻烦。':'新品的价值可以是更有掌控感、更愿意继续参与的体验，而不仅是消除不便。',
    proposedMechanism:novice?'先提供设置更少、动作更明确的入门使用方式，再分阶段引入进阶组合；是否能在同一支竿上兼容，需要结构与性能验证。':'围绕目标动作的稳定性与反馈一致性比较样品，把每次都能获得的体验落到可验证任务。',
    function:novice?'入门与进阶的分阶段使用支持':'关键动作与反馈的一致性设计',benefit:novice?'第一次能开始，之后知道如何继续学，不因为无从下手而失去兴趣':'更容易重复获得目标体验，知道产品差异对自己有什么实际意义',
    companyFit:companyFit(context,'利用现有渠道安排第一次与再次使用的跟踪','先把首次完成和再次使用分开评估，不能把到店人数直接当作持续使用或复购。'),
    validation:{action:'跟踪同一组目标使用者的首次与再次练习，保留过程记录及是否主动继续参与。',measure:'任务掌握情况、再次使用意愿与实际再次参与，以及是否需要同样程度的帮助。',successCondition:'在约定周期里观察到从依赖帮助到独立操作的进展，并保留退出原因；没有进展时回到具体步骤修改。'}
  },social?3:0);
  return list.sort((x,y)=>y.score-x.score).slice(0,3);
}

function otherDirections(context, session, domain) {
  const a=id=>text(session.answers?.[id]), novice=/新手|入门|第一次|初次|初学/.test(`${context.project.name} ${a('U1-user')}`);
  const basis=evidence(session,['U1-user','U2-goal','U3-journey','U4-learning','D1-outcome','D2-ideas','D3-delivery']);
  const goal=meaningful(a('D1-outcome'))?brief(a('D1-outcome'),110):meaningful(a('U2-goal'))?brief(a('U2-goal'),110):'更容易开始、理解并完成一次有价值的使用';
  const common={status:'设计假设',evidenceBasis:basis};
  const create=(key,name,userAction,mechanism,benefit,measure)=>({...common,key,name,goal,scenario:meaningful(a('U3-journey'))?brief(a('U3-journey'),200):'目标使用者第一次接触并开始使用这款新品时',userAction,currentBarrierOrOpportunity:'从使用者想获得的结果与实际操作出发，不要求他提前描述尚未见过的技术方案。',proposedMechanism:mechanism,function:name,benefit,companyFit:companyFit(context,'先用现有条件制作能相互比较的样品','原话里没有说明的制造与交付能力，列入样品评审确认。'),validation:{action:`让目标使用者在相同场景下比较两种样品，观察是否更容易${userAction}，再问具体原因。`,measure,successCondition:'先记录原样品表现并约定通过标准；新版本必须在目标任务上有可重复的改善，同时不增加不可接受的负担。'}});
  if(domain==='brush')return [
    create('adapt','让初次使用有可适应的过程','从习惯的刷牙方式过渡到新的操作','比较较温和的初始设置与逐步过渡的使用路径，结合刷头与握持样型验证。适应时长按试用证据确定，不默认所有人需要固定天数。','初次接触更容易接受，也知道下一步如何逐渐掌握。','初次接受度、是否中断、正确完成动作的情况与口腔不适报告。'),
    create('posture','让姿势或力度更容易掌握','辨认握持方向并完成合适的动作','比较握柄形态、方向提示与可试验的反馈方案；是否有助于控制姿势和力度，交由研发、使用测试与专业人员共同确认。','降低靠猜测使用的程度，让人知道自己是否在正确操作。','动作理解、求助次数、适用性与安全评审结果。'),
  ];
  if(domain==='beverage')return [
    create('occasion','让产品适合那一次具体饮用','选择、携带、打开并完成一次饮用','围绕实际饮用时点比较口味、容量、开启和携带样品；每个变化对应一个真实动作，不仅换包装。','在目标时刻更容易愿意喝、方便喝完；是否补充精力等效果需单独建立证据。','实际饮用完成情况、口味接受、携带开启表现及再次选择。'),
    create('understanding','让实际体验和产品说明说同一件事','理解自己喝的是什么、为什么可能选择它','把原料、口感和使用方式用可理解的说明与实际样品对应，观察盲尝和看说明后判断的差别；不把产地、年份直接当作人人都在意的利益。','知道它与日常选择有什么可感知的差别，不必先懂原料知识。','能否用自己的话解释差别、实际选择理由及重复饮用表现。'),
  ];
  if(domain==='wine')return [
    create('first-choice','让第一次选择有能感受的依据','在几种风味中尝出自己偏好的方向','用适合初次比较的小规格样品、可直接对照的风味组合和易懂说明，让人先体验再表达偏好；具体口感组合通过盲尝筛选。','没有喝过很多种也能开始选择，并逐渐知道自己喜欢什么。','实际风味偏好、能否描述可感知差别、下一次是否愿意主动选择。'),
    create('serving','把第一次饮用过程做得容易完成','完成开启、适饮准备与一次合适的饮用','围绕实际场景比较规格、开启与饮用提示，必要时设计渐进体验组合；不要求新手先说出理想酒的技术参数。','第一次尝试更从容，愿意继续探索，而不是只听懂专业术语。','是否能独立完成饮用准备、体验接受度与再次体验行为。'),
  ];
  if(domain==='protection')return [
    create('task','围绕具体环境验证核心功能','在描述的天气或地面环境中完成目标活动','把防雨、防滑等功能要求对应到合适的材料、结构与受控测试，再比较穿用、活动和适配样品。性能不能靠宣传语或一次体验确认。','在约定条件下获得所需保护或操作体验。','相应性能测试、任务完成、穿用负担与安全评审。'),
    create('fit','让功能在真实使用方式下生效','正确穿用、调整并持续使用','比较适配、调整和动作范围样品，确认使用者会不会因为不好穿、不易调整而失去功能表现。','核心功能与日常使用一起成立，不用为了功能牺牲基本可用性。','穿用和调整完成情况、活动表现以及核心性能是否保持。'),
  ];
  return [
    create('key-action',novice?'让第一次使用的关键动作更容易掌握':'把最重要的使用结果做成可比较的样品','完成这次问答中最重要的使用动作',meaningful(a('D2-ideas'))?`把你已经提出的「${brief(a('D2-ideas'),180)}」转成与现有做法可比较的样品；分别核对功能怎样改变了使用动作，以及结果是否更好。`:'先用低成本模型呈现使用过程里最重要的一步，再比较两种结构、操作或体验机制；通过观察选择具体实现，不把颜色变化自动当成产品创新。','更容易完成想做的事，或获得更愿意再次体验的结果。','关键动作完成、依赖帮助的程度、具体体验差别与再次选择。'),
    create('experience','让产品差异能够被真实体验','感受并理解这款新品带来的具体变化','围绕所述目标设计可重复的对比体验，记录使用者实际做了什么、感觉有什么不同；产品团队负责把结果转成技术方案。','不必先说出理想功能，也能通过体验表达喜好和选择。','实际选择、可描述的体验差别、接受与放弃的原因。'),
  ];
}

function normalizeCompetitors(session, context) {
  const research=session.context?.research || session.projectContext?.research || {};
  const sourceList=(research.sources || []).filter(source=>!source.outdated);
  const entries=(research.competitors?.length?research.competitors:session.researchReferences || []).filter(entry=>!entry.outdated);
  return entries.map((entry,index)=>{
    const source=sourceList.find(s=>s.id===entry.sourceId || (entry.sourceUrl && (s.url===entry.sourceUrl || s.sourceUrl===entry.sourceUrl))) || {};
    const url=safeURL(entry.sourceUrl || entry.source?.url || source.url || source.sourceUrl);
    const verified=entry.verified===true && source.verified===true && source.retrieved===true;
    const product=text(entry.product || entry.category || entry.description), model=text(entry.model);
    const sourceLabel=text(entry.sourceTitle || source.title || entry.source?.title) || (url?'用户提供的网页链接':'用户提供的竞争参考');
    const status=verified?'来源内容已核对':'用户提供，网页与数据尚未独立核对';
    const brand=text(entry.brand) || '品牌尚未填写';
    const missingFields=[];
    for(const [field,label]of [['model','具体型号'],['price','售价与币种'],['place','销售渠道'],['promotion','主推表达'],['sales','销量统计口径'],['ranking','排名范围与时间']])if(!meaningful(entry[field]))missingFields.push(label);
    const scope=`${context.project.name} ${context.project.subcategory}`;
    const sameLure=/路亚/.test(scope) && /路亚|lure|spinning|casting/i.test(`${product} ${model}`);
    const samePole=/台钓|手竿/.test(scope) && /台钓|手竿/.test(`${product} ${model}`);
    const beginner=/新手|入门|初学/.test(`${scope} ${context.project.targetUser}`);
    const beginnerMatch=/新手|入门|beginner|entry.level/i.test(`${product} ${text(entry.benefit || entry.benefits)}`);
    let directness='待核对具体型号、使用者与价带';
    if((sameLure||samePole) && (!beginner||beginnerMatch))directness='同品类与相近使用者的对标对象；价格和性能范围仍需核对';
    else if((/路亚|台钓|钓竿/.test(scope) && /牙刷|toothbrush|红酒|wine|运动鞋/i.test(product)))directness='横向设计参考，不是直接竞争款';
    return {
      id:text(entry.id)||`reference-${index+1}`,brand,model:model||'具体型号待补',product:product||'产品范围待补',
      price:text(entry.price)||'售价、币种和渠道待补', place:text(entry.place)||'销售渠道待补',
      promotion:text(entry.promotion)||'主推表达待补',benefit:text(entry.benefit || entry.benefits)||'实际利益与实现方式待补',
      sales:text(entry.sales)?`${text(entry.sales)}${verified?'':'（用户提供，口径待核对）'}`:'尚未取得可比较的销量数据',
      ranking:text(entry.ranking)?`${text(entry.ranking)}${verified?'':'（用户提供，口径待核对）'}`:'尚未取得明确范围与期间的排名',
      asOf:text(entry.asOf || source.asOf || source.accessedAt),directness,status,verified,
      source:{label:sourceLabel,title:sourceLabel,url,quote:text(entry.quote || source.quote),status},missingFields,
    };
  });
}

function researchPlan(session, context, domain) {
  const provided=session.context?.research?.queries || session.projectContext?.research?.queries || [];
  const target=targetLabel(context,domain), market=context.project.targetMarket || context.company.market || '目标销售市场';
  const fallback=[
    {id:'domestic',market:'domestic',language:'zh',query:`${target} 主推型号 官方 售价 使用者 购买渠道`,focus:'国内同品类、同使用者和目标价带的具体型号，以及实际利益和主推渠道',engines:['国内公开搜索','品牌官网','官方销售渠道']},
    {id:'international',market:'international',language:'en',query:domain==='lure'?'beginner lure fishing rod official product price learning casting':`${target} official product beginner user experience price`,focus:'国际同品类产品与入门设计，保留当地币种、版本和销售地区，不能直接换算为国内销量',engines:['国际公开搜索','品牌官方产品页','行业资料']},
    {id:'adjacent',market:'adjacent',language:'zh/en',query:'beginner onboarding product progressive learning feedback design 新手 渐进适应 操作反馈',focus:'从电动牙刷等产品中研究新手引导、练习和渐进适应的机制；仅借鉴机制，不冒充本品类的市场证据',engines:['品牌官方说明','公开设计资料']},
  ];
  const queries=(provided.length?provided:fallback).map(q=>({...q,status:'检索任务，尚未执行'}));
  const tasks=[
    {name:'确定直接对位的产品款',question:`在${market}，哪几款与「${target}」服务同类使用者，并落在相近价格和销售渠道？`,requiredFields:['品牌与具体型号','目标使用者与经验','产品功能和可感知利益','同渠道实际售价与币种','型号版本与资料日期'],whereToLook:'品牌官网、官方商品页与产品说明；先核对具体型号，再比较宣传语。'},
    {name:'核对4P与主推款',question:'对手卖什么产品、什么价格、在哪里卖、主要怎样解释购买理由？',requiredFields:['Product：功能、结构与实际利益','Price：售价、价带、规格和优惠口径','Place：主销售平台与门店','Promotion：主推表达、演示与用户教育'],whereToLook:'同一时间段的官方产品页和销售渠道；不把搜索排序直接当作主推款排名。'},
    {name:'补齐销量与排名的可比口径',question:'销量和排名出自哪个平台、哪个类目、什么期间，是售出数量、成交额还是评论数量？',requiredFields:['平台及统计期间','指标定义和类目范围','原始来源与访问日期','不能取得时明确留缺'],whereToLook:'可核验的平台数据或有方法说明的行业资料；不能拿评论数推算销量，也不凭品牌知名度编排名。'},
  ];
  return {status:'研究计划待执行',searchPerformed:false,market,queries,tasks,knownReferences:text(session.answers?.['M1-references']),existingObservations:text(session.answers?.['M2-observations']),note:'本次尚未执行横向或国际实时检索；用户提供的链接与文字会作为带来源的资料线索，不自动视为已核验事实。'};
}

function makeJourney(session, context, directions) {
  const a=id=>text(session.answers?.[id]);
  const steps=directions.map(direction=>({stage:direction.name,action:direction.userAction,opportunity:direction.currentBarrierOrOpportunity,source:meaningful(a('U3-journey'))?'根据你描述的使用过程整理':'根据目标体验提出，具体过程需观察',status:'待用样品或观察确认'}));
  return {targetUser:context.project.targetUser || '目标使用者尚未说清',experienceLevel:context.project.experienceLevel || a('U1-user'),desiredExperience:a('U2-goal') || context.project.desiredOutcome,scene:a('U3-journey'),steps,evidence:evidence(session,['U1-user','U2-goal','U3-journey','U4-learning','U5-evidence']),learningPrinciple:'使用者不需要先用过这款新品，也不需要先说出技术方案。可以观察同类活动、首次尝试、选择与学习过程，再由产品团队把目标转成设计，并用样品验证。'};
}

function validationPlan(directions, context, session) {
  const constraints=text(session.answers?.['D3-delivery']);
  const plan=directions.slice(0,2).map((direction,index)=>({priority:index+1,title:`先验证：${direction.name}`,action:direction.validation.action,measure:direction.validation.measure,successCondition:direction.validation.successCondition,decision:'达到目标且没有引入新的明显负担，就保留该机制并进入下一轮；没有改善时回到对应动作修改。',requiredInputs:[context.company.capabilities && `研发与制造条件：${context.company.capabilities}`,context.company.channels && `接触使用者的渠道：${context.company.channels}`,constraints && `现有约束：${constraints}`].filter(Boolean)}));
  plan.push({priority:plan.length+1,title:'确认第一版产品组合与商业边界',action:'用样品表现、同类具体型号资料与目标渠道反馈，确认保留哪些功能、对应哪些使用者、怎样形成可解释的实际利益。',measure:'目标任务完成表现、关键结构的制造与交付条件、目标售价与渠道是否匹配、实际选择或付费反馈。',successCondition:'研发能说明怎么做、使用者能感到差别、目标渠道能说明怎样销售，再确定第一版的规格与投入。',decision:'形成可评审的产品定义与样品任务书，而不是只保留“好玩、沉稳、轻量”等抽象描述。',requiredInputs:[context.project.targetPrice && `目标售价：${context.project.targetPrice}`,context.project.plannedChannels && `计划渠道：${context.project.plannedChannels}`,text(session.answers?.['D4-validation']) && `你提出的验证安排：${text(session.answers['D4-validation'])}`].filter(Boolean)});
  return plan;
}

export function buildDecisionReport(session = {}) {
  const answers=session.answers || {},context=normalizeContext(session),domain=getDomain(context,answers),target=targetLabel(context,domain);
  const directions=(['lure','pole','sea','fishing'].includes(domain)?fishingDirections(context,session,domain):otherDirections(context,session,domain)).map((direction,index)=>({...direction,priority:index+1}));
  const goal=meaningful(answers['D1-outcome'])?brief(answers['D1-outcome'],115):meaningful(answers['U2-goal'])?brief(answers['U2-goal'],115):'完成一次更容易理解、愿意继续的使用体验';
  const cleanGoal=goal.replace(/^(?:第一优先目标|优先目标)[：:]\s*/,'').replace(/[。；\s]+$/,'');
  const first=directions[0];
  const brand=meaningful(context.company.brand)?brief(context.company.brand,90):'本次品牌项目';
  const summary={
    recommendation:`建议为「${target}」优先打样「${first.function}」。第一轮要验证：${cleanGoal}。`,
    rationale:`你把本次新品限定为「${brief(context.project.name,110)}」，并描述了「${brief(answers['U3-journey'] || answers['U4-learning'] || answers['U2-goal'],160) || '仍需观察的首次使用过程'}」。因此先围绕具体动作与结果试做功能机制，再确定参数和利益表达，而不是只改外观或要求新手先提出功能。`,
    assumption:'以下是依据本次问答形成的开发建议与样品假设，不是已经定型的产品，也不是已完成市场验证的量产结论。',
    stage:context.project.stage || '当前研发阶段尚待说明',
    developmentFocus:first.name, desiredOutcome:goal,
    decisionBasis:evidence(session,['N1-scope','U1-user','U2-goal','U3-journey','D1-outcome','B5-capability','B4-channels']),
  };
  const competitors=normalizeCompetitors(session,context),research=researchPlan(session,context,domain),journey=makeJourney(session,context,directions),validation=validationPlan(directions,context,session);
  const companyFacts=[['品牌与市场',context.company.brand,context.company.market],['经营品类',context.company.portfolio],['年销售额',context.company.annualRevenue,context.company.revenuePeriod],['销售渠道与规模',context.company.channels,context.company.channelScale],['技术、研发与制造',context.company.capabilities]].map(([label,...values])=>({label,value:values.filter(Boolean).join('；') || '本次未提供',status:'企业提供，尚未独立核实'}));
  const projectFacts=[['本次新品',context.project.name],['具体品类',context.project.subcategory || context.project.category],['目标使用者',context.project.targetUser],['当前研发阶段',context.project.stage],['目标售价与市场',context.project.targetPrice,context.project.targetMarket],['计划发售渠道',context.project.plannedChannels]].map(([label,...values])=>({label,value:values.filter(Boolean).join('；') || '本次未提供'}));
  const sourceNotes=[
    {label:'企业与项目背景',text:'来自本次问答。财务、渠道与技术口述保留原话，不等同于审计结果或外部认证。',status:'用户提供'},
    {label:'设计建议',text:'由所述使用目标、过程、学习与实现条件形成的样品假设；需要研发和目标使用者共同试验。',status:'设计假设'},
    {label:'市场检索状态',text:research.note,status:'尚未执行实时检索'},
    ...competitors.map(row=>({label:`${row.brand} · ${row.model}`,text:row.source.quote || row.source.title,url:row.source.url,status:row.status})),
  ];
  const scopeComplete=meaningful(answers['N1-scope']) && !/^(?:都有|都做|钓竿|渔具|钓鱼竿)[。！.!\s]*$/.test(text(answers['N1-scope']));
  if(!scopeComplete){summary.recommendation=`先把本次新品收窄到一个明确子品类和使用者，再用下面的方向安排第一次观察与试样。当前「${target}」还不能作为完整产品定义。`;summary.assumption='本次具体产品边界尚未确定；下列是帮助继续推进的开发任务，不代表已选择一个量产产品。';}
  const sections=[
    {id:'recommendation',title:'这次建议开发什么',lead:summary.recommendation,paragraphs:[summary.rationale,summary.assumption],items:[],data:summary},
    {id:'context',title:'企业背景与本次新品',lead:`${brand} · 本次聚焦「${target}」`,paragraphs:[context.companyStage.label,context.companyStage.caveat],items:[...companyFacts,...projectFacts],data:{...context,companyFacts,projectFacts}},
    {id:'competition',title:'竞品、价格带与市场研究',lead:competitors.length?'以下只整理已提供的具体资料；对位关系和数据仍需按来源核实。':'先按本次新品建立具体对标任务；本次没有取得可用于排名或销量结论的市场数据。',paragraphs:[research.note],items:research.tasks,data:{competitors,researchPlan:research,tasks:research.tasks}},
    {id:'userJourney',title:'使用者想获得什么，怎样开始',lead:journey.desiredExperience || '围绕使用目标与过程继续观察，不预设人人都有一个待解决的麻烦。',paragraphs:[journey.learningPrinciple],items:journey.steps,data:journey},
    {id:'design',title:'把体验目标转成产品设计',lead:'以下方向已经指向具体动作、功能机制和实际利益。它们是建议开发方向，不是已定型产品。',paragraphs:[],items:directions,data:directions},
    {id:'validation',title:'下一轮样品怎样做、怎样判断',lead:'先把最优先的机制做成可比较样品，再用实际表现决定保留与修改。',paragraphs:[meaningful(answers['D4-validation'])?`你提出的验证安排：${text(answers['D4-validation'])}`:'先确认研发负责人、目标使用者与可记录的试用任务。'],items:validation,data:validation},
  ];
  return {version:'0.5.0-2026-10-22',generatedAt:new Date().toISOString(),title:`${brand} · ${target}开发建议`,brand,product:target,summary,context,companyFacts,projectFacts,domain,sections,designDirections:directions,competitorComparison:competitors,researchPlan:research,userJourney:journey,validationPlan:validation,sourceNotes,
    decisions:{productDirection:first.name,productStage:'建议开发与样品验证',scopeConfirmed:Boolean(scopeComplete),manufacturingSpecificationFinalized:false,marketStudyCompleted:false},
    evidenceLedger:Object.entries(answers).filter(([,value])=>text(value)).map(([questionId,value])=>({questionId,label:LABELS[questionId] || '本次问答',quote:text(value),status:'本次提供的信息'})),
  };
}
