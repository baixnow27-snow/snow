// Public product-design conversation content. Every scenario is explicitly fictional.
export const ENGINE_VERSION = '0.5.0-2026-10-22';
export const COPY_VERSION = '0.5.0-2026-10-22';

export const QUESTIONS = [
  {
    "id": "B1-brand",
    "round": "B",
    "field": "companyBrandMarket",
    "title": "先介绍一下你的企业或品牌，主要在哪些市场卖？",
    "body": "说说品牌叫什么，主要在国内、哪些地区，或哪些海外市场经营。还在筹备也可以。",
    "example": "比如：我们是溪野（虚构演示品牌），主要做国内休闲钓具。这里介绍企业背景，还没有确定本次新品。",
    "options": [
      "已有品牌，主要在国内销售",
      "已有品牌，同时做国内和海外市场",
      "企业或品牌还在筹备"
    ],
    "target": "说说品牌叫什么，主要在国内、哪些地区，或哪些海外市场经营。还在筹备也可以。",
    "answerKind": "company_statement",
    "domain": "company"
  },
  {
    "id": "B2-portfolio",
    "round": "B",
    "field": "productPortfolio",
    "title": "企业现在做哪些产品品类？",
    "body": "可以列出全部在做的品类。不必现在只选一个；这次具体要做的新品，会接着单独聊。",
    "example": "比如：我们有台钓竿、海钓竿、路亚竿，也卖钓线和钓具周边（虚构演示经营范围）。这次要咨询哪一款，还需要另外说清。",
    "options": [
      "经营一个主要品类",
      "经营几个品类，可以一项项列出来",
      "尚未经营，正在准备第一个品类"
    ],
    "target": "可以列出全部在做的品类。不必现在只选一个；这次具体要做的新品，会接着单独聊。",
    "answerKind": "company_statement",
    "domain": "company"
  },
  {
    "id": "B3-sales",
    "round": "B",
    "field": "annualSales",
    "title": "企业最近一年的销售额大概是多少？",
    "body": "请带上年份，说明是全公司还是某个品类。大概范围就行，也可以说暂时没有或不便透露。",
    "example": "比如：2025自然年全公司约5000万元，都是虚构演示数字；路亚品类没有单独拆分。也可以回答“不便透露，企业目前已稳定经营”。",
    "options": [
      "可以给出年份、统计范围和大概销售额",
      "目前没有销售额，或没有单独统计",
      "不便透露销售额"
    ],
    "target": "请带上年份，说明是全公司还是某个品类。大概范围就行，也可以说暂时没有或不便透露。",
    "answerKind": "company_statement",
    "domain": "company"
  },
  {
    "id": "B4-channels",
    "round": "B",
    "field": "salesChannels",
    "title": "企业现在通过哪些渠道卖？线下大概有多少家店？",
    "body": "线上、线下分别说。门店请区分自营、经销或只是认识的合作方，不要把“认识”当成已能卖这款新品。",
    "example": "比如：有直营网店、2家自营店和40家合作经销门店，门店数均为虚构演示数字；是否愿意卖本次新品，还没确认。",
    "options": [
      "主要在线上销售",
      "线上线下都有，可以分别说门店类型和数量",
      "主要线下，或渠道还在准备"
    ],
    "target": "线上、线下分别说。门店请区分自营、经销或只是认识的合作方，不要把“认识”当成已能卖这款新品。",
    "answerKind": "company_statement",
    "domain": "company"
  },
  {
    "id": "B5-capability",
    "round": "B",
    "field": "capabilityEvidence",
    "title": "企业做过什么、有什么技术或资源，是这次能用上的？",
    "body": "说一个具体的研发、生产或交付经历，以及能找到的记录。现在先记录已有条件，后面再看它能不能支持这款新品。",
    "example": "比如：过去做过复合材料竿体打样，有装配合作方。哪些检测或交付记录能提供，哪些只是我们的判断，分别说明。",
    "options": [
      "有研发、技术或制造经历，可以举具体项目",
      "有供应、门店或使用者联系，可以说具体条件",
      "这些条件尚未具备，或还没有可核对记录"
    ],
    "target": "说一个具体的研发、生产或交付经历，以及能找到的记录。现在先记录已有条件，后面再看它能不能支持这款新品。",
    "answerKind": "company_statement",
    "domain": "company"
  },
  {
    "id": "N1-scope",
    "round": "N",
    "field": "productSubcategory",
    "title": "这次要一起设计的，具体是哪一类新品？",
    "body": "先把本次项目说清，不用把企业所有品类都带进来。可以说产品子品类、给谁用，以及目前暂定的名字。",
    "example": "比如：企业虽然也做台钓、海钓和周边，但这次只设计一款给第一次接触路亚的人用的入门路亚竿。",
    "options": [
      "本次子品类和新品已经明确，可以具体介绍",
      "有几个方向，需要先选定本次讨论哪一个",
      "目前只明确大品类，还需要往下说清子品类"
    ],
    "target": "先把本次项目说清，不用把企业所有品类都带进来。可以说产品子品类、给谁用，以及目前暂定的名字。",
    "answerKind": "project_statement",
    "domain": "project"
  },
  {
    "id": "N2-stage",
    "round": "N",
    "field": "developmentStage",
    "title": "这款新品现在处在哪一步？是从头设计，还是改进已有产品？",
    "body": "只有概念、已有样品、已有参数，或者已有产品想做下一代，都可以。没有样品时就聊设想和已有同类经验。",
    "example": "比如：这款新手路亚竿从0开始，现在还没样品，长度、调性、材料都未确定。也可以回答：已经有样品，想改进初次使用的过程。",
    "options": [
      "从0开始，目前只有概念",
      "已有样品或部分参数，还在试",
      "已有产品，准备改进或做下一代"
    ],
    "target": "只有概念、已有样品、已有参数，或者已有产品想做下一代，都可以。没有样品时就聊设想和已有同类经验。",
    "answerKind": "project_statement",
    "domain": "project"
  },
  {
    "id": "N3-commercial",
    "round": "N",
    "field": "commercialIntent",
    "title": "这款新品想卖给哪个市场、卖多少钱、先从哪里发售？",
    "body": "想好了哪部分就说哪部分。价格、地区和渠道都是当前计划，尚未决定的可以留着，不要求此刻拍板。",
    "example": "比如：初步面向国内新手，设想零售价299—399元，考虑直营网店和愿意参与的门店。这是演示目标价与渠道设想，不是调研结论。",
    "options": [
      "目标市场、价格和渠道已有初步想法",
      "只想好其中一部分，可以先说已知的",
      "这些还没定，需要结合后面的资料再判断"
    ],
    "target": "想好了哪部分就说哪部分。价格、地区和渠道都是当前计划，尚未决定的可以留着，不要求此刻拍板。",
    "answerKind": "project_statement",
    "domain": "project"
  },
  {
    "id": "M1-references",
    "round": "M",
    "field": "marketReferences",
    "title": "你已经看过哪些相近产品，手里有什么资料？",
    "body": "具体品牌、型号、链接、截图、价格记录、门店反馈都可以。没有资料也可以直接说，后面会列出要查什么。",
    "example": "比如：知道市场上有入门路亚竿，但还没整理具体型号和链接。可以先记“待查”，不凭印象编出排名或销量。",
    "options": [
      "有具体品牌、型号、链接或资料，可以贴出来",
      "知道一些产品，但资料还没整理",
      "还没查过相近产品"
    ],
    "target": "具体品牌、型号、链接、截图、价格记录、门店反馈都可以。没有资料也可以直接说，后面会列出要查什么。",
    "answerKind": "competitor_material",
    "domain": "research"
  },
  {
    "id": "M2-observations",
    "round": "M",
    "field": "competitorObservations",
    "title": "这些相近产品卖多少钱、主要讲什么、在哪里卖？",
    "body": "也可以说看到哪款在主推。先讲你知道的一点，并带上资料出处和查看时间；不知道的不用猜。",
    "example": "比如：某款的页面标价、页面强调的用途和售卖门店，可以分别摘录。只看到一条链接，仍不能证明它销量领先；销量、排名都要核实来源、时间和口径。",
    "options": [
      "有一两条具体观察，可以注明出处和时间",
      "只有品牌方或门店口述，还没有独立核实",
      "这些信息暂时不知道，列为待查"
    ],
    "target": "也可以说看到哪款在主推。先讲你知道的一点，并带上资料出处和查看时间；不知道的不用猜。",
    "answerKind": "competitor_material",
    "domain": "research"
  },
  {
    "id": "U1-user",
    "round": "U",
    "field": "userExperience",
    "title": "这款新品主要给什么人用？他对这项活动熟悉到什么程度？",
    "body": "可以是第一次尝试、刚入门、熟练使用者或专业人士。说一个具体的人，以及他现在已经会做哪些事。",
    "example": "比如：一位会钓台钓、第一次想尝试路亚的成年人。不能因为他会台钓，就当作他已经会抛投、收线和判断路亚状态。",
    "options": [
      "第一次接触或刚入门，需要学习",
      "已有一些同类经验，想继续练习",
      "熟练或专业使用者，追求更细的表现"
    ],
    "target": "可以是第一次尝试、刚入门、熟练使用者或专业人士。说一个具体的人，以及他现在已经会做哪些事。",
    "answerKind": "user_activity",
    "domain": "consumer"
  },
  {
    "id": "U2-goal",
    "round": "U",
    "field": "userGoal",
    "title": "这个人为什么想参与这件事？希望得到什么？",
    "body": "可以是完成一件事，也可以是兴趣、学会技能、和朋友一起玩、表达自己或尝试新体验。没有明显麻烦，也能如实说。",
    "example": "比如：新手想体验路亚的抛投和收线过程，看到自己慢慢学会，也想和朋友周末去水边。这是要进一步了解的目标，不要求他先说出鱼竿参数。",
    "options": [
      "主要想完成一个具体任务",
      "主要出于兴趣、学习技能或新体验",
      "主要想和别人一起参与或表达自己",
      "几种原因都有，或还需要问本人"
    ],
    "target": "可以是完成一件事，也可以是兴趣、学会技能、和朋友一起玩、表达自己或尝试新体验。没有明显麻烦，也能如实说。",
    "answerKind": "user_activity",
    "domain": "consumer"
  },
  {
    "id": "U3-journey",
    "round": "U",
    "field": "currentJourney",
    "title": "从准备开始到结束，这个人参与这件事通常会经历哪些步骤？",
    "body": "新品还没上市，就讲他现在用同类产品的过程，或第一次尝试时预计会经历的步骤；把观察过的和设想的分开。",
    "example": "比如：了解装备、装配、到水边练习抛投、让饵运动、收线、整理装备。哪些是观察新手看到的，哪些只是我们推想，分别记录。",
    "options": [
      "观察过同类活动，可以按开始到结束讲",
      "只有部分同类经验，可以先讲知道的步骤",
      "还没观察过，先把预计过程标成设想"
    ],
    "target": "新品还没上市，就讲他现在用同类产品的过程，或第一次尝试时预计会经历的步骤；把观察过的和设想的分开。",
    "answerKind": "user_activity",
    "domain": "consumer"
  },
  {
    "id": "U4-learning",
    "round": "U",
    "field": "learningExperience",
    "title": "对这个人来说，哪些步骤需要学习、适应或得到反馈？",
    "body": "如果是新手，说第一次尝试时哪里需要引导；如果已经熟练，说哪个关键体验最值得改进。说行为和感受就行，不要求他来设计技术方案。",
    "example": "比如：新手可能要学装配、怎么抛投、如何收线，以及怎样判断当前状态。能不能独立完成、在哪一步求助，要观察；不能直接假定他知道该选什么调性或材料。",
    "options": [
      "新手，需要学习或引导，先具体说哪一步",
      "已有经验，主要想改善某个关键体验",
      "还不知道，需要观察一次真实尝试"
    ],
    "target": "如果是新手，说第一次尝试时哪里需要引导；如果已经熟练，说哪个关键体验最值得改进。说行为和感受就行，不要求他来设计技术方案。",
    "answerKind": "user_activity",
    "domain": "consumer"
  },
  {
    "id": "U5-evidence",
    "round": "U",
    "field": "researchEvidence",
    "title": "刚才这些想法，哪些来自真实观察，哪些还是我们的设想？",
    "body": "分清见过、访谈听到、同类产品经验和团队设想。没有问过用户时也可以继续设计，只需把待验证的部分标出来。",
    "example": "比如：“他抛投时会求助”可以来自一次观察；“用更软的竿会更容易学”是我们的设计假设，不能写成新手亲口提出的需求。",
    "options": [
      "有观察、访谈或试用记录，可以说时间和原话",
      "来自同类产品经验，尚未验证到本次人群",
      "主要是团队设想，需要安排首轮验证"
    ],
    "target": "分清见过、访谈听到、同类产品经验和团队设想。没有问过用户时也可以继续设计，只需把待验证的部分标出来。",
    "answerKind": "evidence_source",
    "domain": "consumer"
  },
  {
    "id": "D1-outcome",
    "round": "D",
    "field": "priorityOutcome",
    "title": "这款新品最先想让用户在哪一步做得更顺、或获得更好的体验？",
    "body": "先选一件具体的事，说明它对这个人有什么用。可以是容易学、容易完成、能得到反馈，也可以是活动乐趣或新的体验。",
    "example": "比如：先让第一次接触路亚的人更容易完成一次有控制的抛投，并知道下一次该调整什么。不是先要求新手说出颜色、重量或材料方案。",
    "options": [
      "优先让第一次学习和完成某一步更顺",
      "优先改善熟练使用时的一项具体体验",
      "优先增加活动乐趣、互动或新体验",
      "还需要结合前面的过程选定重点"
    ],
    "target": "先选一件具体的事，说明它对这个人有什么用。可以是容易学、容易完成、能得到反馈，也可以是活动乐趣或新的体验。",
    "answerKind": "design_goal",
    "domain": "design"
  },
  {
    "id": "D2-ideas",
    "round": "D",
    "field": "designIdeas",
    "title": "围绕这件事，你们已经想到哪些功能、结构或使用引导？",
    "body": "企业可以提出设计设想，消费者不需要替研发写参数。暂时没有方案，也可以先把想达到的结果说清。",
    "example": "比如：团队设想提供初次装配和抛投步骤引导、清晰的握持或操作提示，或试验不同的反馈方式；这些都要做样品比较，还不是已证明更好的方案。",
    "options": [
      "已有功能、结构或交互设想，可以说它帮助哪一步",
      "有几个备选想法，希望通过样品比较",
      "暂时没有方案，先明确要达到的体验"
    ],
    "target": "企业可以提出设计设想，消费者不需要替研发写参数。暂时没有方案，也可以先把想达到的结果说清。",
    "answerKind": "design_hypothesis",
    "domain": "design"
  },
  {
    "id": "D3-delivery",
    "round": "D",
    "field": "deliveryConstraints",
    "title": "这些设想，哪些现在能做，哪些要试验，还有哪些成本或交付限制？",
    "body": "把已有能力、需要验证的技术、成本范围和时间条件分开。企业有工厂，不等于每个设计设想都已经能量产。",
    "example": "比如：说明书和操作提示可以先试做；竿体反馈、耐用性和量产一致性需要打样、检测；零售价设想还要倒推可接受的成本。这里先列限制，不编造检测结果。",
    "options": [
      "已有能力可做一部分，可以列具体证据",
      "有些需要打样、检测或供应方确认",
      "成本、时间或交付条件还不明确"
    ],
    "target": "把已有能力、需要验证的技术、成本范围和时间条件分开。企业有工厂，不等于每个设计设想都已经能量产。",
    "answerKind": "delivery_assessment",
    "domain": "design"
  },
  {
    "id": "D4-validation",
    "round": "D",
    "field": "sampleValidation",
    "title": "第一轮样品，准备让谁怎样试，才能看出这项设计有没有帮助？",
    "body": "说可联系的人、场地或门店，安排一个能观察的任务。记录完成到哪一步、哪里求助、出现什么错误，以及本人的原话。",
    "example": "比如：邀请第一次接触路亚的成年人，在适合的练习场地完成装配、抛投和收线，比较不同引导方式。观察能否独立完成和哪步需要帮助，不只问喜欢吗，也不只看有没有钓到鱼。",
    "options": [
      "能安排目标使用者、场地和首轮任务",
      "有一部分试用资源，需要补齐",
      "暂时还没有资源，先明确首轮要验证什么"
    ],
    "target": "说可联系的人、场地或门店，安排一个能观察的任务。记录完成到哪一步、哪里求助、出现什么错误，以及本人的原话。",
    "answerKind": "validation_plan",
    "domain": "design"
  }
];

export const ROUNDS = [
  {
    "id": "B",
    "label": "企业与经营背景",
    "questionIds": [
      "B1-brand",
      "B2-portfolio",
      "B3-sales",
      "B4-channels",
      "B5-capability"
    ]
  },
  {
    "id": "N",
    "label": "本次具体新品",
    "questionIds": [
      "N1-scope",
      "N2-stage",
      "N3-commercial"
    ]
  },
  {
    "id": "M",
    "label": "相近产品与市场资料",
    "questionIds": [
      "M1-references",
      "M2-observations"
    ]
  },
  {
    "id": "U",
    "label": "使用者与活动过程",
    "questionIds": [
      "U1-user",
      "U2-goal",
      "U3-journey",
      "U4-learning",
      "U5-evidence"
    ]
  },
  {
    "id": "D",
    "label": "设计方向与样品验证",
    "questionIds": [
      "D1-outcome",
      "D2-ideas",
      "D3-delivery",
      "D4-validation"
    ]
  }
];

export const SCENARIOS = [
  {
    "id": "fishing",
    "label": "新手路亚竿 · 从企业到设计",
    "title": "溪野 · 新手路亚竿",
    "description": "围绕新手学习过程，形成可打样、可验证的产品方向。",
    "opening": "这次只设计一款新手入门路亚竿，给第一次接触路亚的成年人用；不包含台钓竿、海钓竿或全部周边。",
    "productSubcategory": "新手入门路亚竿",
    "categoryId": "outdoor",
    "answers": {
      "B1-brand": "我们是溪野（虚构演示品牌），主要服务国内休闲钓鱼人。企业名称和以下经营背景均为虚构演示设定。",
      "B2-portfolio": "经营台钓竿、海钓竿、路亚竿，以及钓线和钓具周边（均为演示设定）。这些是企业整体品类，不代表这次要一起设计全部产品。",
      "B3-sales": "2025自然年全公司销售额约5000万元（虚构演示数字，不是真实销量或市场规模）；路亚品类没有单独拆分。",
      "B4-channels": "有直营网店、2家自营门店和40家合作经销门店，门店数量均为虚构演示数字。合作门店是否愿意参与本次新品测试和试销，尚未确认。",
      "B5-capability": "演示设定：团队有复合材料竿体开发、装配和供应合作经验。可以尝试调取既往打样、检测和交付记录，但本演示没有附上实际文件，不能当作已核实的技术结论。",
      "N1-scope": "这次只设计一款新手入门路亚竿，给第一次接触路亚的成年人用；不包含台钓竿、海钓竿或全部周边。",
      "N2-stage": "从0定义一款新品，目前只有概念，没有样品；长度、调性、材料和引导方式都未确定。",
      "N3-commercial": "初步考虑国内市场，零售价299—399元（虚构演示目标价），拟从直营网店和愿意参与试用的门店开始。目标价和渠道都是待验证计划。",
      "M1-references": "知道市面上有入门路亚竿，但当前未整理具体品牌款式、链接和同口径资料。首轮要补与新手路亚竿直接对应的产品，不能拿台钓或海钓竿混比。",
      "M2-observations": "目前没有可核实的价格页面、主推款、排名或销量资料。需要记录具体款式、查看日期、标价与实际成交口径、页面利益说明和售卖渠道；本演示没有执行搜索。",
      "U1-user": "一位周末想第一次尝试路亚的成年人，过去陪朋友去过水边，但不会独立装配、抛投和收线。会不会其他钓法，还需要问本人。",
      "U2-goal": "设想他想体验抛投和收线的过程，逐步学会一项新技能，也可能想和朋友一起玩。我们不把钓到鱼或解决麻烦当成唯一目标。",
      "U3-journey": "目前先列预计过程：了解装备、装配、找到适合练习的位置、练习抛投、操作和收线、判断状态、整理装备。这是同类活动的流程设想，不是有人用过这款未上市新品的记录。",
      "U4-learning": "需要了解新手如何学装配与抛投，怎样知道当前操作是否合适、何时需要帮助。我们没有要求他先说出竿体调性、材料或具体结构方案。",
      "U5-evidence": "用户目标和新手过程目前主要是团队设想，参考过同类活动经验；本演示没有真实访谈、观察或样品试用记录。接下来应按目标人群补齐证据。",
      "D1-outcome": "第一优先目标：让第一次接触路亚的人更容易独立完成一次有控制的抛投，并能理解下一次如何调整。希望让入门更顺、愿意继续练习，实际效果待试。",
      "D2-ideas": "设计假设：比较简明的首次装配与抛投步骤引导、明确的握持或操作提示，以及不同的操作反馈方式。具体竿体参数由研发提出并打样，不让新手替研发定技术规格。",
      "D3-delivery": "演示设定：团队可先做引导材料和基础样品；竿体操作反馈、耐用性、加工一致性及与目标售价匹配的成本需要试验和核实。没有现成量产结论。",
      "D4-validation": "首轮计划联系第一次接触路亚的成年人，在合适练习场地完成装配、抛投与收线。记录独立完成情况、求助的步骤与次数、操作错误和原话，比较不同引导方案；招募人数、场地和安全安排仍需落实。"
    },
    "evidenceStatus": "虚构演示品牌与经营设定；用户与设计内容均待验证"
  },
  {
    "id": "idea",
    "label": "人参饮料 · 从想法开始",
    "title": "参野 · 小瓶人参饮料",
    "description": "从企业条件到第一次选择和饮用，梳理设计目标。",
    "opening": "本次只设计面向成年上班族的小瓶即饮人参饮料，即用人参作原料、打开就能喝的饮料，不讨论全部人参原料业务。",
    "productSubcategory": "小瓶即饮人参饮料",
    "categoryId": "food",
    "answers": {
      "B1-brand": "我们暂用参野（虚构演示品牌），拟面向国内成年饮品购买者。品牌和以下企业情况都只是演示设定。",
      "B2-portfolio": "演示设定：企业经营人参原料和饮品加工，也考虑便携饮品；本次先讨论一款小瓶即饮人参饮料。",
      "B3-sales": "不便提供销售额。演示只记录企业处于有加工经验、拟做自有产品的阶段，不编造真实经营数字。",
      "B4-channels": "演示设定：目前通过品牌客户出货，认识一些线下门店，但自营门店数量和可售新品门店数尚未确认。合作关系不等于已确定发售渠道。",
      "B5-capability": "演示设定：有人参原料合作方、饮料加工和小批量打样经验。实际原料追溯、检测与交付记录尚未提供。",
      "N1-scope": "本次只设计面向成年上班族的小瓶即饮人参饮料，即用人参作原料、打开就能喝的饮料，不讨论全部人参原料业务。",
      "N2-stage": "目前概念阶段，从0定义产品，还没有样品。口味、配料、容量和使用引导都未定，也未验证实际饮用效果。",
      "N3-commercial": "初步面向国内成年上班族，设想每瓶15—20元（虚构演示目标价），考虑愿意参与试用的办公空间或门店；尚未确定发售计划。",
      "M1-references": "知道咖啡、能量饮料和其他人参饮品可能进入同一次饮品选择，但当前没有具体款式、链接和已核实资料。要区分同类产品对标和跨品类替代选择。",
      "M2-observations": "目前没有可靠价格记录、销量、排名或主推款资料，需要逐款核对查看日期、规格、价格、页面用途表达和售卖渠道；本演示未执行搜索。",
      "U1-user": "设想是一位下午经常开会、会自己购买饮品的成年上班族。他对人参饮料可能不熟悉，应先介绍是什么，不默认有使用经验。",
      "U2-goal": "设想他希望下午工作前有一个喜欢的饮品选择，也可能想尝试新口味。是否为了提神或补充精力，需要向本人了解，并核实产品实际作用。",
      "U3-journey": "先列同类饮品选择过程：想到要喝点东西、看货架或平台、读介绍、选择、开瓶饮用、收拾、决定是否再次购买；不是用过这款新品的记录。",
      "U4-learning": "第一次接触人参饮料时，可能需要知道它是什么、怎么喝、口味如何、瓶身信息是否容易看懂。哪些真影响选择和使用，还需要观察。",
      "U5-evidence": "当前主要是团队设想和同类饮品经验，没有真实消费者观察、访谈和本新品试用证据。产品作用和购买理由都未证实。",
      "D1-outcome": "先让第一次接触的人容易看懂这是什么饮料，并顺利完成选择、开瓶和饮用过程，形成明确的口味与使用感受。是否帮助补充精力需另行验证。",
      "D2-ideas": "设计假设：比较简洁的原料与饮用说明、容易识别的瓶身信息、不同开瓶与携带方式，以及可接受的口味方案。不是要求消费者先提出配方或包装技术规格。",
      "D3-delivery": "演示设定：可做小批量饮料样品；口味、稳定性、保质条件、包装与成本要分别试验核实，没有已经可量产的结论。",
      "D4-validation": "首轮计划邀请对这类饮料不熟悉的成年人，在不提示的情况下看介绍、说明自己理解的产品用途、开瓶和试饮。记录看不懂的地方、求助、操作与口味原话，再比较样品；不以口头说喜欢替代真实选择。"
    },
    "evidenceStatus": "虚构演示品牌；用户与设计内容均待验证"
  },
  {
    "id": "product",
    "label": "人参饮料 · 已有样品再优化",
    "title": "参野 · 人参饮料样品优化",
    "description": "已有样品不等于用户已经掌握用法，比较具体使用过程。",
    "opening": "本次只设计面向成年上班族的小瓶即饮人参饮料，即用人参作原料、打开就能喝的饮料，不讨论全部人参原料业务。",
    "productSubcategory": "小瓶即饮人参饮料",
    "categoryId": "food",
    "answers": {
      "B1-brand": "我们暂用参野（虚构演示品牌），拟面向国内成年饮品购买者。品牌和以下企业情况都只是演示设定。",
      "B2-portfolio": "演示设定：企业经营人参原料和饮品加工，也考虑便携饮品；本次先讨论一款小瓶即饮人参饮料。",
      "B3-sales": "不便提供销售额。演示只记录企业处于有加工经验、拟做自有产品的阶段，不编造真实经营数字。",
      "B4-channels": "演示设定：目前通过品牌客户出货，认识一些线下门店，但自营门店数量和可售新品门店数尚未确认。合作关系不等于已确定发售渠道。",
      "B5-capability": "演示设定：有人参原料合作方、饮料加工和小批量打样经验。实际原料追溯、检测与交付记录尚未提供。",
      "N1-scope": "本次只设计面向成年上班族的小瓶即饮人参饮料，即用人参作原料、打开就能喝的饮料，不讨论全部人参原料业务。",
      "N2-stage": "已有小批量样品，准备改进口味、瓶身信息与开瓶体验。样品状态是演示设定，没有真实试用记录；目标购买者不一定已喝过。",
      "N3-commercial": "初步面向国内成年上班族，设想每瓶15—20元（虚构演示目标价），考虑愿意参与试用的办公空间或门店；尚未确定发售计划。",
      "M1-references": "知道咖啡、能量饮料和其他人参饮品可能进入同一次饮品选择，但当前没有具体款式、链接和已核实资料。要区分同类产品对标和跨品类替代选择。",
      "M2-observations": "目前没有可靠价格记录、销量、排名或主推款资料，需要逐款核对查看日期、规格、价格、页面用途表达和售卖渠道；本演示未执行搜索。",
      "U1-user": "设想是一位下午经常开会、会自己购买饮品的成年上班族。他对人参饮料可能不熟悉，应先介绍是什么，不默认有使用经验。",
      "U2-goal": "设想他希望下午工作前有一个喜欢的饮品选择，也可能想尝试新口味。是否为了提神或补充精力，需要向本人了解，并核实产品实际作用。",
      "U3-journey": "先列同类饮品选择过程：想到要喝点东西、看货架或平台、读介绍、选择、开瓶饮用、收拾、决定是否再次购买；不是用过这款新品的记录。",
      "U4-learning": "第一次接触人参饮料时，可能需要知道它是什么、怎么喝、口味如何、瓶身信息是否容易看懂。哪些真影响选择和使用，还需要观察。",
      "U5-evidence": "当前主要是团队设想和同类饮品经验，没有真实消费者观察、访谈和本新品试用证据。产品作用和购买理由都未证实。",
      "D1-outcome": "先让第一次接触的人容易看懂这是什么饮料，并顺利完成选择、开瓶和饮用过程，形成明确的口味与使用感受。是否帮助补充精力需另行验证。",
      "D2-ideas": "设计假设：比较简洁的原料与饮用说明、容易识别的瓶身信息、不同开瓶与携带方式，以及可接受的口味方案。不是要求消费者先提出配方或包装技术规格。",
      "D3-delivery": "演示设定：已有基础配方和样品加工条件；新的口味、包装、稳定性和成本仍需打样检测，不能由现有样品推断可量产。",
      "D4-validation": "首轮计划邀请对这类饮料不熟悉的成年人，在不提示的情况下看介绍、说明自己理解的产品用途、开瓶和试饮。记录看不懂的地方、求助、操作与口味原话，再比较样品；不以口头说喜欢替代真实选择。"
    },
    "evidenceStatus": "虚构演示品牌及样品状态；用户与设计内容均待验证"
  },
  {
    "id": "brand",
    "label": "人参饮料 · 从加工到自有产品",
    "title": "参野 · 从加工到自有饮料",
    "description": "把既有原料和加工条件与本次具体新品分开。",
    "opening": "本次只设计面向成年上班族的小瓶即饮人参饮料，即用人参作原料、打开就能喝的饮料，不讨论全部人参原料业务。",
    "productSubcategory": "小瓶即饮人参饮料",
    "categoryId": "food",
    "answers": {
      "B1-brand": "我们过去做原料和饮料加工，拟用参野（虚构演示品牌）尝试自有产品，主要考虑国内市场。企业和品牌均为演示设定。",
      "B2-portfolio": "演示设定：企业经营人参原料和饮品加工，也考虑便携饮品；本次先讨论一款小瓶即饮人参饮料。",
      "B3-sales": "不便提供销售额。演示只记录企业处于有加工经验、拟做自有产品的阶段，不编造真实经营数字。",
      "B4-channels": "演示设定：目前通过品牌客户出货，认识一些线下门店，但自营门店数量和可售新品门店数尚未确认。合作关系不等于已确定发售渠道。",
      "B5-capability": "演示设定：有人参原料合作方、饮料加工和小批量打样经验。实际原料追溯、检测与交付记录尚未提供。",
      "N1-scope": "本次只设计面向成年上班族的小瓶即饮人参饮料，即用人参作原料、打开就能喝的饮料，不讨论全部人参原料业务。",
      "N2-stage": "从加工业务出发定义自有产品，目前没有确定样品和参数，不把加工客户的要求直接当成消费者需要。",
      "N3-commercial": "初步面向国内成年上班族，设想每瓶15—20元（虚构演示目标价），考虑愿意参与试用的办公空间或门店；尚未确定发售计划。",
      "M1-references": "知道咖啡、能量饮料和其他人参饮品可能进入同一次饮品选择，但当前没有具体款式、链接和已核实资料。要区分同类产品对标和跨品类替代选择。",
      "M2-observations": "目前没有可靠价格记录、销量、排名或主推款资料，需要逐款核对查看日期、规格、价格、页面用途表达和售卖渠道；本演示未执行搜索。",
      "U1-user": "设想是一位下午经常开会、会自己购买饮品的成年上班族。他对人参饮料可能不熟悉，应先介绍是什么，不默认有使用经验。",
      "U2-goal": "设想他希望下午工作前有一个喜欢的饮品选择，也可能想尝试新口味。是否为了提神或补充精力，需要向本人了解，并核实产品实际作用。",
      "U3-journey": "先列同类饮品选择过程：想到要喝点东西、看货架或平台、读介绍、选择、开瓶饮用、收拾、决定是否再次购买；不是用过这款新品的记录。",
      "U4-learning": "第一次接触人参饮料时，可能需要知道它是什么、怎么喝、口味如何、瓶身信息是否容易看懂。哪些真影响选择和使用，还需要观察。",
      "U5-evidence": "当前主要是团队设想和同类饮品经验，没有真实消费者观察、访谈和本新品试用证据。产品作用和购买理由都未证实。",
      "D1-outcome": "先让第一次接触的人容易看懂这是什么饮料，并顺利完成选择、开瓶和饮用过程，形成明确的口味与使用感受。是否帮助补充精力需另行验证。",
      "D2-ideas": "设计假设：比较简洁的原料与饮用说明、容易识别的瓶身信息、不同开瓶与携带方式，以及可接受的口味方案。不是要求消费者先提出配方或包装技术规格。",
      "D3-delivery": "演示设定：可做小批量饮料样品；口味、稳定性、保质条件、包装与成本要分别试验核实，没有已经可量产的结论。",
      "D4-validation": "首轮计划邀请对这类饮料不熟悉的成年人，在不提示的情况下看介绍、说明自己理解的产品用途、开瓶和试饮。记录看不懂的地方、求助、操作与口味原话，再比较样品；不以口头说喜欢替代真实选择。"
    },
    "evidenceStatus": "虚构演示品牌与经营设定；用户与设计内容均待验证"
  }
];

export const QUESTION_FIELD_MAP = Object.fromEntries(QUESTIONS.map(q => [q.id, q.field]));
export const FIELD_MAP = QUESTION_FIELD_MAP;
export function getQuestion(id) { return QUESTIONS.find(question => question.id === id); }
export function getSampleAnswer(scenarioId = 'fishing', questionId) {
  return (SCENARIOS.find(scenario => scenario.id === scenarioId) || SCENARIOS[0]).answers[questionId] || '';
}
export function getSampleAnswers(scenarioId = 'fishing', questionIds = QUESTIONS.map(question => question.id)) {
  return Object.fromEntries(questionIds.map(id => [id, getSampleAnswer(scenarioId, id)]));
}

const CATEGORY_CHOICES = [
  { id: 'outdoor', label: '户外、运动与钓具' },
  { id: 'food', label: '食品与饮料' },
  { id: 'personal-care', label: '日常洗护' },
  { id: 'home', label: '家居与日用品' },
  { id: 'digital', label: '数码与配件' },
  { id: 'general', label: '先用熟悉的日常产品' },
];
export function getCategoryChoices() { return CATEGORY_CHOICES.map(choice => ({ ...choice })); }

function projectScope(session = {}) {
  const project=session.projectContext?.project || session.context?.project;
  if(project?.subcategory)return [project.subcategory,project.targetUser].filter(Boolean).join(' ');
  return String(session.answers?.['N1-scope'] || session.productSubcategory || session.project?.productSubcategory || '').replace(/(?:不做|不包含|不讨论|不是)[^，。；\n]{0,20}/g,'').trim();
}
function productPhrase(session = {}) {
  const scope = projectScope(session);
  if (!scope) return '本次待确定的新品';
  const phrases = [
    ['新手入门路亚竿', /(?:新手|入门|第一次)[^。；\n]{0,20}路亚(?:鱼)?[竿杆]|路亚[^。；\n]{0,12}(?:新手|入门)/],
    ['路亚竿', /路亚(?:鱼)?[竿杆]|(?:只|本次|这次)[^。；\n]{0,8}路亚/],
    ['台钓竿', /台钓(?:鱼)?[竿杆]|(?:只|本次|这次)[^。；\n]{0,8}台钓/],
    ['海钓竿', /海钓(?:鱼)?[竿杆]|(?:只|本次|这次)[^。；\n]{0,8}海钓/],
    ['小瓶即饮人参饮料', /人参|红参/],
    ['露营帐篷', /露营[^。；\n]{0,8}帐篷|帐篷/],
    ['徒步鞋', /徒步鞋|登山鞋/],
    ['户外电水壶', /户外[^。；\n]{0,8}(?:电水壶|烧水壶)/],
    ['电水壶', /电水壶|烧水壶/],
    ['洗发水', /洗发水/],
    ['电动牙刷', /电动牙刷/],
    ['防晒产品', /防晒/],
    ['充电宝', /充电宝|移动电源/],
    ['耳机', /耳机/],
    ['保温杯', /保温杯/],
    ['雨伞', /雨伞/],
    ['酸奶', /酸奶/],
    ['即饮饮料', /饮料|饮品/],
  ];
  const match = phrases.find(([, pattern]) => pattern.test(scope));
  if (match) return match[0];
  // A broad category is useful company context, but cannot name the project.
  if (/^(?:都有|都做|全部|钓具|钓竿|鱼竿|周边|户外产品|功能性产品)[。！.!\s]*$/.test(scope)) return '本次待确定的新品';
  return scope.length <= 32 && !/[。；\n]/.test(scope) ? scope : '本次讨论的新品';
}

export function inferCategory(session = {}) {
  const selectedId = typeof session.guidanceCategory === 'string' ? session.guidanceCategory : session.guidanceCategory?.id;
  const selected = CATEGORY_CHOICES.find(choice => choice.id === selectedId);
  const scope = projectScope(session);
  const context = scope || [session.answers?.['B1-brand'], session.answers?.['B2-portfolio']].filter(Boolean).join('\n');
  const classifiers = [
    ['outdoor', /钓[具竿杆鱼]|鱼竿|渔[具竿杆]|路亚|台钓|海钓|帐篷|徒步鞋|登山鞋|冲锋衣|攀岩|骑行|滑雪/],
    ['food', /食品|酸奶|牛奶|饮料|饮品|咖啡|人参|红参|零食|饼干|果汁|代餐/],
    ['personal-care', /牙刷|洗发|护发|防晒|洗面|护肤|沐浴|牙膏/],
    ['digital', /充电宝|移动电源|耳机|数码|充电器|手机壳|数据线|键盘|鼠标/],
    ['home', /电水壶|烧水壶|保温杯|雨伞|锅具|收纳|台灯|床品|枕头|家具|清洁用品/],
    ['outdoor', /户外|露营|运动|野营/],
  ];
  const detected = classifiers.find(([, pattern]) => pattern.test(context));
  const category = selected || CATEGORY_CHOICES.find(choice => choice.id === (detected?.[0] || 'general'));
  const experience = String(session.answers?.['U1-user'] || scope);
  const experienceLevel = /新手|初次|第一次|零基础|刚入门/.test(experience) ? 'beginner' : /熟练|专业|老手|资深/.test(experience) ? 'experienced' : 'unknown';
  return {
    ...category, confidence: selected ? 1 : detected ? 0.85 : 0,
    reason: selected ? '你选择的相近案例' : scope ? '依据本次新品选择相近案例' : detected ? '先依据企业品类选例子，本次新品仍需单独确认' : '品类尚未明确，先用熟悉的日常产品',
    productSubcategory: productPhrase(session), experienceLevel,
    scopeConfirmed: Boolean(scope && productPhrase(session) !== '本次待确定的新品'),
  };
}

const GENERAL_EXAMPLES = {
  'B1-brand': '比如：我们是伞行（虚构演示品牌），主要在国内经营日常出行用品。先介绍企业，不急着断定这次新品是什么。',
  'B2-portfolio': '比如：企业经营雨伞、雨衣和通勤包（虚构演示经营范围）；本次咨询还要另外选定具体哪一款新品。',
  'B3-sales': '比如：可以说“2025年全公司大概在某个销售额范围”，也可以说“不便透露”。年份、全公司还是单品类需要分清，例子不提供真实企业数字。',
  'B4-channels': '比如：说清直营网店、自己开的店、合作经销店分别有哪些；知道多少家就说多少家，不知道不要补数字。',
  'B5-capability': '比如：做过雨伞打样，认识加工合作方，有某次交付或检测记录。认识工厂和已有证据可以分别写。',
  'N1-scope': '比如：企业也做雨衣和包，但本次只讨论给地铁通勤者用的一款折叠雨伞，不把全部业务混在一起。',
  'N2-stage': '比如：目前从0开始，没有样品；也可以是已有一把伞，想改进收伞过程。两种起点都可以。',
  'N3-commercial': '比如：先明确面向国内通勤者，目标价还没定，考虑从现有网店发售。没想好的部分可以保留。',
  'M1-references': '比如：整理两三款面向相近人的折叠伞，附上具体款式或链接。还没查过，就把资料缺口列出来。',
  'M2-observations': '比如：把“这款页面标价多少、强调什么用途、在哪些地方卖、哪里看到、哪天查看”分别记下。页面存在不能证明它销量领先。',
  'U1-user': '比如：一位每天乘地铁的设计师，自己买过几把折叠伞；他熟悉日常用伞，但还没用过你这款未上市新品。',
  'U2-goal': '比如：她希望雨天出行方便，也可能喜欢一把表达自己风格的伞；功能和审美都可以是目标，不必硬找一个严重麻烦。',
  'U3-journey': '比如：看天气、选伞出门、撑开、进站时收伞、携带、回家晾干。讲她当前用伞的过程，并标出哪些亲眼见过。',
  'U4-learning': '比如：熟悉普通伞的人也可能要适应新的开合方式。可以观察她是否一看就会、是否需要说明，不要求她设计伞的结构。',
  'U5-evidence': '比如：“她在进站时会腾手收伞”来自观察；“换一种开合结构会更顺”是团队设计假设。两种信息分别记录。',
  'D1-outcome': '比如：优先让她进地铁时能顺畅完成收伞和携带。先说明对使用者有何帮助，再考虑设计。',
  'D2-ideas': '比如：团队提出开合操作提示、握持方式或收纳结构的备选想法。说明各自帮助哪一步，再用样品比较。',
  'D3-delivery': '比如：现有合作方能先做基础样品，但新结构的耐用性、量产一致性和成本尚需验证。',
  'D4-validation': '比如：让通勤者带着包完成撑伞、收伞和携带任务，记录能否独立完成、哪里求助、操作错误及原话，再比较样品。',
};
const EXPLANATIONS = {
  'B1-brand': '先了解企业叫什么、目前主要在哪些市场经营。本次要设计什么，后面单独确认。',
  'B2-portfolio': '先列企业现在经营的全部品类。说“都有”时，也把包含哪些具体种类补充出来。',
  'B3-sales': '大致了解企业目前的经营阶段。请说年份和统计范围；范围、暂时没有和不便透露都是有效回答。',
  'B4-channels': '说清目前实际有的销售渠道和门店。自营、经销、认识的合作方分别记录，再确认哪些能用于这次新品。',
  'B5-capability': '举一个过去做过的具体项目或记录，让我们知道团队现在有什么基础。还没有记录的判断也可以注明。',
  'N1-scope': '现在从企业全部业务里，圈定这一次要讨论的具体新品。先不要猜它属于哪一个子品类。',
  'N2-stage': '从0做新品、已有样品或改进现有产品都可以。先说现在有哪些东西已经确定。',
  'N3-commercial': '把已经想到的售价、市场地区和发售渠道记下，没想好的部分留着；这些是当前计划。',
  'M1-references': '把已经知道的相近产品、具体款式和资料放在一起。还没查过，就列接下来需要查的对象。',
  'M2-observations': '先说知道的一点：价格、用处、售卖渠道或主推介绍，并带上来源和查看日期。销量与排名需要额外核实口径。',
  'U1-user': '说清人是谁，以及他第一次接触、刚入门还是已经熟练。同一活动的不同经验阶段，需要不同的设计。',
  'U2-goal': '这个人想完成什么、学会什么、享受什么？功能、兴趣、社交、自我表达和新体验都可以，不必先有严重麻烦。',
  'U3-journey': '像讲一段活动过程，从准备到结束。新品没上市，就看当前同类活动或首次尝试的设想，分别标明来源。',
  'U4-learning': '新手在哪一步需要学习、适应和反馈？熟练者最在意哪一段体验？先说可观察的行为，不要求用户给出技术方案。',
  'U5-evidence': '把真实观察、访谈原话、同类经验和团队推想分开。没有证据的内容也能提出，但要接着安排验证。',
  'D1-outcome': '先选最值得改善的一步，讲清这个人因此能更容易做什么、体验会怎样变化。',
  'D2-ideas': '围绕这一步，团队有什么功能、结构或使用引导的想法？暂时没有也可以，消费者不需要替研发写规格。',
  'D3-delivery': '把能做的、要试的、受成本和时间限制的分别说清。下一步才能判断怎样做样品。',
  'D4-validation': '安排一个真实任务，看人怎么完成、在哪求助、出了什么错、说了什么，再比较设计。只问喜欢吗通常不够。',
};

const FAMILIAR_PROFILES = {
  food: {
    brand: '晨食', portfolio: '酸奶、牛奶和早餐食品', product: '早餐酸奶',
    intro: '就是常见的小杯酸奶，用准备早餐、开杯和食用的过程说明问法。',
    customer: '一位上早班、自己准备早餐的成年人',
    experience: '熟悉常见酸奶，但没尝试过这款新品',
    goal: '希望早上吃得顺手，也想找到自己喜欢的口味',
    journey: '想起要准备早餐、看货架或平台、选择、携带、开杯食用、收拾',
    learning: '第一次看到时能否读懂食用和储存信息，开杯和携带是否顺手',
    outcome: '让第一次购买的人看懂食用信息，并顺利完成开杯和食用',
    idea: '比较更清楚的食用说明、不同开杯方式和口味方案',
    capability: '食品加工合作方和少量试做条件', channels: '便利店或配送合作方',
    task: '让没看过产品的人选购、携带、开杯和试吃，记录理解、求助、操作及口味原话',
  },
  'personal-care': {
    brand: '清沐', portfolio: '洗发水、沐浴用品和日常洗护', product: '日常洗发水',
    intro: '就是洗头时使用、超市常见的洗发水，用选择、开瓶、清洗和冲洗的过程说明问法。',
    customer: '一位经常运动、自己购买洗发水的成年人',
    experience: '熟悉洗头，但没用过这款新配方和新包装',
    goal: '希望运动后洗头的过程顺手，也喜欢合适的气味和使用感',
    journey: '购买和选择、读说明、开瓶取用、清洗、冲洗、擦干、决定是否继续用',
    learning: '第一次使用时能否看懂说明、顺手取用，是否需要适应用量和使用感',
    outcome: '让第一次用的人看懂说明、顺手取用并形成清楚的使用感受',
    idea: '比较取用方式、清楚的用法说明以及不同气味和使用感方案',
    capability: '日化加工合作方、稳定性试验和打样条件', channels: '日用品店或理发店合作方',
    task: '让目标使用者独立阅读、取用和完成一次清洗，记录求助、操作以及使用感原话',
  },
  home: {
    brand: '壶间', portfolio: '电水壶、保温杯和厨房小家电', product: '家用电水壶',
    intro: '就是插电后把水烧开的电水壶，用取水、烧水和倒水的过程说明问法。',
    customer: '一位每天早上给家人准备早餐的成年人',
    experience: '熟悉普通电水壶，但没使用过这款新品',
    goal: '希望早上能顺手准备一杯热饮，也享受一家人吃早餐的时间',
    journey: '取水、加水、放好水壶、启动、等待、倒水、清洁和收纳',
    learning: '第一次看到时能否理解操作和状态提示，握持和倒水是否自然',
    outcome: '让第一次使用的人顺利启动，并清楚知道何时可以倒水',
    idea: '比较握持和操作提示、状态反馈以及倒水方式的方案',
    capability: '小家电加工、检测和打样合作方', channels: '家电门店与售后合作方',
    task: '让目标使用者独立加水、启动和倒水，记录完成情况、求助和操作原话',
  },
  digital: {
    brand: '随行', portfolio: '充电宝、充电线和手机配件', product: '通勤充电宝',
    intro: '就是随身为手机供电的移动电源，用连接、充电和携带的过程说明问法。',
    customer: '一位经常在外跑工作、自己购买手机配件的成年人',
    experience: '用过充电宝，但没见过这款新品的接口和提示方式',
    goal: '希望出门能保持联系，也能顺手给随身设备补电',
    journey: '准备出门、查看电量、选择接口和线、连接设备、观察充电状态、收线和携带',
    learning: '第一次拿到时能否找到合适接口、接对设备并看懂剩余电量与充电状态',
    outcome: '让第一次用的人独立完成连接，并看懂是否正在给手机充电',
    idea: '比较清楚的接口标识、状态反馈和线材收纳方式',
    capability: '配件工厂、检测和基础打样合作方', channels: '数码店和售后合作方',
    task: '让目标使用者独立连接手机、说明充电状态并收好配件，记录求助、错误和原话',
  },
  outdoor: {
    brand: '野坐', portfolio: '帐篷、露营垫和户外用品', product: '周末露营帐篷',
    intro: '就是到营地时搭起来休息的帐篷，用准备、搭建、使用和整理的过程说明问法。',
    customer: '一位刚开始带家人去露营、自己买装备的成年人',
    experience: '借用过帐篷，但还不熟悉独立搭建',
    goal: '希望体验户外休息，和家人一起参与，也想逐步学会独立搭建',
    journey: '选地点、准备装备、打开和辨认部件、搭建、固定、休息、拆卸和收纳',
    learning: '第一次独立搭建时能否辨认部件、理解步骤，并知道当前是否搭好',
    outcome: '让第一次搭建的人更容易完成一轮搭建，并清楚看到是否固定妥当',
    idea: '比较部件标识、逐步搭建引导和完成状态提示',
    capability: '布料与加工合作方、小批量打样条件', channels: '户外门店与营地合作方',
    task: '让第一次独立搭建的人按现场条件搭好并收起帐篷，记录求助步骤、错误和原话',
  },
};
function familiarExample(profile, questionId) {
  const examples = {
    'B1-brand': `比如：我们是${profile.brand}（虚构演示品牌），面向国内日常购买者经营。现在先介绍企业，本次新品接着单独确认。`,
    'B2-portfolio': `比如：企业经营${profile.portfolio}（虚构演示经营范围）。本次具体讨论哪一款，还需要另外说清。`,
    'B3-sales': '比如：可以给出最近一年的年份、全公司还是品类、大概销售额范围；也可以说目前没有或不便透露。例子不提供真实经营数字。',
    'B4-channels': `比如：有直营网店，也认识${profile.channels}；具体多少家和合作类型要按实际记录，不补数字，不默认能发售本次新品。`,
    'B5-capability': `比如：企业有${profile.capability}（虚构演示条件）。应说明过去做过什么、有没有试验或交付记录。`,
    'N1-scope': `比如：企业经营多个品类，但本次只设计一款${profile.product}，先单独说明给谁用。`,
    'N2-stage': `比如：${profile.product}可以从0开始、没有样品；也可以已有样品，想改进第一次使用。两种情况都能继续聊。`,
    'N3-commercial': `比如：初步考虑国内市场，目标价未定，计划先与${profile.channels}确认试用和发售条件。知道哪部分先说哪部分。`,
    'M1-references': `比如：整理几款面向相近人群的${profile.product}，附具体品牌、款式和链接；没整理过就列为待查。`,
    'M2-observations': `比如：对一款具体${profile.product}，分别记录页面价格、主要用途说明、售卖渠道、主推介绍、来源与查看时间。排名和销量另查证据，不由页面存在来推断。`,
    'U1-user': `比如：${profile.customer}；${profile.experience}。`,
    'U2-goal': `比如：这个人${profile.goal}。功能、兴趣和新体验都可以成为目标，不必硬找严重麻烦。`,
    'U3-journey': `比如：当前同类活动包括${profile.journey}。标清哪些亲眼见过，哪些还只是团队预计，不说已用过未上市新品。`,
    'U4-learning': `比如：观察${profile.learning}。先说行为和感受，不要求使用者替研发提出参数。`,
    'U5-evidence': `比如：“他在某一步求助”可以来自观察；“${profile.idea}会有帮助”是团队设计假设。把两类信息分开。`,
    'D1-outcome': `比如：先${profile.outcome}。说明希望带来的实际体验，再考虑具体设计。`,
    'D2-ideas': `比如：团队设想${profile.idea}。这些是备选设计，需要样品验证，不是消费者必须先说出的方案。`,
    'D3-delivery': `比如：已有${profile.capability}，能先试做部分样品；具体结构、稳定性、量产一致性、成本和时间仍要分别核实。`,
    'D4-validation': `比如：${profile.task}，再对比设计方案。不要只问喜不喜欢。`,
  };
  return examples[questionId];
}
function guidanceExample(session, questionId, category) {
  const scope = projectScope(session);
  const source = scope || [session.answers?.['B1-brand'], session.answers?.['B2-portfolio']].filter(Boolean).join('\n');
  if (/路亚|台钓|海钓|钓[具竿杆鱼]|鱼竿/.test(source)) return getSampleAnswer('fishing', questionId);
  if (category.id === 'food' && /人参|红参/.test(source)) return getSampleAnswer('idea', questionId);
  if (FAMILIAR_PROFILES[category.id]) return familiarExample(FAMILIAR_PROFILES[category.id], questionId);
  return GENERAL_EXAMPLES[questionId];
}

export function getGuidance(session = {}, questionId) {
  const question = getQuestion(questionId);
  const category = inferCategory(session);
  const productName = category.productSubcategory;
  const source = projectScope(session) || [session.answers?.['B1-brand'], session.answers?.['B2-portfolio']].filter(Boolean).join('\n');
  const fishing = /路亚|台钓|海钓|钓[具竿杆鱼]|鱼竿/.test(source);
  const ginseng = category.id === 'food' && /人参|红参/.test(source);
  const familiar = FAMILIAR_PROFILES[category.id];
  const referenceProductName = fishing ? '新手入门路亚竿' : ginseng ? '小瓶即饮人参饮料' : familiar?.product || '通勤雨伞';
  const productIntro = fishing
    ? '路亚是一种通过抛投和操作拟饵参与钓鱼的方式。这个例子关注第一次学习装配、抛投和收线的过程。'
    : ginseng ? '用人参作原料、打开就能喝的小瓶饮料。这里用第一次选择和饮用的过程说明问法。'
      : familiar ? familiar.intro : '就是下雨天出门常带的折叠雨伞，用准备、撑开、收起和携带的过程说明问法。';
  const questionTitle = String(question?.title || '').replaceAll('这款新品', productName).replaceAll('这款产品', productName);
  const questionBody = String(question?.body || '').replaceAll('这款新品', productName).replaceAll('这款产品', productName);
  return {
    categoryId: category.id, categoryLabel: category.label, productName,
    referenceProductName, productIntro,
    example: guidanceExample(session, questionId, category) || '可以先说目前知道的部分，再把真实记录和设想分开。',
    options: [...(question?.options || ['先说目前知道的部分'])],
    simpleExplanation: EXPLANATIONS[questionId] || '先说目前知道的部分，再把来源和设想分开。',
    questionTitle, questionBody,
    hypothetical: true,
    experienceLevel: category.experienceLevel,
  };
}
